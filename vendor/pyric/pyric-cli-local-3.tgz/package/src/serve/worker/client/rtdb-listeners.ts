/** RTDB value/child listeners and Firebase-compatible `off` registration identity. */
import type { InboundMessage } from '../protocol.js';
import { executeQuery, queryIdentifier } from 'pyric/database/internal';
import { sameRtdbValue } from '../rtdb-value-equality.js';
import {
  _defaultLens,
  closeSubscription,
  isDisconnectedPort,
  nextSubId,
  openSnapshotSubscription,
  stampIssuer,
  subscribeLens,
} from './core.js';
import type { ClientPort, RtdbDataSnapshot, Unsubscribe } from './handles.js';
import { pageListenerOwners } from './listener-owners.js';
import { observeRtdbConnection } from './rtdb-connection-lifecycle.js';
import { beginWorkerDatabaseActivity } from './sdk-activity.js';
import type { SdkActivityHandle } from 'pyric/sandbox/internal';
import {
  isRtdbQuery,
  rtdbChild,
  targetParts,
  type RtdbTarget,
} from './rtdb-references.js';
import {
  hydrateRtdbSnapshot,
  makeRtdbSnapshot,
  valueAt,
  type RtdbWireEntry,
} from './rtdb-snapshots.js';

export type RtdbEventType =
  | 'value'
  | 'child_added'
  | 'child_changed'
  | 'child_removed'
  | 'child_moved';

interface ListenerRegistration {
  readonly port: ClientPort;
  readonly path: string;
  readonly scope?: string;
  readonly eventType: RtdbEventType;
  readonly callback: object;
  close(): void;
}

const registrations: ListenerRegistration[] = [];

/** Drop client-side registration identity when the owning app port closes. */
export function dropRtdbListenersForPort(port: ClientPort): void {
  for (const registration of [...registrations]) {
    if (registration.port === port) registration.close();
  }
}

function targetScope(target: RtdbTarget): string {
  if (!isRtdbQuery(target)) return 'default';
  return queryIdentifier(target._spec);
}

/**
 * The listen options a value subscription reads. `owner` is pyric's own listen
 * option: the page names who owns the listener, and the owners derived from it
 * travel with the subscribe message.
 */
type ValueListenOptions = { readonly onlyOnce?: boolean; readonly owner?: unknown };

function removeRegistration(registration: ListenerRegistration): void {
  const index = registrations.indexOf(registration);
  if (index >= 0) registrations.splice(index, 1);
}

function openValueSubscription(
  target: RtdbTarget,
  next: (snap: RtdbDataSnapshot) => void,
  cancelCallbackOrOptions: ((err: unknown) => void) | ValueListenOptions | undefined,
  options: ValueListenOptions | undefined,
  activity: SdkActivityHandle,
): Unsubscribe {
  const { ref, query } = targetParts(target);
  const error = typeof cancelCallbackOrOptions === 'function' ? cancelCallbackOrOptions : undefined;
  const listenOptions = typeof cancelCallbackOrOptions === 'function'
    ? options
    : cancelCallbackOrOptions;
  let currentSubId = nextSubId();
  activity.transport(currentSubId);
  let fired = false;
  let unsubscribed = false;

  // Derived here, on the stack the caller is still on and against the page's
  // own document. The worker's attach can read neither.
  const owners = pageListenerOwners(listenOptions);
  const ownerFields = owners ? { owners } : {};

  const makeSubMsg = (subId: string, lens: typeof _defaultLens): InboundMessage =>
    lens
      ? { t: 'sub', subId, target: { service: 'rtdb', path: ref.path, ...(query ? { query } : {}) }, actAs: lens, ...ownerFields }
      : { t: 'sub', subId, target: { service: 'rtdb', path: ref.path, ...(query ? { query } : {}) }, ...ownerFields };

  let unsubLens: () => void = () => {};

  const subHandler = {
    port: ref.port,
    next: (wire: unknown) => {
      if (listenOptions?.onlyOnce && fired) return;
      fired = true;
      // Reported on the subscription id the sandbox also records as the
      // listener id, immediately before the application's callback runs.
      if (listenOptions?.onlyOnce) {
        unsubLens();
        closeSubscription(ref.port, currentSubId);
      }
      next(hydrateRtdbSnapshot(ref, wire));
    },
    error: (cause: unknown) => { activity.fail(); error?.(cause); },
    close: () => activity.close(),
  };

  const opened = openSnapshotSubscription(
    ref.port,
    currentSubId,
    subHandler,
    stampIssuer(makeSubMsg(currentSubId, _defaultLens)),
  );
  if (!opened) activity.fail();
  if (!opened && error) {
    queueMicrotask(() => error(new Error('FIREBASE FATAL ERROR: Database has been deleted.')));
  }

  unsubLens = subscribeLens((newLens) => {
    if (unsubscribed || (listenOptions?.onlyOnce && fired)) return;
    closeSubscription(ref.port, currentSubId);
    currentSubId = nextSubId();
    activity.transport(currentSubId);
    openSnapshotSubscription(
      ref.port,
      currentSubId,
      subHandler,
      stampIssuer(makeSubMsg(currentSubId, newLens)),
    );
  });

  return () => {
    if (unsubscribed) return;
    unsubscribed = true;
    activity.close();
    unsubLens();
    closeSubscription(ref.port, currentSubId);
  };
}

function registerListener(
  target: RtdbTarget,
  eventType: RtdbEventType,
  callback: object,
  unsubscribe: Unsubscribe,
): Unsubscribe {
  const { ref } = targetParts(target);
  let closed = false;
  const registration: ListenerRegistration = {
    port: ref.port,
    path: ref.path,
    scope: targetScope(target),
    eventType,
    callback,
    close() {
      if (closed) return;
      closed = true;
      removeRegistration(registration);
      unsubscribe();
    },
  };
  registrations.push(registration);
  return registration.close;
}

export function rtdbOnValue(
  target: RtdbTarget,
  next: (snap: RtdbDataSnapshot) => void,
  cancelCallbackOrOptions?: ((err: unknown) => void) | ValueListenOptions,
  options?: ValueListenOptions,
  registryCallback: object = next,
): Unsubscribe {
  const hasCancelCallback = typeof cancelCallbackOrOptions === 'function';
  const listenOptions = hasCancelCallback
    ? options
    : cancelCallbackOrOptions;
  const activity = beginWorkerDatabaseActivity(target, 'onValue', 'subscription', pageListenerOwners(listenOptions));
  let unsubscribe: Unsubscribe = () => {};
  const deliver = (snapshot: RtdbDataSnapshot): void => {
    try {
      activity.delivered(snapshot);
      next(snapshot);
    } catch {
      // Firebase isolates listener exceptions from sibling deliveries.
    } finally {
      const isOnce = listenOptions?.onlyOnce === true;
      if (isOnce) queueMicrotask(() => unsubscribe());
    }
  };
  const { ref, query } = targetParts(target);
  const isActivePort = !isDisconnectedPort(ref.port);
  const isConnectionValue = ref.path === '/.info/connected';
  const isMetadataRoot = ref.path === '/.info';
  const observesConnection = isActivePort && (isConnectionValue || isMetadataRoot);
  let rawUnsubscribe: Unsubscribe;
  if (observesConnection) {
    let previousRows: RtdbWireEntry[] | undefined;
    rawUnsubscribe = observeRtdbConnection(ref.port, (connected) => {
      const value = isMetadataRoot ? { connected, serverTimeOffset: 0 } : connected;
      const filtersChildren = isMetadataRoot && query !== undefined;
      if (filtersChildren) {
        const rows = executeQuery(value, query);
        const isUnchangedSelection = sameRtdbValue(previousRows, rows);
        if (isUnchangedSelection) return;
        previousRows = rows;
        const hasRows = rows.length > 0;
        const projection = Object.fromEntries(rows.map(({ key, value }) => [key, value]));
        const selectedValue = hasRows ? projection : null;
        deliver(makeRtdbSnapshot(ref, selectedValue, hasRows, null, rows));
        return;
      }
      deliver(makeRtdbSnapshot(ref, value));
    });
  } else {
    rawUnsubscribe = openValueSubscription(target, deliver, cancelCallbackOrOptions, options, activity);
  }
  unsubscribe = registerListener(
    target,
    'value',
    registryCallback,
    () => { activity.close(); rawUnsubscribe(); },
  );
  return unsubscribe;
}

type ChildEventKind = 'added' | 'changed' | 'removed' | 'moved';

function directChildren(value: unknown): Record<string, unknown> {
  if (Array.isArray(value)) {
    return Object.fromEntries(
      value.flatMap((child, index) => child == null ? [] : [[String(index), child]]),
    );
  }
  if (value === null || typeof value !== 'object') return {};
  return value as Record<string, unknown>;
}

function rtdbKeyCompare(left: string, right: string): number {
  const integerKey = (key: string): number | null => {
    if (!/^(0|[1-9]\d*)$/.test(key)) return null;
    const value = Number(key);
    return Number.isSafeInteger(value) && value <= 2_147_483_647 ? value : null;
  };
  const leftInteger = integerKey(left);
  const rightInteger = integerKey(right);
  if (leftInteger !== null && rightInteger !== null) return leftInteger - rightInteger;
  if (leftInteger !== null) return -1;
  if (rightInteger !== null) return 1;
  return left < right ? -1 : left > right ? 1 : 0;
}

function onChildEvent(
  target: RtdbTarget,
  kind: ChildEventKind,
  next: (snap: RtdbDataSnapshot, previousChildName: string | null) => void,
  error: ((err: unknown) => void) | undefined,
  activity: SdkActivityHandle,
  reverseInitial = false,
): Unsubscribe {
  const { ref, query } = targetParts(target);
  let initialized = false;
  let previous: RtdbWireEntry[] = [];
  return openValueSubscription(target, (parent) => {
    const current: RtdbWireEntry[] = [];
    parent.forEach((childSnap) => {
      if (childSnap.key !== null) {
        current.push({
          key: childSnap.key,
          value: childSnap.val(),
          priority: childSnap.priority,
          exportValue: childSnap.exportVal(),
        });
      }
    });
    if (current.length === 0) {
      for (const key of Object.keys(directChildren(parent.val())).sort(rtdbKeyCompare)) {
        current.push({ key, value: directChildren(parent.val())[key] });
      }
    }
    const emit = (entry: RtdbWireEntry, previousChildName: string | null): void => {
      try {
        next(makeRtdbSnapshot(
          rtdbChild(ref, entry.key),
          entry.value,
          undefined,
          entry.priority ?? null,
          undefined,
          entry.exportValue ?? entry.value,
        ), previousChildName);
      } catch {
        // Firebase isolates listener exceptions from sibling deliveries.
      }
    };
    if (!initialized) {
      initialized = true;
      if (kind === 'added') {
        const indexes = current.map((_, index) => index);
        if (reverseInitial) indexes.reverse();
        for (const index of indexes) {
          emit(current[index]!, current[index - 1]?.key ?? null);
        }
      }
      previous = current;
      return;
    }
    const previousByKey = new Map(previous.map((entry, index) => [entry.key, { entry, index }]));
    const currentByKey = new Map(current.map((entry, index) => [entry.key, { entry, index }]));
    if (kind === 'removed') {
      for (const prior of previous) {
        if (!currentByKey.has(prior.key)) {
          emit(prior, null);
        }
      }
    } else {
      for (let index = 0; index < current.length; index++) {
        const entry = current[index]!;
        const prior = previousByKey.get(entry.key);
        const previousChildName = current[index - 1]?.key ?? null;
        if (kind === 'added' && !prior) emit(entry, previousChildName);
        if (kind === 'changed' && prior && !sameRtdbValue(prior.entry.value, entry.value)) {
          emit(entry, previousChildName);
        }
        if (kind === 'moved' && prior) {
          const orderBy = query?.orderBy ?? { kind: 'priority' as const };
          const indexed = (candidate: RtdbWireEntry): unknown => {
            if (orderBy.kind === 'key') return candidate.key;
            if (orderBy.kind === 'priority') return candidate.priority ?? null;
            if (orderBy.kind === 'value') return candidate.value;
            return valueAt(candidate.value, orderBy.path);
          };
          if (!sameRtdbValue(indexed(prior.entry), indexed(entry))) {
            emit(entry, previousChildName);
          }
        }
      }
    }
    previous = current;
  }, error, undefined, activity);
}

function subscribeChild(
  target: RtdbTarget,
  kind: ChildEventKind,
  next: (snap: RtdbDataSnapshot, previousChildName: string | null) => void,
  cancelCallbackOrOptions?: ((err: unknown) => void) | ValueListenOptions,
  options?: ValueListenOptions,
  registryCallback: object = next,
): Unsubscribe {
  const error = typeof cancelCallbackOrOptions === 'function' ? cancelCallbackOrOptions : undefined;
  const listenOptions = typeof cancelCallbackOrOptions === 'function'
    ? options
    : cancelCallbackOrOptions;
  const activity = beginWorkerDatabaseActivity(target, `onChild${kind[0]!.toUpperCase()}${kind.slice(1)}`, 'subscription', pageListenerOwners(listenOptions));
  const callback = next;
  next = (snapshot, previous) => { activity.delivered(snapshot); callback(snapshot, previous); };
  const eventType = `child_${kind}` as RtdbEventType;
  if (!listenOptions?.onlyOnce) {
    return registerListener(target, eventType, registryCallback, onChildEvent(target, kind, next, error, activity));
  }
  let stopped = false;
  let stopScheduled = false;
  let unsubscribe: Unsubscribe = () => {};
  const rawUnsubscribe = onChildEvent(target, kind, (snapshot, previousChildName) => {
    if (stopped) return;
    try {
      next(snapshot, kind === 'removed' ? null : previousChildName);
    } finally {
      if (kind === 'added') {
        if (!stopScheduled) {
          stopScheduled = true;
          queueMicrotask(() => { stopped = true; unsubscribe(); });
        }
      } else {
        stopped = true;
        unsubscribe();
      }
    }
  }, error, activity, kind === 'added');
  unsubscribe = registerListener(target, eventType, registryCallback, rawUnsubscribe);
  return unsubscribe;
}

type ChildCallback = (snap: RtdbDataSnapshot, previousChildName: string | null) => void;
type CancelOrOptions = ((err: unknown) => void) | { readonly onlyOnce?: boolean };
type ListenOptions = { readonly onlyOnce?: boolean };

export function rtdbOnChildAdded(target: RtdbTarget, next: ChildCallback, cancel?: CancelOrOptions, options?: ListenOptions, identity: object = next): Unsubscribe {
  return subscribeChild(target, 'added', next, cancel, options, identity);
}

export function rtdbOnChildChanged(target: RtdbTarget, next: ChildCallback, cancel?: CancelOrOptions, options?: ListenOptions, identity: object = next): Unsubscribe {
  return subscribeChild(target, 'changed', next, cancel, options, identity);
}

export function rtdbOnChildRemoved(target: RtdbTarget, next: ChildCallback, cancel?: CancelOrOptions, options?: ListenOptions, identity: object = next): Unsubscribe {
  return subscribeChild(target, 'removed', next, cancel, options, identity);
}

export function rtdbOnChildMoved(target: RtdbTarget, next: ChildCallback, cancel?: CancelOrOptions, options?: ListenOptions, identity: object = next): Unsubscribe {
  return subscribeChild(target, 'moved', next, cancel, options, identity);
}

export function rtdbOff(target: RtdbTarget, eventType?: RtdbEventType, callback?: object): void {
  const { ref } = targetParts(target);
  const scope = targetScope(target);
  const allViews = !isRtdbQuery(target);
  const matches = (registration: ListenerRegistration): boolean =>
    registration.port === ref.port
      && registration.path === ref.path
      && (allViews || registration.scope === scope)
      && (eventType === undefined || registration.eventType === eventType)
      && (callback === undefined || registration.callback === callback);
  if (callback !== undefined && eventType !== undefined) {
    registrations.find(matches)?.close();
    return;
  }
  for (const registration of [...registrations]) {
    if (matches(registration)) registration.close();
  }
}
