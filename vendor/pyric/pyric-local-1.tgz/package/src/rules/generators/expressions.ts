/**
 * Firestore rules expression generators for grid-based games.
 *
 * Win detection returns a Firestore rules boolean expression over the board
 * parameter `b`; the gravity pattern returns a regular expression for a rules
 * `matches()` call.
 */

import type { GridConfig } from './grid.js';
import { indexToColRow } from './grid.js';

/**
 * Win detection: OR of all winning lines for a specific mark.
 * Uses `b` as the board parameter name.
 *
 * Example output: (b.c0r0 == 'R' && b.c1r0 == 'R' && b.c2r0 == 'R' && b.c3r0 == 'R') || ...
 */
export function winCheckExpr(mark: string, lines: number[][], grid: GridConfig): string {
  return lines.map(line => {
    const cells = line.map(i => {
      const [c, r] = indexToColRow(i, grid.cols);
      return `b.${grid.cellName(c, r)} == '${mark}'`;
    });
    return `(${cells.join(' && ')})`;
  }).join('\n          || ');
}

/**
 * Split win lines by direction for per-direction functions.
 * Returns { horizontal, vertical, diagUp, diagDown }.
 */
export function splitWinLinesByDirection(
  lines: number[][],
  cols: number,
): { horizontal: number[][]; vertical: number[][]; diagUp: number[][]; diagDown: number[][] } {
  const horizontal: number[][] = [];
  const vertical: number[][] = [];
  const diagUp: number[][] = [];
  const diagDown: number[][] = [];

  for (const line of lines) {
    const [c0, r0] = indexToColRow(line[0], cols);
    const [c1, r1] = indexToColRow(line[1], cols);
    const dc = c1 - c0;
    const dr = r1 - r0;
    if (dc === 1 && dr === 0) horizontal.push(line);
    else if (dc === 0 && dr === 1) vertical.push(line);
    else if (dc === 1 && dr === 1) diagUp.push(line);
    else diagDown.push(line);
  }

  return { horizontal, vertical, diagUp, diagDown };
}

/**
 * Gravity: a regular expression matching
 * `<cell>:<cell below>` for every cell on the board, where the part after
 * the colon is empty for the bottom row. Rules cannot compute a neighbor's
 * key, so the client stores both keys and this pattern pins them to real
 * vertical neighbors.
 */
export function gravityPairsPattern(grid: GridConfig): string {
  const escape = (name: string) => name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pairs: string[] = [];
  for (let c = 0; c < grid.cols; c++) {
    for (let r = 0; r < grid.rows; r++) {
      const below = r > 0 ? escape(grid.cellName(c, r - 1)) : '';
      pairs.push(`${escape(grid.cellName(c, r))}:${below}`);
    }
  }
  return pairs.join('|');
}
