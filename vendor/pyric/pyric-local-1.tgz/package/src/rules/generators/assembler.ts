/**
 * Assembles a complete Firestore security rules file for a grid-based game.
 *
 * Board layouts (chosen automatically by board size):
 * - Small boards (≤42 cells): cells in a nested `board` map, one win function per player
 * - Medium boards (43-121 cells): cells as top-level fields, win functions split by direction
 *
 * Game document fields: host, guest, currentTurn, status, winner, moveCount,
 * lastMove (the key of the cell the latest move filled, '' before the first
 * move) and, for gravity games, lastBelow (the key of the cell directly
 * beneath lastMove, '' on the bottom row).
 *
 * Every update transition (normal move, win claim, draw claim) carries the
 * same move check: the cell named by lastMove was empty, now holds the
 * mover's mark, rests on an occupied cell when the game has gravity, and no
 * other cell or field outside the move metadata changed. Win and draw rules
 * add their outcome check on top, so a claim can never write more than one
 * legal placement.
 *
 * Uses the stdlib convention: host/guest/currentTurn/status.
 */

import type { GridConfig } from './grid.js';
import { generateWinLines } from './grid.js';
import { winCheckExpr, splitWinLinesByDirection, gravityPairsPattern } from './expressions.js';

export interface GameConfig {
  collection: string;
  grid: GridConfig;
  winLineCount: number;       // N-in-a-row (3 for TTT, 4 for C4, 5 for Gomoku)
  hasGravity: boolean;
  hasLobby: boolean;
}

const SMALL_BOARD_THRESHOLD = 42;

/** A single Firestore path segment we are willing to interpolate into a
 *  `match /<collection>/{gameId}` block. Deliberately stricter than
 *  Firestore's own collection-id rules: alphanumerics, dash, underscore,
 *  1–64 chars. Anything else (slashes, braces, whitespace, newlines) could
 *  break out of the match block and inject arbitrary rules, so we reject it
 *  rather than escape it. */
const COLLECTION_SEGMENT = /^[A-Za-z0-9_-]{1,64}$/;

/** Validate a caller-supplied collection name before it is interpolated into
 *  generated rules source. Throws on anything that isn't a plain path
 *  segment — every caller of the public `pyric/rules` generator is safe by
 *  default, no escaping required at the call site. */
function assertSafeCollection(collection: string): void {
  if (typeof collection !== 'string' || !COLLECTION_SEGMENT.test(collection)) {
    throw new Error(
      `assembleGameRules: invalid collection ${JSON.stringify(collection)} — ` +
        `must match ${COLLECTION_SEGMENT} (a single Firestore path segment: ` +
        `letters, digits, "-" or "_", 1–64 chars). Rejected to prevent rules injection.`,
    );
  }
}

/** Where the cells live and how a win is detected, for one board size. */
interface Layout {
  /** The cell map after and before the write. */
  next: string;
  prev: string;
  /** Rules functions the layout needs (win detection). */
  functions: string;
  /** Expressions that hold when the post-write cells contain a winning line. */
  hostWon: string;
  guestWon: string;
  /** Holds when the write changes only `metadataKeys` and the placed cell. */
  onlyMoveChanged(metadataKeys: string[]): string;
  /** Holds when every cell of a document being created is ''. */
  boardEmpty: string;
}

export function assembleGameRules(config: GameConfig): string {
  const { grid, winLineCount, collection } = config;
  assertSafeCollection(collection);
  const lines = generateWinLines(grid.cols, grid.rows, winLineCount);
  const layout = grid.cols * grid.rows > SMALL_BOARD_THRESHOLD
    ? flatLayout(grid, lines)
    : nestedLayout(grid, lines);
  return assemble(config, layout);
}

// ---- Small boards: nested board map, single win function per player ----
function nestedLayout(grid: GridConfig, lines: number[][]): Layout {
  return {
    next: 'request.resource.data.board',
    prev: 'resource.data.board',
    functions: `    function hasWonHost(b) {
      return ${winCheckExpr('host', lines, grid)};
    }

    function hasWonGuest(b) {
      return ${winCheckExpr('guest', lines, grid)};
    }`,
    hostWon: 'hasWonHost(request.resource.data.board)',
    guestWon: 'hasWonGuest(request.resource.data.board)',
    onlyMoveChanged: keys => `request.resource.data.board.diff(resource.data.board).affectedKeys().hasOnly([request.resource.data.lastMove])
          && request.resource.data.diff(resource.data).affectedKeys().hasOnly([${quoteAll(['board', ...keys])}])`,
    boardEmpty: `request.resource.data.board.size() == ${grid.cols * grid.rows}
        && request.resource.data.board.values().hasOnly([''])`,
  };
}

// ---- Medium boards: flat top-level cells, directional win split ----
function flatLayout(grid: GridConfig, lines: number[][]): Layout {
  const dirs = splitWinLinesByDirection(lines, grid.cols);

  function dirWinFn(name: string, mark: string, dirLines: number[][]): string {
    if (dirLines.length === 0) return `    function ${name}(b) { return false; }`;
    return `    function ${name}(b) {
      return ${winCheckExpr(mark, dirLines, grid)};
    }`;
  }

  const functions = [
    dirWinFn('wonHH', 'host', dirs.horizontal),
    dirWinFn('wonHV', 'host', dirs.vertical),
    dirWinFn('wonHD1', 'host', dirs.diagUp),
    dirWinFn('wonHD2', 'host', dirs.diagDown),
    dirWinFn('wonGH', 'guest', dirs.horizontal),
    dirWinFn('wonGV', 'guest', dirs.vertical),
    dirWinFn('wonGD1', 'guest', dirs.diagUp),
    dirWinFn('wonGD2', 'guest', dirs.diagDown),
  ].join('\n\n');

  const emptyCells: string[] = [];
  for (let c = 0; c < grid.cols; c++) {
    for (let r = 0; r < grid.rows; r++) emptyCells.push(`${rulesStringLiteral(grid.cellName(c, r))}: ''`);
  }

  return {
    next: 'request.resource.data',
    prev: 'resource.data',
    functions,
    hostWon: '(wonHH(request.resource.data) || wonHV(request.resource.data) || wonHD1(request.resource.data) || wonHD2(request.resource.data))',
    guestWon: '(wonGH(request.resource.data) || wonGV(request.resource.data) || wonGD1(request.resource.data) || wonGD2(request.resource.data))',
    onlyMoveChanged: keys => `request.resource.data.diff(resource.data).affectedKeys().hasOnly([${quoteAll(keys)}, request.resource.data.lastMove])`,
    // A cell holding anything but '' shows up as a changed key.
    boardEmpty: `request.resource.data.diff({${emptyCells.join(', ')}}).changedKeys().size() == 0`,
  };
}

function assemble(config: GameConfig, layout: Layout): string {
  const { grid, hasGravity, hasLobby, collection } = config;
  const totalCells = grid.cols * grid.rows;
  const { next, prev } = layout;

  const metadataKeys = ['lastMove', 'currentTurn', 'moveCount', 'status', 'winner'];
  if (hasGravity) metadataKeys.push('lastBelow');

  const turn = `request.auth != null
          && resource.data.status == 'playing'
          && (
            (resource.data.currentTurn == 'host' && request.auth.uid == resource.data.host)
            || (resource.data.currentTurn == 'guest' && request.auth.uid == resource.data.guest)
          )
          && (
            (resource.data.currentTurn == 'host' && request.resource.data.currentTurn == 'guest')
            || (resource.data.currentTurn == 'guest' && request.resource.data.currentTurn == 'host')
          )
          && request.resource.data.moveCount == resource.data.moveCount + 1`;

  // Rules cannot compute a neighbor's key, so gravity games store the key of
  // the cell beneath the move in lastBelow. The pattern pins the pair to real
  // vertical neighbors ('' below the bottom row); the cell beneath must be
  // occupied.
  const gravity = hasGravity
    ? `
          && (request.resource.data.lastMove + ':' + request.resource.data.lastBelow).matches(${rulesStringLiteral(gravityPairsPattern(grid))})
          && (request.resource.data.lastBelow == '' || ${prev}[request.resource.data.lastBelow] != '')`
    : '';

  const move = `${prev}[request.resource.data.lastMove] == ''
          && ${next}[request.resource.data.lastMove] == resource.data.currentTurn
          && ${layout.onlyMoveChanged(metadataKeys)}${gravity}`;

  return `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

${layout.functions}

    match /${collection}/{gameId} {
      allow read: if request.auth != null;
${lobbyRules(hasLobby, hasGravity, layout.boardEmpty)}
      // Firestore charges every evaluated expression, including each link of
      // an && chain, against one budget of 1000 per request, across all the
      // allow rules it tries. Each transition therefore tests one outcome
      // field first and groups the rest, so the rules for other transitions
      // stop after a single comparison.

      // --- Normal move (game continues) ---
      allow update: if request.resource.data.status == 'playing' && (
        request.resource.data.winner == ''
          && ${turn}
          && ${move}
      );

      // --- Winning move (host) ---
      allow update: if request.resource.data.winner == 'host' && (
        request.resource.data.status == 'won'
          && ${turn}
          && ${move}
          && ${layout.hostWon}
      );

      // --- Winning move (guest) ---
      allow update: if request.resource.data.winner == 'guest' && (
        request.resource.data.status == 'won'
          && ${turn}
          && ${move}
          && ${layout.guestWon}
      );

      // --- Draw ---
      allow update: if request.resource.data.status == 'draw' && (
        request.resource.data.winner == ''
          && request.resource.data.moveCount == ${totalCells}
          && ${turn}
          && ${move}
      );
    }
  }
}
`;
}

function quoteAll(keys: string[]): string {
  return keys.map(rulesStringLiteral).join(', ');
}

/** Quote a value as a single-quoted rules string literal. */
function rulesStringLiteral(value: string): string {
  return `'${value.replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
}

// ---- Lobby rules ----
function lobbyRules(hasLobby: boolean, hasGravity: boolean, boardEmpty: string): string {
  const freshMove = `request.resource.data.lastMove == ''${hasGravity ? `
        && request.resource.data.lastBelow == ''` : ''}
        && ${boardEmpty}`;

  if (!hasLobby) return `
      allow create: if request.auth != null
        && request.resource.data.host == request.auth.uid
        && request.resource.data.currentTurn == 'host'
        && request.resource.data.status == 'playing'
        && request.resource.data.winner == ''
        && request.resource.data.moveCount == 0
        && ${freshMove};
`;
  return `
      allow create: if request.auth != null
        && request.resource.data.host == request.auth.uid
        && request.resource.data.guest == ''
        && request.resource.data.currentTurn == 'host'
        && request.resource.data.status == 'waiting'
        && request.resource.data.winner == ''
        && request.resource.data.moveCount == 0
        && ${freshMove};

      allow update: if resource.data.status == 'waiting' && (
        request.auth != null
          && request.resource.data.status == 'playing'
          && resource.data.guest == ''
          && request.resource.data.guest == request.auth.uid
          && request.auth.uid != resource.data.host
          && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['guest', 'status'])
      );

      allow delete: if request.auth != null
        && resource.data.status == 'waiting'
        && request.auth.uid == resource.data.host;
`;
}
