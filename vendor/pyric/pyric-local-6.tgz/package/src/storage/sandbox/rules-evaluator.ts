import { FirestoreSet } from '../../rules/simulator/firestore-set.js';
import { RulesFloat } from '../../rules/simulator/wrappers/float.js';
import {
  expandVerb,
  type EvaluationInput,
  type EvaluationResult,
  type Expr,
  type FirestoreLookup,
  type FunctionMap,
  type MatchBlock,
  type StorageResource,
  type StorageRules,
} from './rules.js';
import { buildRequestObject, buildResourceObject } from './rules-bindings.js';
import { applyConversion, conversionFor } from './rules-conversions.js';
import { evalMethodCall } from './rules-methods.js';
import {
  cmp,
  evalArithmetic,
  evalValueOperator,
  isValueTypeOperand,
  typeMatches,
} from './rules-operators.js';
import { formatPath, matchSegments, splitPath } from './rules-path-match.js';
import {
  RuleEvalError,
  RuleResourceLimitError,
  RuleUnsupportedError,
  isAbsorbableEvalError,
} from './rules-evaluation-error.js';
import { StoragePath } from './rules-path.js';
import {
  RuleError,
  describeRulesType as describeType,
  isRuleError as isErr,
  isRulesMap,
  rulesEquals,
} from './rules-values.js';

export function evaluateStorageRules(
  rules: StorageRules,
  input: EvaluationInput,
  now: Date = new Date(),
  firestoreLookup?: FirestoreLookup,
): EvaluationResult {
  // `request.time` is the request's evaluation moment. The caller injects it
  // (deterministic in tests); it defaults to now. The request binding turns
  // it into the Timestamp value `timestamp.date(...)` and
  // `timestamp.value(...)` also build.
  const nowMillis = now.getTime();
  const pathSegments = splitPath(input.request.path);
  const reasons: string[] = [];
  const firestoreAccesses = new Set<string>();

  // The operation's verb, reduced to its granular set. A coarse
  // request method expands to its sub-verbs so umbrella semantics are
  // symmetric; a precise granular verb expands to itself.
  const requestVerbs = new Set(expandVerb(input.request.method));

  /**
   * Walk a match block. `remaining` is the still-unmatched part of
   * the request path; `params` are the bindings accumulated so far.
   * Recurses into matching children. Whenever a block fully
   * consumes the path, its `allow` rules run.
   */
  function visit(
    block: MatchBlock,
    remaining: string[],
    params: Record<string, string | string[]>,
  ): boolean {
    // Match this block's segments against the start of `remaining`.
    const match = matchSegments(block.segments, remaining, params);
    if (!match) return false;
    const newParams = match.params;
    const left = match.left;

    // If this block fully consumes the path, evaluate its allow
    // rules. (Or if a wildcard absorbed the remainder.)
    if (left.length === 0) {
      for (const rule of block.allows) {
        // A grant applies when the operation's verb falls within the
        // grant's verbs after coarse→granular expansion. `allow read`
        // covers get + list; `allow get` covers only get.
        const grantVerbs = new Set(rule.verbs.flatMap(expandVerb));
        const applies = [...requestVerbs].some((v) => grantVerbs.has(v));
        if (!applies) continue;
        let result: boolean;
        try {
          let value: unknown = true;
          if (rule.condition) {
            value = evalExpr(rule.condition, {
              input,
              now: nowMillis,
              params: newParams,
              locals: {},
              funcs: block.visibleFuncs ?? new Map(),
              depth: 0,
              firestoreLookup,
              firestoreAccesses,
            });
          }
          if (typeof value === 'boolean') {
            result = value;
          } else {
            // Not a bool. Either the expression already produced an evaluation
            // error, or CEL's boolean typing of the allow boundary makes one
            // here: the same `RuleError` the ternary condition raises, rather
            // than a truthiness coercion. Both DENY this rule with production's
            // own message in the reason trace and continue to the next rule.
            // Registry rows
            // `storage-rules#storage.semantic.strict-boolean-allow-boundary`
            // and `storage-rules#storage.semantic.strict-boolean-ternary-condition`
            // carry the claim; corpus scenario
            // `strict-boolean-allow-and-ternary` is the capture that verifies it.
            let failure: RuleError;
            if (isErr(value)) {
              failure = value;
            } else {
              failure = new RuleError(`Allow condition expected bool, got ${describeType(value)}.`);
            }
            reasons.push(
              `match ${formatPath(block.segments)} ${input.request.method}: ${failure.message}`,
            );
            continue;
          }
        } catch (err) {
          // Any thrown evaluation failure (depth exceeded, an unresolved
          // import, an error inside a body) denies this rule with a reason
          // that names the function, never a false allow.
          if (err instanceof RuleEvalError) {
            reasons.push(
              `match ${formatPath(block.segments)} ${input.request.method}: ${err.message}`,
            );
            continue;
          }
          throw err;
        }
        if (result) return true;
        reasons.push(
          `match ${formatPath(block.segments)} ${input.request.method}: condition false`,
        );
      }
    }
    // Recurse into children with the leftover path.
    for (const child of block.children) {
      if (visit(child, left, newParams)) return true;
    }
    return false;
  }

  const allowed = visit(rules._root, pathSegments, {});
  if (!allowed && reasons.length === 0) {
    reasons.push(`no rule matches ${input.request.method} /${pathSegments.join('/')}`);
  }
  return { allowed, reasons };
}

/** Property read against `obj`, with production's absent-property semantics:
 *  a key that is missing — or present but holding `undefined` — is an ERROR,
 *  never a silent `undefined`. */
function readProperty(obj: unknown, name: string): unknown {
  if (!isRulesMap(obj) && !Array.isArray(obj)) {
    return new RuleError(`Property ${name} is undefined on ${describeType(obj)}.`);
  }
  if (!Object.hasOwn(obj, name)) {
    return new RuleError(`Property ${name} is undefined on object.`);
  }
  const v = obj[name as keyof typeof obj];
  if (v === undefined) return new RuleError(`Property ${name} is undefined on object.`);
  return v;
}

/**
 * Raised when a user-defined function cannot be evaluated (undefined,
 * wrong arity, call depth exceeded, or an error surfacing from within a
 * body). Caught at the condition boundary and converted into a
 * deny-with-reason so a function failure NEVER produces a false allow,
 * matching production Storage, where evaluation errors deny.
 */
/**
 * Production Storage caps function call depth (documented limit 20) and
 * effectively disallows recursion. We enforce a hard cap that errors
 * (→ deny) rather than looping forever.
 */
const MAX_CALL_DEPTH = 20;

/** Everything an expression needs to evaluate. */
export interface EvalCtx {
  input: EvaluationInput;
  /** The evaluation instant in epoch milliseconds (injected by the caller,
   *  defaulting to evaluation-time now); `request.time` is its Timestamp. */
  now: number;
  /** Path wildcards from the enclosing match. Empty inside a function
   *  body: caller wildcards do not leak in except via arguments. */
  params: Record<string, string | string[]>;
  /** Function parameter and `let` bindings for the current body. */
  locals: Record<string, unknown>;
  /** Functions callable from the current scope. */
  funcs: FunctionMap;
  /** Current call depth (0 at an allow condition). */
  depth: number;
  /** Optional Firestore read capability for `firestore.get()/exists()`.
   *  Absent in pure/test usage → those methods deny "unsupported". */
  firestoreLookup?: FirestoreLookup;
  /** Distinct Firestore document paths charged during this evaluation. */
  firestoreAccesses: Set<string>;
}

/**
 * Walk an `Expr` against the bindings + path params. Missing bindings or
 * members and invalid operations produce `RuleError` values. They propagate
 * unless a `&&`/`||` operand that uniquely determines the result absorbs
 * them COMMUTATIVELY, CEL-style (`<error> || true` → true, and
 * `<error> && false` → false, see the binary case). Any `RuleError` that
 * reaches an allow boundary denies with its production-shaped reason.
 *
 * Function-evaluation failures throw `RuleEvalError`; at a `&&`/`||`
 * operand boundary the ABSORBABLE ones are converted to error values so
 * they participate in the same absorption, while unsupported/compile-reject
 * (`RuleUnsupportedError`) and resource-limit (`RuleResourceLimitError`)
 * failures re-throw and fail the evaluation closed. The allow boundary
 * catches whatever still throws and denies instead of falling through to a
 * potentially truthy value.
 */
export function evalExpr(expr: Expr, ctx: EvalCtx): unknown {
  switch (expr.kind) {
    case 'literal':
      return expr.value;
    case 'ident': {
      // Local (param / let) bindings win over globals and path params.
      if (expr.name in ctx.locals) return ctx.locals[expr.name];
      if (expr.name === 'request') return buildRequestObject(ctx.input, ctx.now);
      // Production exposes no usable `resource` value when the target object
      // does not exist. Even comparing the missing binding with null errors
      // and denies; it is not a JavaScript-like null sentinel.
      if (expr.name === 'resource') {
        return ctx.input.resource === null
          ? new RuleError('Null value error.')
          : buildResourceObject(ctx.input.resource);
      }
      if (expr.name in ctx.params) return ctx.params[expr.name];
      return undefined;
    }
    case 'member': {
      const t = evalExpr(expr.target, ctx);
      if (isErr(t)) return t;
      // Production: dereferencing a null (e.g. `resource.name` on a create) is
      // a "Null value error" — it denies, and denies through a negation too.
      if (t === null || t === undefined) return new RuleError(`Null value error.`);
      return readProperty(t, expr.name);
    }
    case 'index': {
      const t = evalExpr(expr.target, ctx);
      if (isErr(t)) return t;
      if (t === null || t === undefined) return new RuleError(`Null value error.`);
      const idx = evalExpr(expr.index, ctx);
      if (isErr(idx)) return idx;
      return readProperty(t, String(idx));
    }
    case 'call':
      return evalCall(expr, ctx);
    case 'methodcall':
      return evalMethodCall(expr, ctx);
    case 'path':
      // A path literal is only meaningful as a `firestore.get()/exists()`
      // argument (handled directly there). Reaching it anywhere else means
      // the rule used it out of position, a compile-reject-class failure
      // (never absorbed): deny rather than coerce.
      throw new RuleUnsupportedError('a Firestore path literal is only valid as an argument to firestore.get()/exists()');
    case 'unary': {
      const a = evalExpr(expr.arg, ctx);
      if (expr.op === '!') {
        if (isErr(a)) {
          throw new RuleEvalError(a.message);
        }
        if (typeof a !== 'boolean') {
          throw new RuleEvalError(`Unary '!' expects a boolean, got ${describeType(a)}.`);
        }
        return !a;
      }
      if (isErr(a)) return a;
      if (expr.op === '-') {
        if (a instanceof RulesFloat) return new RulesFloat(-a.value);
        if (typeof a !== 'number') return new RuleError(`Unary '-' applied to ${describeType(a)}.`);
        return -a;
      }
      return undefined;
    }
    case 'ternary': {
      const c = evalExpr(expr.cond, ctx);
      // An error condition denies the whole conditional; it must not fall
      // through to the alternate branch and potentially allow.
      if (isErr(c)) return c;
      // CEL types the condition as bool. A non-boolean condition is an
      // evaluation error, which `&&` and `||` absorb like any other. Registry
      // row `storage-rules#storage.semantic.strict-boolean-ternary-condition`
      // carries the claim; corpus scenario `strict-boolean-allow-and-ternary`
      // is the capture that would verify it.
      if (typeof c !== 'boolean') {
        return new RuleError(`Ternary condition expected bool, got ${describeType(c)}.`);
      }
      return c ? evalExpr(expr.then, ctx) : evalExpr(expr.else, ctx);
    }
    case 'in': {
      const el = evalExpr(expr.element, ctx);
      if (isErr(el)) return el;
      const coll = evalExpr(expr.collection, ctx);
      if (isErr(coll)) return coll;
      // `x in list` is membership; `x in map` tests OWN keys only — production
      // maps never expose prototype names (`'toString' in map` is false;
      // live-pinned by rules-firestore-prototype-chain-keys), so JS `in`
      // (which walks the prototype chain) would false-ALLOW here.
      if (Array.isArray(coll)) return coll.some((v) => rulesEquals(v, el));
      if (coll instanceof FirestoreSet) return coll.hasAll([el]);
      if (isRulesMap(coll)) return typeof el === 'string' && Object.prototype.hasOwnProperty.call(coll, el);
      return new RuleError(`'in' applied to ${describeType(coll)} (expected a list, set, or map).`);
    }
    case 'is': {
      const v = evalExpr(expr.value, ctx);
      if (isErr(v)) return v;
      return typeMatches(v, expr.typeName);
    }
    case 'list': {
      const out: unknown[] = [];
      for (const el of expr.elements) {
        const v = evalExpr(el, ctx);
        if (isErr(v)) return v;
        out.push(v);
      }
      return out;
    }
    case 'map': {
      const out: Record<string, unknown> = {};
      for (const entry of expr.entries) {
        const k = evalExpr(entry.key, ctx);
        if (isErr(k)) return k;
        if (typeof k !== 'string') return new RuleError(`Map literal key is ${describeType(k)} (expected a string).`);
        const v = evalExpr(entry.value, ctx);
        if (isErr(v)) return v;
        out[k] = v;
      }
      return out;
    }
    case 'slice': {
      const t = evalExpr(expr.target, ctx);
      if (isErr(t)) return t;
      const start = evalExpr(expr.start, ctx);
      if (isErr(start)) return start;
      const end = evalExpr(expr.end, ctx);
      if (isErr(end)) return end;
      if (typeof start !== 'number' || typeof end !== 'number' || !Number.isInteger(start) || !Number.isInteger(end)) {
        return new RuleError(`Slice bounds must be integers.`);
      }
      // Production slices lists AND strings, but an out-of-range bound ERRORS
      // (deny) — it does NOT clamp the way JS `.slice()` does (live-pinned by
      // rules-firestore-range-slice-list-and-string: end past length → DENY).
      if (Array.isArray(t) || typeof t === 'string') {
        if (start < 0 || end < start || end > t.length) {
          return new RuleError(`Slice bounds [${start}:${end}] out of range for ${describeType(t)} of size ${t.length}.`);
        }
        return t.slice(start, end);
      }
      return new RuleError(`Slice applied to ${describeType(t)} (expected a list or string).`);
    }
    case 'binary': {
      // RULES-B3: && and || are COMMUTATIVE error-absorbing operators in
      // CEL, not JS left-to-right short-circuit. The two operators differ
      // only in which operand value uniquely determines the result: false
      // for &&, true for ||. Both are evaluated by the one helper below.
      if (expr.op === '&&') return evalAbsorbingOperator(expr.left, expr.right, false, ctx);
      if (expr.op === '||') return evalAbsorbingOperator(expr.left, expr.right, true, ctx);
      const l = evalExpr(expr.left, ctx);
      if (isErr(l)) return l;
      const r = evalExpr(expr.right, ctx);
      if (isErr(r)) return r;
      // Timestamp, Duration, and Bytes operands own their comparison and
      // arithmetic operators; equality stays with rulesEquals below.
      if (expr.op !== '==' && expr.op !== '!=' && (isValueTypeOperand(l) || isValueTypeOperand(r))) {
        return evalValueOperator(expr.op, l, r);
      }
      switch (expr.op) {
        // Lists and maps compare STRUCTURALLY (production `[a] == [a]` is true;
        // JS reference identity would make every literal comparison
        // false). Everything else is strict equality.
        case '==': return rulesEquals(l, r);
        case '!=': return !rulesEquals(l, r);
        case '<':  return cmp(l, r) < 0;
        case '>':  return cmp(l, r) > 0;
        case '<=': return cmp(l, r) <= 0;
        case '>=': return cmp(l, r) >= 0;
        case '+':
        case '-':
        case '*':
        case '/':
        case '%':
          return evalArithmetic(expr.op, l, r);
      }
    }
  }
}

/**
 * Evaluate one commutative error-absorbing operator, `&&` or `||`. The two
 * differ only in `determining`, the operand value that fixes the result on
 * its own: `false` for `&&`, `true` for `||`.
 *
 * If either operand evaluates to `determining`, that is the result and an
 * error in the other operand is absorbed, whichever side it sits on. So
 * `error && false` evaluates to false and `error || true` to true, while
 * `error && true` and `error || false` propagate the error and deny.
 * Laziness is preserved in the no-error path: a determining left operand
 * skips the right one entirely.
 */
function evalAbsorbingOperator(
  left: Expr,
  right: Expr,
  determining: boolean,
  ctx: EvalCtx,
): boolean | RuleError {
  const l = evalLogicalOperand(left, ctx);
  if (l === determining) return determining; // left determines; right unevaluated
  const r = evalLogicalOperand(right, ctx);
  if (r === determining) return determining; // right determines and absorbs any left error
  if (isErr(l)) return l;                    // left errored and nothing determined
  return r;                                  // left was non-determining; right decides
}

/**
 * Evaluate one `&&`/`||` operand tri-state: `true`, `false`, or a
 * {@link RuleError} value the operator may absorb commutatively.
 *
 *   - A thrown ABSORBABLE {@link RuleEvalError} (for example
 *     `firestore.get()` without an injected capability, or `!` on an error)
 *     is converted to an error VALUE here so a determining sibling operand
 *     can absorb it: production evaluates these positions to a
 *     position-local error.
 *   - {@link RuleUnsupportedError} (compile-reject or unmodelable) and
 *     {@link RuleResourceLimitError} (lookup cap, call depth) re-throw:
 *     production fails those closed for the WHOLE evaluation, so no
 *     determining operand may rescue them (the lookup-budget precedent).
 *   - A non-boolean, non-error operand is a CEL TYPE error (RULES-B6,
 *     captured by rules-firestore-strict-boolean-control-flow): it becomes
 *     an absorbable error value, never a truthy/falsy coercion.
 */
function evalLogicalOperand(expr: Expr, ctx: EvalCtx): boolean | RuleError {
  let v: unknown;
  try {
    v = evalExpr(expr, ctx);
  } catch (err) {
    if (isAbsorbableEvalError(err)) return new RuleError(err.message);
    throw err;
  }
  if (isErr(v)) return v;
  if (typeof v !== 'boolean') {
    return new RuleError(`Expected a boolean '&&'/'||' operand, got ${describeType(v)}.`);
  }
  return v;
}

/**
 * Evaluate a bare function call. A function the ruleset declares in scope
 * wins over a global of the same name. Arguments are evaluated in the
 * CALLER's context, then bound to the function's parameters; the body
 * (with any `let` bindings) is evaluated in the function's own lexical
 * scope with fresh locals, so caller path wildcards are not visible except
 * through the arguments passed. An undefined function and a wrong argument
 * count are error values that `&&` and `||` can absorb, as in production.
 */
function evalCall(expr: Extract<Expr, { kind: 'call' }>, ctx: EvalCtx): unknown {
  const fn = ctx.funcs.get(expr.name);
  if (!fn) return evalGlobalCall(expr, ctx);
  // An unresolved import is a construct the evaluator cannot model, so it
  // always fails closed.
  if (fn.unresolvedImport !== undefined) {
    throw new RuleUnsupportedError(
      `function ${expr.name}() is imported from '${fn.unresolvedImport}', but import module resolution is not implemented`,
    );
  }
  if (fn.params.length !== expr.args.length) {
    return new RuleError(
      `Incorrect number of arguments. Received: ${expr.args.length}. Expected: ${expr.name}(${fn.params.join(', ')}).`,
    );
  }
  const depth = ctx.depth + 1;
  if (depth > MAX_CALL_DEPTH) {
    // Resource-limit class: fails the evaluation closed, never absorbed.
    throw new RuleResourceLimitError(
      `function ${expr.name}() exceeded max call depth ${MAX_CALL_DEPTH}`,
    );
  }
  // Arguments: caller context.
  const argVals = expr.args.map((a) => evalExpr(a, ctx));
  const locals: Record<string, unknown> = {};
  fn.params.forEach((p, i) => {
    locals[p] = argVals[i];
  });
  const bodyCtx: EvalCtx = {
    input: ctx.input,
    now: ctx.now,
    params: {}, // no dynamic-scope leakage of caller wildcards
    locals,
    funcs: fn.declScope ?? new Map(),
    depth,
    firestoreLookup: ctx.firestoreLookup,
    firestoreAccesses: ctx.firestoreAccesses,
  };
  // `let` bindings evaluated in order; each is visible to the next and
  // to the return expression (they share the `locals` object).
  for (const b of fn.lets) {
    locals[b.name] = evalExpr(b.value, bodyCtx);
  }
  return evalExpr(fn.body, bodyCtx);
}

/** Evaluate a call to a global function: `path()` or a conversion. */
function evalGlobalCall(expr: Extract<Expr, { kind: 'call' }>, ctx: EvalCtx): unknown {
  if (expr.name === 'path' && expr.args.length === 1) {
    const inner = evalExpr(expr.args[0], ctx);
    if (isErr(inner)) return inner;
    if (typeof inner === 'string') return new StoragePath(inner);
    if (inner instanceof StoragePath) return inner;
    return new RuleError(`path() expects a string, got ${describeType(inner)}.`);
  }
  const conversion = conversionFor(expr.name);
  if (!conversion) return new RuleError(`Function not found error: Name: [${expr.name}].`);
  const args: unknown[] = [];
  for (const arg of expr.args) {
    const value = evalExpr(arg, ctx);
    if (isErr(value)) return value;
    args.push(value);
  }
  return applyConversion(conversion, args);
}
