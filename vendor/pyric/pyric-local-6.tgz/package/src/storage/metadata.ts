/**
 * Metadata types + helpers.
 *
 * Type definitions land in Slice 5 (used by `uploadBytes` for its
 * `SettableMetadata` argument and `UploadResult.metadata` return);
 * the public `getMetadata` / `updateMetadata` operations land in
 * Slice 6 on the back of these same types.
 *
 * The shapes mirror `firebase/storage`'s `FullMetadata` and
 * `SettableMetadata` (survey Section 5) so consumer code typechecks
 * against either implementation. One intentional difference, and one field
 * that depends on the host:
 *
 * - `ref` is omitted from `FullMetadata`. The JS SDK populates it
 *   lazily; we don't need that machinery for the v1 scope.
 * - `downloadTokens` is kept when a host that serves bytes over HTTP mints
 *   one; elsewhere `getDownloadURL` returns a `data:` URI and none exists.
 */
import { emitSandboxEvent, getClock, makeServiceMutationEvent } from 'pyric/sandbox/internal';
import type { EventProvenance } from 'pyric/sandbox';
import { getStorageService, storageAuth, storageOperationProvenance, targetOf } from './service.js';
import { enforceRules } from './enforce.js';
import { resourceFromStored, requestResourceFor } from './sandbox/rules-resources.js';
import { clientContentEncoding, planeOf, type StoragePlane } from './content-defaults.js';
import { objectNotFound, invalidRootOperation } from './errors.js';
import type { StoredMetadata } from './persistence.js';
import type { StorageReference } from './reference.js';

/**
 * Client-settable fields. Passed to `uploadBytes` /
 * `uploadString` / `updateMetadata`. Every field is optional — the
 * upload pipeline fills any unsupplied client fields with sane
 * defaults (e.g. `contentType` falls back to `application/octet-stream`).
 */
export interface SettableMetadata {
  contentType?: string;
  cacheControl?: string;
  contentDisposition?: string;
  contentEncoding?: string;
  contentLanguage?: string;
  customMetadata?: { [key: string]: string };
}

/**
 * Server-set + client-settable fields read back from
 * `uploadBytes` / `getMetadata` / `updateMetadata`. Server-set
 * fields (`bucket`, `fullPath`, `name`, `generation`,
 * `metageneration`, `timeCreated`, `updated`, `size`) are populated
 * by the upload pipeline; client-settable fields round-trip from
 * `SettableMetadata`.
 */
export interface FullMetadata extends SettableMetadata {
  bucket: string;
  fullPath: string;
  name: string;
  generation: string;
  metageneration: string;
  timeCreated: string;
  updated: string;
  size: number;
  md5Hash?: string;
}

/** Return shape of `uploadBytes` / `uploadString`. */
export interface UploadResult {
  metadata: FullMetadata;
  ref: StorageReference;
}

/**
 * Project a `StoredMetadata` (persistence-layer shape) onto the public
 * `FullMetadata` a caller on `plane` reads. A client reads an unset
 * `contentEncoding` as `identity`, as the Firebase Storage endpoint reports
 * it; the admin plane reads the stored record as is.
 */
export function toFullMetadata(stored: StoredMetadata, plane: StoragePlane): FullMetadata {
  if (plane === 'admin') return { ...stored };
  return { ...stored, contentEncoding: clientContentEncoding(stored.contentEncoding) };
}

/**
 * Apply a `SettableMetadata` patch onto an existing
 * `StoredMetadata`, replacing only the client-settable fields. The
 * server-set fields (`bucket`, `fullPath`, `name`, `generation`,
 * `timeCreated`, `size`, `md5Hash`) are preserved. `metageneration`
 * is bumped, and `updated` is refreshed to the call moment — both
 * are server-tracked but driven by client-initiated changes.
 *
 * Used by `updateMetadata` in Slice 6. Defined here in Slice 5 so
 * the types stay close to the rest of the metadata model.
 */
export function applyMetadataPatch(
  base: StoredMetadata,
  patch: SettableMetadata,
  now: Date = new Date(),
): StoredMetadata {
  return {
    ...base,
    // Client-settable fields are REPLACED wholesale per Firebase
    // semantics; passing `undefined` removes the field.
    contentType: patch.contentType ?? base.contentType,
    cacheControl: patch.cacheControl ?? base.cacheControl,
    contentDisposition: patch.contentDisposition ?? base.contentDisposition,
    contentEncoding: patch.contentEncoding ?? base.contentEncoding,
    contentLanguage: patch.contentLanguage ?? base.contentLanguage,
    customMetadata: patch.customMetadata ?? base.customMetadata,
    metageneration: bump(base.metageneration),
    updated: now.toISOString(),
  };
}

/** Bump a base-10 numeric string by 1; `'5'` → `'6'`. */
export function bump(value: string): string {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return '1';
  return String(parsed + 1);
}

// ─── Public operations (Slice 6) ───────────────────────────────────

/**
 * Read the full metadata record at `ref`. Throws when no object
 * exists at the path (`storage/object-not-found`).
 *
 * Mirrors `firebase/storage`'s `getMetadata`. Returns the same
 * `FullMetadata` shape `uploadBytes` produced — server-set fields
 * pinned at upload time, client-settable fields whatever the latest
 * write left them as.
 */
export async function getMetadata(ref: StorageReference): Promise<FullMetadata> {
  guardNonRoot(ref, 'getMetadata');
  const target = targetOf(ref.storage);
  const operationProvenance = storageOperationProvenance(target);
  const service = await getStorageService(ref.storage);
  const stored = await service.backend.getMetadata(ref.fullPath);
  enforceRules(service, {
    request: {
      auth: storageAuth(target),
      method: 'get',
      path: ref.fullPath,
    },
    resource: resourceFromStored(stored),
  }, target, operationProvenance);
  if (!stored) {
    throw objectNotFound(ref.fullPath);
  }
  return toFullMetadata(stored, planeOf(target));
}

/**
 * Update the client-settable metadata at `ref`. Server-set fields
 * (`bucket`, `fullPath`, `name`, `generation`, `timeCreated`,
 * `size`, `md5Hash`) are preserved; `metageneration` bumps and
 * `updated` refreshes. The blob is untouched.
 *
 * Pass `undefined` for a field to leave the previous value in
 * place. To explicitly clear a field, the JS SDK accepts `null` —
 * we don't model that in the v1 scope to keep the patch logic simple.
 * Documented for Slice 9's deferred-features section.
 *
 * `provenance` (host-only): op {@link EventProvenance} bound at ISSUE time,
 * threaded EXPLICITLY onto the emitted `metadata_update` event. Emit runs
 * after the backend awaits, escaping the sandbox's synchronous
 * ambient-provenance window — see the note on `uploadBytes`.
 */
export async function updateMetadata(
  ref: StorageReference,
  patch: SettableMetadata,
  provenance?: EventProvenance,
): Promise<FullMetadata> {
  return rewriteMetadata(ref, 'updateMetadata', (existing, now) => applyMetadataPatch(existing, patch, now), provenance);
}

/**
 * What the admin plane changes in one metadata write, as firebase-admin's
 * `File.setMetadata` does.
 */
export interface AdminMetadataPatch {
  /** Settable fields to replace. Custom metadata is merged through `customMetadata`. */
  settable?: Omit<SettableMetadata, 'customMetadata'>;
  /** Custom keys to set; `null` removes a key. Keys not named stay. */
  customMetadata?: { [key: string]: string | null };
  /** The object's download tokens, or `null` to remove them, which revokes their URLs. */
  downloadTokens?: string | null;
}

/**
 * Merge `patch` into an object's metadata in one write. Rules apply as for
 * `updateMetadata`; the admin plane's handle bypasses them.
 */
export async function patchObjectMetadata(
  ref: StorageReference,
  patch: AdminMetadataPatch,
  provenance?: EventProvenance,
): Promise<FullMetadata> {
  return rewriteMetadata(ref, 'setMetadata', (existing, now) => {
    const next = applyMetadataPatch(existing, patch.settable ?? {}, now);
    const custom = { ...(existing.customMetadata ?? {}) };
    for (const [key, value] of Object.entries(patch.customMetadata ?? {})) {
      if (value === null) delete custom[key];
      else custom[key] = value;
    }
    const hasCustom = Object.keys(custom).length > 0;
    if (hasCustom) next.customMetadata = custom;
    else delete next.customMetadata;
    // `null` removes the tokens, which revokes their URLs.
    const tokens = patch.downloadTokens;
    if (tokens === null) delete next.downloadTokens;
    else if (tokens !== undefined) next.downloadTokens = tokens;
    return next;
  }, provenance);
}

/**
 * Replace an object's metadata with `change(existing)`: `update` rules see the
 * changed view, the backend writes it, and one `metadata_update` event records
 * it. Throws `storage/object-not-found` when the object is absent.
 */
async function rewriteMetadata(
  ref: StorageReference,
  operation: string,
  change: (existing: StoredMetadata, now: Date) => StoredMetadata,
  provenance?: EventProvenance,
): Promise<FullMetadata> {
  guardNonRoot(ref, operation);
  const target = targetOf(ref.storage);
  const operationProvenance = storageOperationProvenance(target, provenance);
  const service = await getStorageService(ref.storage);
  const existing = await service.backend.getMetadata(ref.fullPath);
  const next = existing ? change(existing, getClock(target.sandbox).date()) : undefined;
  enforceRules(service, {
    request: {
      auth: storageAuth(target),
      // The operation always targets an existing object (it throws
      // object-not-found below when absent), so the verb is `update`.
      method: 'update',
      path: ref.fullPath,
      // The changed view drives `request.resource`, with the stored
      // metageneration: production shows the rule the version before this
      // write advances it.
      resource: existing && next
        ? requestResourceFor({ ...next, metageneration: existing.metageneration }, 'metadataUpdate')
        : undefined,
    },
    resource: resourceFromStored(existing),
  }, target, operationProvenance);
  if (!existing || !next) {
    throw objectNotFound(ref.fullPath);
  }
  await service.backend.putMetadata(ref.fullPath, next);
  try {
    emitSandboxEvent(
      target.sandbox,
      makeServiceMutationEvent({
        at: getClock(target.sandbox).now(),
        service: 'storage',
        op: 'metadata_update',
        path: ref.fullPath,
        auth: storageAuth(target),
        before: existing,
        after: next,
        detail: { bucket: ref.bucket },
      }),
      operationProvenance,
    );
  } catch {
    // Observational — never let event emission break a metadata update.
  }
  return toFullMetadata(next, planeOf(target));
}

function guardNonRoot(ref: StorageReference, op: string): void {
  if (ref.fullPath === '') {
    throw invalidRootOperation(op);
  }
}
