/**
 * RulesState — the deployed rules source and its parsed AST (ADR-0009,
 * PR B3, decision 5).
 *
 * One holder for what used to be spread across the engine facade as
 * `rulesSource`, `parsedRulesCache`, and the `rulesAst()` accessor.
 * Shared by the rules-gated read paths (RulesReadEngine's query-proof
 * gate) and the write engine's simulate path.
 *
 * RULES-B11 — the AST cache exists because the query-proof gate needs
 * the matched `list` rule's condition AST on EVERY list read;
 * re-parsing the (unchanging) rules source per read would be O(source)
 * on the listener hot path. Writes, document reads and list residuals
 * evaluate the same cached AST, and the source map beside it, through
 * `simulateParsed`, so no request parses. The cache is keyed on the exact source
 * string so `deployRules` / `seed` invalidate it for free by calling
 * {@link set}.
 */
import {
  compileLimitViolations,
  parseToAST,
  readAuthoredSourceMap,
  type AuthoredSourceMap,
  type FirestoreRules,
} from 'pyric/rules/internal';

import type { TestResult } from 'pyric/rules/internal';
import { captureRulesEvidence, captureQueryEvidence } from './rules-evidence.js';
import type { RulesEvidence } from '../../sandbox/types/rules-evidence.js';

// Diagnostic identity only; rules evaluation also works outside secure contexts.
function rulesVersion(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  return `rules-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}

export class RulesState {
  private version = rulesVersion();

  captureEvidence(result: TestResult, scope: RulesEvidence['scope'] = 'request'): RulesEvidence {
    return captureRulesEvidence(result, this.version, scope);
  }

  captureQueryEvidence(proof: import('../../sandbox/types/query-proof.js').QueryProofDiagnostic, residual?: RulesEvidence): RulesEvidence {
    return captureQueryEvidence(proof, this.version, residual);
  }

  private currentSource: string;

  /**
   * RULES-B11 — parsed-AST cache, keyed on the exact source string.
   * `ast` is `null` when the source doesn't parse or breaks one of
   * production's compile limits (the simulate() call then reports the
   * failure on its own).
   */
  private parsedCache: { source: string; ast: FirestoreRules | null } | null = null;

  /** The source map read from the source, cached on the same key. */
  private sourceMapCache: { source: string; sourceMap: AuthoredSourceMap } | null = null;

  constructor(initialSource: string) {
    this.currentSource = initialSource;
  }

  /** The currently deployed rules source. */
  get source(): string {
    return this.currentSource;
  }

  /**
   * Install a new rules source (seed / deployRules). Cache invalidation
   * is implicit: {@link ast} re-parses when the cached source string no
   * longer matches — installing the byte-identical source keeps the
   * cached AST warm.
   */
  set(source: string): void {
    if (this.currentSource !== source) this.version = rulesVersion();
    this.currentSource = source;
  }

  /**
   * The parsed rules AST for the current source, cached per source
   * string. Returns `null` when the source doesn't parse or production
   * would reject it at compile time, so no request evaluates it.
   */
  ast(): FirestoreRules | null {
    if (this.parsedCache?.source !== this.currentSource) {
      const parsed = parseToAST(this.currentSource);
      this.parsedCache = {
        source: this.currentSource,
        ast: parsed && compileLimitViolations(parsed).length === 0 ? parsed : null,
      };
    }
    return this.parsedCache.ast;
  }

  /**
   * The authored-location source map embedded in the current source,
   * read once per source string. Empty when the source carries none.
   */
  sourceMap(): AuthoredSourceMap {
    if (this.sourceMapCache?.source !== this.currentSource) {
      this.sourceMapCache = {
        source: this.currentSource,
        sourceMap: readAuthoredSourceMap(this.currentSource),
      };
    }
    return this.sourceMapCache.sourceMap;
  }
}
