/**
 * `StorageError` — the sandbox's analog of `firebase/storage`'s
 * `StorageError`. Every sandbox operation that fails throws one of
 * these so `err.code === 'storage/...'` branching matches the canonical
 * Firebase-shaped application contract (ST-B1).
 *
 * Shape parity with upstream (`clones/firebase-js-sdk/packages/
 * storage/src/implementation/error.ts`):
 *   - `.code` is the prefixed form `storage/<code>` (e.g.
 *     `storage/object-not-found`).
 *   - the message embeds the prefixed code so the substring-matching
 *     probes (`toThrow(/object-not-found/)`) and `err.code` reads
 *     agree.
 *
 * Intentional divergence (documented in COMPAT row 105): upstream's
 * `StorageError extends FirebaseError` and reports `name:
 * 'FirebaseError'` with a `"Firebase Storage: … (storage/…)"`
 * message. The sandbox keeps a plain `Error` subclass — same as
 * `SandboxError` for Firestore — so the `.code` contract is faithful
 * while the message wording stays sandbox-flavored. The
 * `storage/<code>` prefix is what consumer code branches on.
 */
import { asSentence } from 'pyric/sandbox/internal';

/** Unprefixed Firebase Storage error codes. */
export const StorageErrorCode = {
  UNKNOWN: "unknown",
  OBJECT_NOT_FOUND: "object-not-found",
  BUCKET_NOT_FOUND: "bucket-not-found",
  PROJECT_NOT_FOUND: "project-not-found",
  QUOTA_EXCEEDED: "quota-exceeded",
  UNAUTHENTICATED: "unauthenticated",
  UNAUTHORIZED: "unauthorized",
  UNAUTHORIZED_APP: "unauthorized-app",
  RETRY_LIMIT_EXCEEDED: "retry-limit-exceeded",
  INVALID_CHECKSUM: "invalid-checksum",
  CANCELED: "canceled",
  INVALID_EVENT_NAME: "invalid-event-name",
  INVALID_URL: "invalid-url",
  INVALID_DEFAULT_BUCKET: "invalid-default-bucket",
  NO_DEFAULT_BUCKET: "no-default-bucket",
  CANNOT_SLICE_BLOB: "cannot-slice-blob",
  SERVER_FILE_WRONG_SIZE: "server-file-wrong-size",
  NO_DOWNLOAD_URL: "no-download-url",
  INVALID_ARGUMENT: "invalid-argument",
  INVALID_ARGUMENT_COUNT: "invalid-argument-count",
  APP_DELETED: "app-deleted",
  INVALID_ROOT_OPERATION: "invalid-root-operation",
  INVALID_FORMAT: "invalid-format",
  INTERNAL_ERROR: "internal-error",
  UNSUPPORTED_ENVIRONMENT: "unsupported-environment",
} as const;
export type StorageErrorCode = (typeof StorageErrorCode)[keyof typeof StorageErrorCode];

/** Prefix an unprefixed code with `storage/` — matches upstream. */
export function prependCode(code: StorageErrorCode): `storage/${StorageErrorCode}` {
  return `storage/${code}`;
}

/**
 * Storage error carrying a prefixed `storage/<code>` on `.code`.
 * Drop-in for `err.code === 'storage/object-not-found'` branching.
 */
export class StorageError extends Error {
  /** Prefixed code, e.g. `storage/object-not-found`. */
  readonly code: `storage/${StorageErrorCode}`;

  constructor(code: StorageErrorCode, message: string) {
    const prefixed = prependCode(code);
    // The prefixed code is embedded so substring probes and `.code`
    // reads see the same value.
    super(`${prefixed}: ${message}`);
    this.name = 'StorageError';
    this.code = prefixed;
    // Mirror upstream's prototype pin so `instanceof StorageError`
    // survives the transpile-to-ES5-class-extends pattern.
    Object.setPrototypeOf(this, StorageError.prototype);
  }
}

// ─── Factory helpers (mirror upstream's error.ts free functions) ────

export function objectNotFound(path: string): StorageError {
  return new StorageError('object-not-found', `no object at "${path}".`);
}

export function unauthorized(method: string, path: string, detail: string): StorageError {
  return new StorageError(
    'unauthorized',
    asSentence(`${method} "${path}" denied by rules${detail}`),
  );
}

export function quotaExceeded(path: string, size: number, max: number): StorageError {
  // Kept for StorageErrorCode parity. maxDownloadSizeBytes truncates
  // (COMPAT #55); this factory is unused by download paths today.
  return new StorageError(
    'quota-exceeded',
    `object at "${path}" is ${size} bytes, exceeds maxDownloadSizeBytes ${max}.`,
  );
}

export function invalidRootOperation(op: string): StorageError {
  return new StorageError(
    'invalid-root-operation',
    `${op} cannot operate on the root reference.`,
  );
}

export function invalidFormat(format: string, message: string): StorageError {
  return new StorageError('invalid-format', `string does not match format "${format}": ${message}`);
}

export function uploadCanceled(): StorageError {
  return new StorageError('canceled', 'User canceled the upload/download.');
}
