/**
 * Service module — sandbox handles and factories.
 *
 * The public `FirebaseStorage` handle is opaque — it carries a
 * `TARGET_SYMBOL` field pointing to the sandbox state every operation
 * needs (IDB service, rules, identity, bucket, and admin lens).
 *
 * Caching:
 *
 * - **Per `Sandbox`** — the IDB-backed `StorageService` is shared.
 *   Two `getStorageSandbox` calls on the same sandbox hit the same
 *   backend.
 * - **Per `SandboxContext`** — the sandbox `FirebaseStorage` handle
 *   is identity-stable. `getStorageSandbox(ctx)` twice returns the
 *   same object.
 * Internal access:
 *
 * `getStorageService(storage)` returns the backing
 * `Promise<StorageService>` for sandbox handles.
 */
import { SandboxContextImpl } from 'pyric/sandbox';
import type { AuthState, EventProvenance, Sandbox, SandboxContext } from 'pyric/sandbox';
import type { FirebaseApp } from '../app/types.js';
import {
  bindOperationContext,
  provenanceForOperationContext,
  resolveOperationContext,
} from 'pyric/sandbox/internal';
import { openStorageBackend, storageDbName, type StorageBackend } from './persistence.js';
import { StorageService, type CrossServiceIam } from './sandbox/running-service.js';
import type { StorageRules } from './sandbox/rules.js';
import {
  compileStorageRules,
  type StorageRulesResolution,
} from './rules-resolution.js';

/**
 * Default sandbox bucket identifier. v1 has a single implicit
 * bucket; the field is recorded on every uploaded metadata record
 * so consumer code can round-trip it.
 */
const DEFAULT_BUCKET = 'pyric-default';

/**
 * Hidden property on every {@link FirebaseStorage} handle. Carries
 * the sandbox state free functions share without exposing it publicly.
 */
export const TARGET_SYMBOL: unique symbol = Symbol('pyric/storage/target');

/**
 * Sandbox target — IDB-backed, identity from `SandboxContext`, rules
 * enforced in-process via `enforce.ts`.
 */
export interface SandboxTarget {
  readonly kind: 'sandbox';
  readonly sandbox: Sandbox;
  readonly context: SandboxContext;
  /** App handles resolve auth at operation time; explicit contexts stay frozen. */
  readonly currentAuth?: () => AuthState;
  readonly bucket: string;
  readonly servicePromise: Promise<StorageService>;
  /**
   * Rules-bypass admin plane. `true` only on handles minted by the
   * INTERNAL {@link getAdminStorageSandbox} factory (exported via
   * `pyric/storage/internal`, never the public surface): operations
   * on an admin handle skip rule evaluation entirely — the storage
   * mirror of `getAdminFirestore` / `getAdminDatabase`. The public
   * modular surface stays rules-honest; this exists so hosts (the
   * SharedWorker's `actAs: { mode: 'admin' }` lens) can serve
   * firebase-admin semantics against the same shared store.
   */
  readonly admin?: boolean;
}

export type Target = SandboxTarget;

export function storageAuth(target: SandboxTarget): AuthState {
  return target.currentAuth?.() ?? target.context.auth;
}

/**
 * Public opaque handle. Carries a {@link Target} via
 * {@link TARGET_SYMBOL}; never inspected by consumer code, which
 * interacts with storage only through {@link ref} and the operation
 * free functions.
 */
export interface FirebaseStorage {
  readonly [TARGET_SYMBOL]: Target;
  readonly app?: FirebaseApp;
}

/** Storage handle returned by Firebase-shaped app overloads. */
export type AppFirebaseStorage = FirebaseStorage & { readonly app: FirebaseApp };

export { StorageService, type CrossServiceIam } from './sandbox/running-service.js';

/** Options for {@link getStorageSandbox}. */
export interface StorageOptions {
  /**
   * Bucket identifier recorded on uploaded metadata and used to isolate
   * storage persistence across multiple buckets.
   */
  bucket?: string;
  /**
   * Override the IndexedDB database name. Tests pass per-case unique
   * names so state doesn't leak between runs.
   * Only takes effect on the FIRST call per `Sandbox`.
   */
  dbName?: string;
  /**
   * Project identity used to derive the default IndexedDB database name
   * (`pyric-storage:<projectId>` — see {@link storageDbName}). IndexedDB is
   * origin-scoped, so without this every project served on the same
   * localhost port shared one storage database (issue #359). Ignored when
   * an explicit `dbName` is given; only honored on the FIRST call per
   * `Sandbox`. Hosts pass their project identity here (`pyric sandbox` passes
   * the served project's key; app handles pass `options.projectId`).
   */
  projectId?: string;
  /**
   * Storage rules source. Parsed eagerly so a malformed string
   * throws at config time. Only honored on the FIRST call per
   * `Sandbox`.
   */
  rules?: string;
  /**
   * Model the production Storage→Firestore IAM dependency (see
   * {@link CrossServiceIam}). Defaults to `'granted'`. Like `rules`,
   * only honored on the FIRST storage call per `Sandbox`; a LATER,
   * DIFFERING value throws instead of silently flipping the mode.
   */
  crossServiceIam?: CrossServiceIam;
}

// ─── Caches ─────────────────────────────────────────────────────────

/**
 * Everything one `Sandbox` opened its storage service WITH, in one record.
 * These four facts are written together on the first storage call and read
 * together afterwards, so they live in one map rather than four parallel
 * ones that can drift out of step.
 */
interface OpenStorageService {
  /** The service itself, resolving once its IndexedDB backend is open. */
  readonly service: Promise<StorageService>;
  /** The rules source it was opened with, `null` when opened without rules. */
  readonly rulesSource: string | null;
  /** The module-resolution record for that source, `null` without rules. */
  readonly rulesResolution: StorageRulesResolution | null;
  /** The cross-service IAM mode it was opened with. */
  readonly crossServiceIam: CrossServiceIam;
}

/** One open storage service, with its opening configuration, per `Sandbox`. */
const OPEN_SERVICES = new WeakMap<Sandbox, OpenStorageService>();
const HOST_BACKENDS = new WeakMap<Sandbox, StorageBackend>();

/** Hosts install their durable backend before any Storage service is created. */
export function installStorageBackend(sandbox: Sandbox, backend: StorageBackend): void {
  const alreadyOpened = OPEN_SERVICES.has(sandbox) || HOST_BACKENDS.has(sandbox);
  if (alreadyOpened) throw new Error('Storage backend must be installed once, before Storage initializes.');
  HOST_BACKENDS.set(sandbox, backend);
}

/** One scoped `StorageService` per (Sandbox, bucket). */
const SCOPED_SERVICES = new WeakMap<Sandbox, Map<string, Promise<StorageService>>>();

function getOrCreateScopedService(
  sandbox: Sandbox,
  bucket: string,
  rootServicePromise: Promise<StorageService>,
): Promise<StorageService> {
  let bucketMap = SCOPED_SERVICES.get(sandbox);
  if (!bucketMap) {
    bucketMap = new Map();
    SCOPED_SERVICES.set(sandbox, bucketMap);
  }
  let existing = bucketMap.get(bucket);
  if (!existing) {
    existing = rootServicePromise.then((rootService) => {
      const backend = rootService.backend.scoped
        ? rootService.backend.scoped(bucket)
        : rootService.backend;
      return new StorageService(backend, rootService.rules, rootService.crossServiceIam);
    });
    bucketMap.set(bucket, existing);
  }
  return existing;
}

/** Sandbox `FirebaseStorage` handles cached per `(SandboxContext, bucket)`. */
const SANDBOX_HANDLES = new WeakMap<SandboxContext, Map<string, FirebaseStorage>>();

/**
 * Anonymous handles cached per `(Sandbox, bucket)`. `Sandbox.withAuth(null)`
 * mints a FRESH `SandboxContext` on every call, so the per-context
 * cache above would miss for the bare-`Sandbox` convenience path —
 * `getStorageSandbox(sandbox)` twice returned two different handles
 * (ST-B3). Caching on the `Sandbox` keeps that path identity-stable,
 * matching the documented "handle is identity-stable per Sandbox".
 */
const BARE_SANDBOX_HANDLES = new WeakMap<Sandbox, Map<string, FirebaseStorage>>();

/**
 * Reject a late option that differs from the one the service is already
 * open with. Both `rules` and `crossServiceIam` are honored only on the
 * FIRST storage call per `Sandbox`. Silently discarding a later, differing
 * value would wipe the rules, or reopen the false-ALLOW surface the IAM
 * mode models, without a word. Re-supplying the IDENTICAL value stays fine
 * (idempotent multi-handle construction, for example per-user contexts),
 * and so does omitting it.
 */
function rejectDifferingLateConfig(
  option: string,
  descriptor: string,
  supplied: string | undefined,
  openedWith: string | null,
  caller: string,
): void {
  if (supplied === undefined || supplied === openedWith) return;
  const openedDescription = openedWith === null
    ? `without ${option}`
    : `with a different ${descriptor}`;
  throw new Error(
    `pyric/storage: ${caller} received a ${descriptor}, but this sandbox's storage service ` +
      `is already open ${openedDescription}. ${option} is honored only on the FIRST storage ` +
      'call per Sandbox, so this value would be silently discarded. Configure it on the first ' +
      'storage call for this sandbox.',
  );
}

/**
 * Install a new ruleset into a sandbox's storage service, replacing whatever
 * it is enforcing.
 *
 * This is the deliberate counterpart to the late-config guard in
 * {@link ensureService}. That guard exists because a `rules` option passed to
 * a FACTORY after the service is open would be silently discarded, and a
 * caller asking for a handle has not asked to change the ruleset. Here the
 * caller has asked for exactly that and nothing is discarded: the source is
 * compiled first, so a source that does not parse throws and leaves the
 * ruleset in force untouched, and the factory guard is unchanged, so the
 * served-app path still refuses a late differing option.
 *
 * A null source removes the ruleset, the state a service opened without
 * rules is in: every client operation is denied. A service that is not open
 * yet is left to open as its first storage call configures it.
 *
 * The new ruleset reaches the root service and every per-bucket scoped
 * service, because each holds its own reference to the parsed rules.
 */
export async function replaceStorageRules(sandbox: Sandbox, source: string | null): Promise<void> {
  const compiled = source === null ? { rules: null, resolution: null } : compileStorageRules(source);
  const open = OPEN_SERVICES.get(sandbox);
  if (open === undefined) {
    if (source === null) return;
    await ensureService(sandbox, { rules: source }, 'replaceStorageRules');
    return;
  }
  OPEN_SERVICES.set(sandbox, {
    service: open.service,
    rulesSource: source,
    rulesResolution: compiled.resolution,
    crossServiceIam: open.crossServiceIam,
  });
  const root = await open.service;
  root.rules = compiled.rules;
  for (const scopedPromise of SCOPED_SERVICES.get(sandbox)?.values() ?? []) {
    const scoped = await scopedPromise;
    scoped.rules = compiled.rules;
  }
}

/**
 * The cross-service IAM posture a sandbox's storage service is running under.
 *
 * A sandbox whose storage service has never been opened reports the default a
 * first open would take, so a reader gets the mode that is in force rather
 * than an absence it has to interpret.
 */
export function getStorageCrossServiceIam(sandbox: Sandbox): CrossServiceIam {
  return OPEN_SERVICES.get(sandbox)?.crossServiceIam ?? 'granted';
}

/**
 * Move a sandbox's storage service between the granted and denied
 * cross-service IAM states, replacing whatever it is enforcing.
 *
 * This is the deliberate counterpart to the late-config guard in
 * {@link ensureService}, on the same argument that gives
 * {@link replaceStorageRules} its exception: a `crossServiceIam` option passed
 * to a FACTORY after the service is open would be silently discarded, and a
 * caller asking for a handle has not asked to change the project's IAM
 * posture. Here the caller has asked for exactly that.
 *
 * The new mode reaches the root service and every per-bucket scoped service,
 * because each holds its own reference to it.
 */
export async function replaceCrossServiceIam(
  sandbox: Sandbox,
  mode: CrossServiceIam,
): Promise<void> {
  const open = OPEN_SERVICES.get(sandbox);
  if (open === undefined) {
    await ensureService(sandbox, { crossServiceIam: mode }, 'replaceCrossServiceIam');
    return;
  }
  OPEN_SERVICES.set(sandbox, {
    service: open.service,
    rulesSource: open.rulesSource,
    rulesResolution: open.rulesResolution,
    crossServiceIam: mode,
  });
  const root = await open.service;
  root.crossServiceIam = mode;
  for (const scopedPromise of SCOPED_SERVICES.get(sandbox)?.values() ?? []) {
    const scoped = await scopedPromise;
    scoped.crossServiceIam = mode;
  }
}

/**
 * Get (or open) the ONE per-sandbox `StorageService`. Loud on the
 * silent-rules-wipe hazard: when the service is already open and the
 * caller supplies a `rules` source differing from the one it was opened
 * with (including "opened without rules"), this throws — configure rules
 * on the first storage call for the sandbox instead.
 */
function ensureService(
  sandbox: Sandbox,
  options: StorageOptions,
  caller: string,
): Promise<StorageService> {
  const existing = OPEN_SERVICES.get(sandbox);
  const alreadyOpen = existing !== undefined;
  if (alreadyOpen) {
    rejectDifferingLateConfig(
      'rules',
      'rules source',
      options.rules,
      existing.rulesSource,
      caller,
    );
    rejectDifferingLateConfig(
      'crossServiceIam',
      'crossServiceIam mode',
      options.crossServiceIam,
      existing.crossServiceIam,
      caller,
    );
    return existing.service;
  }
  let rules: StorageRules | null = null;
  let resolution: StorageRulesResolution | null = null;
  const rulesSource = options.rules;
  const hasRules = typeof rulesSource === 'string' && rulesSource.length > 0;
  if (hasRules) {
    const compiled = compileStorageRules(rulesSource);
    rules = compiled.rules;
    resolution = compiled.resolution;
  }
  // Explicit dbName wins; otherwise scope the default by project identity so
  // two projects on one origin never share a storage database (issue #359).
  const crossServiceIam = options.crossServiceIam ?? 'granted';
  const injectedBackend = HOST_BACKENDS.get(sandbox);
  let backendPromise: Promise<StorageBackend>;
  const hasInjectedBackend = injectedBackend !== undefined;
  if (hasInjectedBackend) backendPromise = Promise.resolve(injectedBackend);
  else {
    backendPromise = openStorageBackend(
      options.dbName ?? storageDbName(options.projectId),
      options.bucket ?? DEFAULT_BUCKET,
    );
  }
  const servicePromise = backendPromise.then(
    (backend) => new StorageService(backend, rules, crossServiceIam),
  );
  OPEN_SERVICES.set(sandbox, {
    service: servicePromise,
    rulesSource: options.rules ?? null,
    rulesResolution: resolution,
    crossServiceIam,
  });
  // Join the sandbox's persistable-service REGISTRY so `sandbox.resetAll()`
  // reaches storage (issue #359: Studio's reset cleared Firestore + auth but
  // never storage — storage was invisible to the sandbox). Storage does NOT
  // ride the persistence blob: it owns its durability (IndexedDB), and blobs
  // aren't JSON-serializable — so snapshot/restore are deliberate no-ops and
  // `reset` is the only live hook (clears both IDB object stores).
  sandbox.registerPersistableService('storage', {
    snapshot: () => null,
    restore: () => {},
    reset: async () => {
      const service = await servicePromise;
      await service.backend.reset();
    },
  });
  return servicePromise;
}

/**
 * Type predicate distinguishing `SandboxContext` from `Sandbox`. We
 * use the class-identity test (every real `SandboxContext` is a
 * `SandboxContextImpl`) so the TS narrowing works downstream.
 */
function isContext(target: Sandbox | SandboxContext): target is SandboxContext {
  return target instanceof SandboxContextImpl;
}

/**
 * Construct (or return cached) a sandbox-backed `FirebaseStorage`
 * handle. Accepts either a bare `Sandbox` (anonymous identity wired
 * up via `sandbox.withAuth(null)`) or an explicit `SandboxContext`.
 * Idempotent on `SandboxContext` identity.
 */
export function getStorageSandbox(
  target: Sandbox | SandboxContext,
  options: StorageOptions = {},
): FirebaseStorage {
  const fromBareSandbox = !isContext(target);
  const sandbox: Sandbox = isContext(target) ? target.sandbox : target;

  // Open (or fetch) the ONE per-sandbox service FIRST — before any handle
  // cache fast-path — so a late, differing `rules` option throws instead of
  // being silently discarded (see ensureService).
  const rootServicePromise = ensureService(sandbox, options, 'getStorageSandbox');
  const bucket = options.bucket ?? DEFAULT_BUCKET;

  // Fast path: a repeat bare-`Sandbox` call returns the cached
  // anonymous handle for the requested bucket.
  if (fromBareSandbox) {
    const cachedBare = BARE_SANDBOX_HANDLES.get(sandbox)?.get(bucket);
    if (cachedBare) return cachedBare;
  }

  const ctx = isContext(target) ? target : target.withAuth(null);
  const cached = SANDBOX_HANDLES.get(ctx)?.get(bucket);
  if (cached) return cached;

  const servicePromise = getOrCreateScopedService(sandbox, bucket, rootServicePromise);

  const sandboxTarget: SandboxTarget = {
    kind: 'sandbox',
    sandbox,
    context: ctx,
    currentAuth: fromBareSandbox ? () => sandbox.currentUser : undefined,
    bucket,
    servicePromise,
  };
  const handle: FirebaseStorage = Object.freeze({ [TARGET_SYMBOL]: sandboxTarget });

  let ctxMap = SANDBOX_HANDLES.get(ctx);
  if (!ctxMap) {
    ctxMap = new Map();
    SANDBOX_HANDLES.set(ctx, ctxMap);
  }
  ctxMap.set(bucket, handle);

  if (fromBareSandbox) {
    let bareMap = BARE_SANDBOX_HANDLES.get(sandbox);
    if (!bareMap) {
      bareMap = new Map();
      BARE_SANDBOX_HANDLES.set(sandbox, bareMap);
    }
    bareMap.set(bucket, handle);
  }
  return handle;
}

/** Admin handles are cached by bound context so Studio, agent, and
 * unattributed callers can share storage state without sharing provenance. */
const ADMIN_CONTEXT_HANDLES = new WeakMap<SandboxContext, Map<string, FirebaseStorage>>();
const BARE_ADMIN_HANDLES = new WeakMap<Sandbox, Map<string, FirebaseStorage>>();

/**
 * INTERNAL (exported via `pyric/storage/internal` only) — construct
 * (or return cached) the rules-BYPASS admin `FirebaseStorage` handle
 * for a sandbox or bound context. Shares the SAME `StorageService` (one IDB store, one
 * ruleset) as every rules-honest handle on that sandbox; only rule
 * evaluation is skipped (see {@link SandboxTarget.admin}). Bucket /
 * dbName / rules options follow the same first-call-per-`Sandbox`
 * semantics as {@link getStorageSandbox}.
 *
 * This is the storage mirror of `getAdminFirestore` /
 * `getAdminDatabase` — the handle the SharedWorker host resolves for
 * `actAs: { mode: 'admin' }` storage ops (firebase-admin semantics
 * over the bridge). Deliberately NOT on the public `pyric/storage`
 * surface so the modular API stays rules-honest.
 */
export function getAdminStorageSandbox(
  target: Sandbox | SandboxContext,
  options: StorageOptions = {},
): FirebaseStorage {
  const fromBareSandbox = !isContext(target);
  const sandbox = isContext(target) ? target.sandbox : target;
  // Service first (late differing `rules` must throw, even on a cache hit).
  const rootServicePromise = ensureService(sandbox, options, 'getAdminStorageSandbox');
  const bucket = options.bucket ?? DEFAULT_BUCKET;

  if (fromBareSandbox) {
    const cachedBare = BARE_ADMIN_HANDLES.get(sandbox)?.get(bucket);
    if (cachedBare) return cachedBare;
  }

  const baseContext = isContext(target) ? target : sandbox.withAuth(null);
  const context = baseContext.operationContext.authLens.mode === 'admin'
    ? baseContext
    : bindOperationContext(baseContext, {
        source: baseContext.operationContext.source,
        authLens: { mode: 'admin' },
        ...(baseContext.operationContext.planId === undefined
          ? {}
          : { planId: baseContext.operationContext.planId }),
      });
  const cached = ADMIN_CONTEXT_HANDLES.get(baseContext)?.get(bucket);
  if (cached) return cached;

  const servicePromise = getOrCreateScopedService(sandbox, bucket, rootServicePromise);

  const sandboxTarget: SandboxTarget = {
    kind: 'sandbox',
    sandbox,
    context,
    bucket,
    servicePromise,
    admin: true,
  };
  const handle: FirebaseStorage = Object.freeze({ [TARGET_SYMBOL]: sandboxTarget });

  let ctxMap = ADMIN_CONTEXT_HANDLES.get(baseContext);
  if (!ctxMap) {
    ctxMap = new Map();
    ADMIN_CONTEXT_HANDLES.set(baseContext, ctxMap);
  }
  ctxMap.set(bucket, handle);

  if (fromBareSandbox) {
    let bareMap = BARE_ADMIN_HANDLES.get(sandbox);
    if (!bareMap) {
      bareMap = new Map();
      BARE_ADMIN_HANDLES.set(sandbox, bareMap);
    }
    bareMap.set(bucket, handle);
  }
  return handle;
}

/** Merge a host override with the immutable provenance bound to a Storage
 * handle. The result is captured before awaits, so concurrent async
 * operations cannot exchange source or auth-lens identity. */
export function storageOperationProvenance(
  target: SandboxTarget,
  override?: EventProvenance,
): EventProvenance {
  const context = resolveOperationContext(
    override,
    provenanceForOperationContext(target.context.operationContext),
  );
  return {
    ...override,
    ...provenanceForOperationContext(context),
    service: 'storage',
  };
}

/** Return an operation-scoped view of a Storage handle. The backing service,
 * bucket, and admin/rules mode are shared; only immutable operation identity is
 * rebound. Worker hosts use this internal seam instead of extending Firebase's
 * public function signatures with host-only provenance arguments. */
export function bindStorageOperationContext(
  storage: FirebaseStorage,
  provenance: EventProvenance | undefined,
): FirebaseStorage {
  if (!provenance) return storage;
  const target = targetOf(storage);
  const context = resolveOperationContext(
    provenance,
    provenanceForOperationContext(target.context.operationContext),
  );
  const scopedTarget: SandboxTarget = {
    ...target,
    context: bindOperationContext(target.context, context),
  };
  return Object.freeze({ [TARGET_SYMBOL]: scopedTarget });
}

/**
 * Internal — extract the {@link Target} from a handle. Throws on
 * objects that weren't produced by a factory in this module.
 */
export function targetOf(storage: FirebaseStorage): Target {
  const t = (storage as { [TARGET_SYMBOL]?: Target })[TARGET_SYMBOL];
  if (!t) {
    throw new TypeError(
      'pyric/storage: not a FirebaseStorage handle — was it produced by getStorageSandbox?',
    );
  }
  return t;
}

/**
 * Internal — fetch the backing `StorageService` promise for a sandbox handle.
 */
export function getStorageService(storage: FirebaseStorage): Promise<StorageService> {
  return targetOf(storage).servicePromise;
}

/** Internal assurance seam for the exact rules source retained by Storage setup. */
export function getStorageRulesResolution(
  storage: FirebaseStorage,
): StorageRulesResolution | null {
  return OPEN_SERVICES.get(targetOf(storage).sandbox)?.rulesResolution ?? null;
}
