import type {
  FirestoreRules, MatchBlock, AllowRule, FunctionDef, Expression, Operation,
} from './FirestoreAST.js';
import { countDocumentAccessCalls } from './document-access-count.js';
import { compileLimitViolations } from './compile-limits.js';
import {
  collectRulesetScopes, functionReferences, ruleReferences,
  type NameReferences, type RulesetScopes,
} from './function-scopes.js';

export interface ValidationFinding {
  code: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  path: string;
  operation?: string;
  message: string;
}

const WRITE_OPS: Set<Operation> = new Set(['write', 'create', 'update', 'delete']);
const READ_OPS: Set<Operation> = new Set(['read', 'get', 'list']);
const DATA_WRITE_OPS: Set<Operation> = new Set(['create', 'update']);

export function validateFirestoreRules(ast: FirestoreRules): ValidationFinding[] {
  const findings: ValidationFinding[] = [];
  const rootMatch = ast.service.match;

  // Global and service scope functions are visible in every match block.
  const outerScope = [...(ast.functions ?? []), ...(ast.service.functions ?? [])];
  const scopes = collectRulesetScopes(ast);

  // SEC-4: Check for default deny
  checkDefaultDeny(rootMatch, findings);

  // QUA-3: Duplicate function names in one scope (production compile
  // rejection, so critical). Nested shadowing is legal and is not flagged.
  checkDuplicateFunctions(ast, findings);

  // SEM-4, SEM-5, QUA-4: names resolved by declaration scope
  checkNameResolution(scopes, findings);

  // STR-3: Overlapping match paths
  checkOverlappingPaths(rootMatch.children, findings);

  // Walk all match blocks
  walkMatch(rootMatch, findings, outerScope);

  return findings;
}

function walkMatch(
  match: MatchBlock,
  findings: ValidationFinding[],
  scopeFunctions: FunctionDef[],
) {
  const isRecursiveWildcard = match.path.segments.some(s => s.type === 'recursive');
  const pathStr = match.path.raw;

  // Merge scope: parent functions + this match's functions
  const localScope = [...scopeFunctions, ...match.functions];

  for (const allow of match.allows) {
    const ops = allow.operations;
    // Fold semantically-constant conditions (e.g. `X || true`, `X && false`,
    // `!true`, ternaries with literal conditions) before the literal checks and
    // the auth/data-reference walks, so tautological rules can't evade SEC-1/2/3
    // and QUA-1 by being written as a binaryOp instead of a bare `true`/`false`.
    const cond = foldConstants(allow.condition);
    const isWrite = ops.some(op => WRITE_OPS.has(op));
    const isRead = ops.some(op => READ_OPS.has(op));
    const isDataWrite = ops.some(op => DATA_WRITE_OPS.has(op));
    const isLiteralTrue = cond.type === 'literal' && cond.value === true;
    const isLiteralFalse = cond.type === 'literal' && cond.value === false;
    const opStr = ops.join(', ');

    // SEC-1: Public write
    if (isWrite && isLiteralTrue) {
      findings.push({
        code: 'SEC-1', severity: 'critical', path: pathStr, operation: opStr,
        message: `Public write at ${pathStr} — anyone can ${opStr} without authentication`,
      });
    }

    // SEC-2: Public read at recursive wildcard
    if (isRead && isLiteralTrue && isRecursiveWildcard) {
      findings.push({
        code: 'SEC-2', severity: 'critical', path: pathStr, operation: opStr,
        message: `Public read at recursive wildcard ${pathStr} — entire database is readable`,
      });
    }

    // SEC-5: Overly permissive recursive wildcard
    if (isRecursiveWildcard && !isLiteralFalse) {
      findings.push({
        code: 'SEC-5', severity: 'high', path: pathStr, operation: opStr,
        message: `Recursive wildcard ${pathStr} has a non-deny rule — overrides all specific rules`,
      });
    }

    // SEC-3: No auth check on write (follows function calls transitively)
    const fnMap = new Map(localScope.map(f => [f.name, f]));
    if (isWrite && !isLiteralTrue && !isLiteralFalse && !referencesAuthTransitive(cond, fnMap)) {
      findings.push({
        code: 'SEC-3', severity: 'high', path: pathStr, operation: opStr,
        message: `Write rule at ${pathStr} does not check request.auth`,
      });
    }

    // SEC-6: Write without data validation (follows function calls transitively)
    if (isDataWrite && !isLiteralFalse && !referencesRequestDataTransitive(cond, fnMap)) {
      findings.push({
        code: 'SEC-6', severity: 'high', path: pathStr, operation: opStr,
        message: `${opStr} at ${pathStr} does not validate request.resource.data — any data shape accepted`,
      });
    }

    // SEM-1: request.resource.data in read rule
    if (isRead && !isWrite && referencesRequestData(cond)) {
      findings.push({
        code: 'SEM-1', severity: 'high', path: pathStr, operation: opStr,
        message: `Read rule at ${pathStr} references request.resource.data which is not available on reads`,
      });
    }

    // SEM-2: resource.data in create rule
    if (ops.includes('create') && !ops.includes('update') && referencesResourceData(cond)) {
      findings.push({
        code: 'SEM-2', severity: 'high', path: pathStr, operation: opStr,
        message: `Create rule at ${pathStr} references resource.data but document doesn't exist yet on create`,
      });
    }

    // SEM-3: document access budget exceeded. Production allows exactly 10
    // get/exists/getAfter/existsAfter reads per request evaluation; the
    // 11th fails, so the finding fires only ABOVE 10 (same boundary as the
    // linter's GET_COUNT error and the simulator's runtime LookupBudget).
    const docReads = countDocumentAccessCalls(cond, fnMap);
    if (docReads > 10) {
      findings.push({
        code: 'SEM-3', severity: 'high', path: pathStr, operation: opStr,
        message: `Rule at ${pathStr} may perform ${docReads} document access calls (get/exists/getAfter/existsAfter), which exceeds the 10-call budget`,
      });
    }

    // QUA-1: Hardcoded true
    if (isLiteralTrue) {
      const severity = isWrite ? 'critical' as const : 'low' as const;
      findings.push({
        code: 'QUA-1', severity, path: pathStr, operation: opStr,
        message: `Hardcoded 'true' at ${pathStr} for ${opStr}`,
      });
    }

    // QUA-5: Complex condition
    if (exprDepth(cond) > 10) {
      findings.push({
        code: 'QUA-5', severity: 'low', path: pathStr, operation: opStr,
        message: `Condition at ${pathStr} has depth ${exprDepth(cond)} — consider splitting into functions`,
      });
    }
  }

  // QUA-2: Empty match block
  if (match.allows.length === 0 && match.children.length === 0 && match.functions.length === 0) {
    findings.push({
      code: 'QUA-2', severity: 'low', path: pathStr,
      message: `Match block at ${pathStr} is empty — no allows, children, or functions`,
    });
  }

  // STR-1: Match without wildcard
  if (match.path.segments.every(s => s.type === 'literal')) {
    findings.push({
      code: 'STR-1', severity: 'low', path: pathStr,
      message: `Match at ${pathStr} has no wildcard — matches exactly one document`,
    });
  }

  // STR-2: Nested match without parent rules (skip the root /databases match)
  const isRoot = match.path.raw.includes('databases') && match.path.raw.includes('documents');
  if (match.children.length > 0 && match.allows.length === 0 && !isRoot) {
    findings.push({
      code: 'STR-2', severity: 'medium', path: pathStr,
      message: `Match at ${pathStr} has nested children but no allows — parent collection is locked`,
    });
  }

  // Recurse into children
  for (const child of match.children) {
    walkMatch(child, findings, localScope);
  }
}

// ---- SEC-4: Default deny ----

function checkDefaultDeny(rootMatch: MatchBlock, findings: ValidationFinding[]) {
  const hasDefaultDeny = rootMatch.children.some(child => {
    const isRecursive = child.path.segments.some(s => s.type === 'recursive');
    if (!isRecursive) return false;
    return child.allows.some(a => {
      const hasBothOps = a.operations.includes('read') && a.operations.includes('write');
      const isDeny = a.condition.type === 'literal' && a.condition.value === false;
      return hasBothOps && isDeny;
    });
  });

  if (!hasDefaultDeny) {
    findings.push({
      code: 'SEC-4', severity: 'medium', path: '/',
      message: 'No default deny rule (match /{document=**} { allow read, write: if false; })',
    });
  }
}

// ---- Constant folding / simplification ----

function boolLiteral(value: boolean): Expression {
  return { type: 'literal', value, raw: String(value) };
}

function isLitBool(expr: Expression, value: boolean): boolean {
  return expr.type === 'literal' && expr.value === value;
}

/**
 * Simplify semantically-constant conditions so the literal checks and the
 * auth/data-reference walks operate on the reduced form. Recurses into nested
 * nodes so `X || (Y || true)` folds to `true`. Non-constant subexpressions are
 * preserved intact so the downstream walks still see real auth/data references.
 */
function foldConstants(expr: Expression): Expression {
  switch (expr.type) {
    case 'binaryOp': {
      const left = foldConstants(expr.left);
      const right = foldConstants(expr.right);
      if (expr.op === '||') {
        // X || true / true || X -> true
        if (isLitBool(left, true) || isLitBool(right, true)) return boolLiteral(true);
        // X || false / false || X -> X
        if (isLitBool(left, false)) return right;
        if (isLitBool(right, false)) return left;
      } else if (expr.op === '&&') {
        // X && false / false && X -> false
        if (isLitBool(left, false) || isLitBool(right, false)) return boolLiteral(false);
        // X && true / true && X -> X
        if (isLitBool(left, true)) return right;
        if (isLitBool(right, true)) return left;
      }
      return { type: 'binaryOp', op: expr.op, left, right };
    }
    case 'unaryOp': {
      const operand = foldConstants(expr.operand);
      if (expr.op === '!' && operand.type === 'literal' && typeof operand.value === 'boolean') {
        return boolLiteral(!operand.value);
      }
      return { type: 'unaryOp', op: expr.op, operand };
    }
    case 'ternary': {
      const condition = foldConstants(expr.condition);
      const consequent = foldConstants(expr.consequent);
      const alternate = foldConstants(expr.alternate);
      // Literal condition -> the taken branch
      if (condition.type === 'literal' && typeof condition.value === 'boolean') {
        return condition.value ? consequent : alternate;
      }
      return { type: 'ternary', condition, consequent, alternate };
    }
    default:
      return expr;
  }
}

// ---- Expression tree walkers ----

/** Every expression a function evaluates: each let value, then the return expression. */
function functionExpressions(fn: FunctionDef): Expression[] {
  return [...fn.lets.map(l => l.value), fn.body];
}

function referencesAuth(expr: Expression): boolean {
  return exprContains(expr, e =>
    e.type === 'memberAccess' && e.property === 'auth' &&
    e.object.type === 'identifier' && e.object.name === 'request',
  );
}

function referencesAuthTransitive(expr: Expression, fns: Map<string, FunctionDef>, visited = new Set<string>()): boolean {
  if (referencesAuth(expr)) return true;
  // Follow function calls
  let found = false;
  walkExpr(expr, e => {
    if (found) return;
    if (e.type === 'functionCall' && fns.has(e.name) && !visited.has(e.name)) {
      visited.add(e.name);
      if (functionExpressions(fns.get(e.name)!).some(x => referencesAuthTransitive(x, fns, visited))) found = true;
    }
  });
  return found;
}

function referencesRequestData(expr: Expression): boolean {
  return exprContains(expr, e =>
    e.type === 'memberAccess' && e.property === 'data' &&
    e.object.type === 'memberAccess' && e.object.property === 'resource' &&
    e.object.object.type === 'identifier' && e.object.object.name === 'request',
  );
}

function referencesRequestDataTransitive(expr: Expression, fns: Map<string, FunctionDef>, visited = new Set<string>()): boolean {
  if (referencesRequestData(expr)) return true;
  let found = false;
  walkExpr(expr, e => {
    if (found) return;
    if (e.type === 'functionCall' && fns.has(e.name) && !visited.has(e.name)) {
      visited.add(e.name);
      if (functionExpressions(fns.get(e.name)!).some(x => referencesRequestDataTransitive(x, fns, visited))) found = true;
    }
  });
  return found;
}

function referencesResourceData(expr: Expression): boolean {
  return exprContains(expr, e =>
    e.type === 'memberAccess' && e.property === 'data' &&
    e.object.type === 'identifier' && e.object.name === 'resource',
  );
}

// ---- QUA-3: Duplicate functions ----
//
// Production REJECTS two declarations of one function name in the SAME
// scope at compile time, so this is severity 'critical': the write gate
// (`write/handler.ts`) blocks only critical validator findings, and
// 'medium' folded to a mere warning that deployed anyway.
//
// A scope is one declaration list: the global list above `service`, the
// list directly inside `service`, or one match block's own list. A nested
// match block that redeclares a name from an enclosing scope SHADOWS it and
// is legal: the simulator implements shadowing in
// `simulator/match-resolution.ts`, and the production capture in
// `conformance/rules-corpus/storage/function-scopes-and-shadowing.ts` pins
// inner-shadows-outer as accepted. Flagging that would block a ruleset
// production deploys.
//
// The code stays QUA-3 (already registered and asserted by consumers);
// `DUPLICATE_FUNCTION` was considered and rejected, because the module
// resolver already uses that name for its own error code
// (`modules/resolver-core.ts`), and colliding would make mixed issue
// lists ambiguous.
//
// Detection is the compile-limit module's FUNCTION_REDEFINED rejection, which
// the Firestore simulator and the Storage parser also enforce at load.

function checkDuplicateFunctions(ast: FirestoreRules, findings: ValidationFinding[]) {
  for (const violation of compileLimitViolations(ast)) {
    if (violation.code !== 'FUNCTION_REDEFINED') continue;
    findings.push({
      code: 'QUA-3', severity: 'critical', path: violation.scope ?? '',
      message: `${violation.message} Function '${violation.functionName}' is declared twice in ${violation.scope}, and production rejects the ruleset at compile time`,
    });
  }
}

// ---- SEM-4, SEM-5, QUA-4: name resolution ----
//
// Every rule condition and every function body resolves its names against
// the scopes in effect where it is declared (`function-scopes.ts`), not
// against every function in the ruleset. Production compiles an unresolved
// function or variable name with a warning ("Invalid function name: s.",
// "Invalid variable name: d.") and evaluating it is an error, so a rule
// that reaches it denies: SEM-4 and SEM-5 are high. A function that no
// resolved call reaches draws production's "Unused function: f." warning,
// at any scope: QUA-4 is low. A call from an unused function still counts,
// as it does in production.

function checkNameResolution(scopes: RulesetScopes, findings: ValidationFinding[]) {
  const called = new Set<FunctionDef>();
  const report = (refs: NameReferences, subject: string, path: string, operation?: string) => {
    for (const callee of refs.callees) called.add(callee);
    const op = operation === undefined ? {} : { operation };
    for (const name of refs.undefinedCalls) {
      findings.push({
        code: 'SEM-4', severity: 'high', path, ...op,
        message: `${subject} calls undefined function '${name}'`,
      });
    }
    for (const name of refs.unboundVariables) {
      findings.push({
        code: 'SEM-5', severity: 'high', path, ...op,
        message: `${subject} reads unbound variable '${name}'. No let binding, function parameter, path capture, or rules global has that name, so evaluating it is an error and the request is denied`,
      });
    }
  };
  for (const scoped of scopes.rules) {
    report(ruleReferences(scoped), `Rule at ${scoped.label}`, scoped.label, scoped.rule.operations.join(', '));
  }
  for (const scoped of scopes.functions) {
    report(functionReferences(scoped), `Function '${scoped.fn.name}' in ${scoped.label}`, scoped.label);
  }
  for (const scoped of scopes.functions) {
    if (called.has(scoped.fn)) continue;
    findings.push({
      code: 'QUA-4', severity: 'low', path: scoped.label,
      message: `Unused function '${scoped.fn.name}': no rule or function calls it`,
    });
  }
}

// ---- STR-3: Overlapping paths ----

function checkOverlappingPaths(siblings: MatchBlock[], findings: ValidationFinding[]) {
  for (let i = 0; i < siblings.length; i++) {
    for (let j = i + 1; j < siblings.length; j++) {
      if (pathsOverlap(siblings[i], siblings[j])) {
        findings.push({
          code: 'STR-3', severity: 'low', path: siblings[i].path.raw,
          message: `Match paths '${siblings[i].path.raw}' and '${siblings[j].path.raw}' may overlap — the more permissive one wins`,
        });
      }
    }
    // Recurse into each sibling's children
    checkOverlappingPaths(siblings[i].children, findings);
  }
}

function pathsOverlap(a: MatchBlock, b: MatchBlock): boolean {
  const segsA = a.path.segments;
  const segsB = b.path.segments;
  if (segsA.length !== segsB.length) return false;
  // If one has a wildcard and the other has a literal at the same position, they overlap
  for (let i = 0; i < segsA.length; i++) {
    const sa = segsA[i], sb = segsB[i];
    if (sa.type === 'literal' && sb.type === 'literal' && sa.value !== sb.value) return false;
    // wildcard + literal at same position = overlap
    if ((sa.type === 'wildcard' || sa.type === 'recursive') && sb.type === 'literal') return true;
    if (sa.type === 'literal' && (sb.type === 'wildcard' || sb.type === 'recursive')) return true;
  }
  return false;
}

// ---- Expression depth ----

function exprDepth(expr: Expression): number {
  switch (expr.type) {
    case 'binaryOp': return 1 + Math.max(exprDepth(expr.left), exprDepth(expr.right));
    case 'unaryOp': return 1 + exprDepth(expr.operand);
    case 'ternary': return 1 + Math.max(exprDepth(expr.condition), exprDepth(expr.consequent), exprDepth(expr.alternate));
    case 'methodCall': return 1 + Math.max(exprDepth(expr.object), ...expr.args.map(exprDepth));
    case 'functionCall': return 1 + Math.max(0, ...expr.args.map(exprDepth));
    case 'bracketAccess': return 1 + Math.max(exprDepth(expr.object), exprDepth(expr.index));
    case 'sliceAccess': return 1 + Math.max(exprDepth(expr.object), exprDepth(expr.start), exprDepth(expr.end));
    case 'memberAccess': return 1 + exprDepth(expr.object);
    case 'inExpr': return 1 + Math.max(exprDepth(expr.element), exprDepth(expr.collection));
    case 'isExpr': return 1 + exprDepth(expr.value);
    default: return 0;
  }
}

// ---- Generic expression walker ----

function exprContains(expr: Expression, predicate: (e: Expression) => boolean): boolean {
  if (predicate(expr)) return true;
  return walkExprSome(expr, predicate);
}

function walkExprSome(expr: Expression, predicate: (e: Expression) => boolean): boolean {
  switch (expr.type) {
    case 'binaryOp': return exprContains(expr.left, predicate) || exprContains(expr.right, predicate);
    case 'unaryOp': return exprContains(expr.operand, predicate);
    case 'ternary': return exprContains(expr.condition, predicate) || exprContains(expr.consequent, predicate) || exprContains(expr.alternate, predicate);
    case 'methodCall': return exprContains(expr.object, predicate) || expr.args.some(a => exprContains(a, predicate));
    case 'functionCall': return expr.args.some(a => exprContains(a, predicate));
    case 'bracketAccess': return exprContains(expr.object, predicate) || exprContains(expr.index, predicate);
    case 'sliceAccess': return exprContains(expr.object, predicate) || exprContains(expr.start, predicate) || exprContains(expr.end, predicate);
    case 'memberAccess': return exprContains(expr.object, predicate);
    case 'inExpr': return exprContains(expr.element, predicate) || exprContains(expr.collection, predicate);
    case 'isExpr': return exprContains(expr.value, predicate);
    case 'listLiteral': return expr.elements.some(e => exprContains(e, predicate));
    case 'mapLiteral': return expr.entries.some(e => exprContains(e.key, predicate) || exprContains(e.value, predicate));
    default: return false;
  }
}

function walkExpr(expr: Expression, visitor: (e: Expression) => void) {
  visitor(expr);
  switch (expr.type) {
    case 'binaryOp': walkExpr(expr.left, visitor); walkExpr(expr.right, visitor); break;
    case 'unaryOp': walkExpr(expr.operand, visitor); break;
    case 'ternary': walkExpr(expr.condition, visitor); walkExpr(expr.consequent, visitor); walkExpr(expr.alternate, visitor); break;
    case 'methodCall': walkExpr(expr.object, visitor); expr.args.forEach(a => walkExpr(a, visitor)); break;
    case 'functionCall': expr.args.forEach(a => walkExpr(a, visitor)); break;
    case 'bracketAccess': walkExpr(expr.object, visitor); walkExpr(expr.index, visitor); break;
    case 'sliceAccess': walkExpr(expr.object, visitor); walkExpr(expr.start, visitor); walkExpr(expr.end, visitor); break;
    case 'memberAccess': walkExpr(expr.object, visitor); break;
    case 'inExpr': walkExpr(expr.element, visitor); walkExpr(expr.collection, visitor); break;
    case 'isExpr': walkExpr(expr.value, visitor); break;
    case 'listLiteral': expr.elements.forEach(e => walkExpr(e, visitor)); break;
    case 'mapLiteral': expr.entries.forEach(e => { walkExpr(e.key, visitor); walkExpr(e.value, visitor); }); break;
  }
}
