import type { AiEngineConfigWire } from './worker/protocol.js';

/** Browser-safe wire contract served by `/__pyric/init.json`. */
export interface InitPayload {
  /** Per-server capability for the warning-only activity report endpoint. */
  activityToken?: string;
  /** Per-boot session capability token required on workspace and project endpoints. */
  sessionToken?: string;
  rules: string | null;
  rulesHash: string | null;
  databaseRules?: { rules: Record<string, unknown> } | null;
  databaseRulesHash?: string | null;
  databaseUrl?: string | null;
  /** Explicit opt-in to permissive default access when rules are unconfigured. */
  permissive?: boolean;
  /** Storage rules installed before the first Storage operation. A dev server
   *  replaces them over `storage-rules-update` when the rules file changes. */
  storageRules: string | null;
  storageRulesHash: string | null;
  /**
   * Local project identity — the served project directory. Scopes the
   * storage IndexedDB database name (`pyric-storage:<projectKey>`, issue
   * #359): IndexedDB is origin-scoped, so without this every project served
   * on one localhost port shared one storage database. Local-only (a dev
   * server path never leaves the machine). Absent/null on older servers —
   * consumers fall back to the legacy shared name.
   */
  projectKey?: string | null;
  bridgeUrl: string | null;
  /** Explicit Node ownership; browser startup must not select a local store. */
  hosted?: boolean;
  persistenceUnhealthy?: boolean;
  seed: Record<string, Record<string, unknown>> | null;
  persist?: boolean;
  seedState?: unknown | null;
  authUsers?: ReadonlyArray<Record<string, unknown>> | null;
  capture?: boolean;
  messaging?: boolean;
  /**
   * True exactly when `/__pyric/assets/avatar/<uid>` is mounted (`avatars`
   * was not explicitly disabled — see `avatars-config.ts`). Only this flag
   * travels to the page; the resolved set directory or source never does,
   * mirroring the AI proxy's server-only-config asymmetry. A browser
   * consumer that backfills `photoURL` from this flag is a later task.
   */
  avatars?: boolean;
  /**
   * True exactly when this server's avatars config carries a `source`, the
   * only configuration whose images can arrive after the first request: a
   * generated image supersedes the placeholder the browser was served while
   * it ran. `avatars` says the route is mounted; this says an upgrade is
   * possible at all. The page decides on this flag whether to open a
   * listener, so the default and set-only configurations — final on the first
   * request — open no connection.
   */
  avatarUpgrades?: boolean;
  /**
   * Plugin-level AI config (`@pyric/cli/vite`'s `ai.engine`). Only the ENGINE
   * travels here — the OpenAI proxy upstream is a server-side namespace option
   * that never reaches the page. The worker host reads `ai.engine` into
   * `ctx.aiEngine`, which wins over any op-carried `engine` (see host-ai.ts).
   * Absent under `pyric dev` (no CLI surface) and whenever the plugin sets no
   * engine. The in-page fallback path receives the same engine synchronously
   * via the injected `globalThis.__PYRIC_AI_ENGINE__` (init.json can't be read
   * synchronously by the served `getAI`).
   */
  ai?: { engine?: AiEngineConfigWire } | null;
}

/** Synchronous page transport selection, injected before application modules. */
export type WorkerInitPayload = Pick<InitPayload, 'hosted' | 'projectKey' | 'bridgeUrl' | 'persistenceUnhealthy'>;

declare global {
  var __PYRIC_WORKER_INIT__: WorkerInitPayload | undefined;
}
