/**
 * Apply a typed seed to a sandbox, through the public sandbox surfaces the
 * product exposes rather than a raw snapshot restore.
 *
 * This is the one implementation of "what a seed does to a sandbox." The eval
 * harness seeds a fresh sandbox with it before a run starts, and the
 * `sandbox.seed` operation calls the same two functions against the live
 * sandbox, so a task's seed and an agent's own seed call are one shape and one
 * code path. `SandboxSeed` is that one shape: the harness's `EvalSeed` is an
 * alias of it rather than a second declaration of the same fields.
 *
 * Ordering matters. The database default policy is stateful and every write
 * is evaluated against whatever ruleset is in force, so rules are applied
 * before any data write.
 */
import { parseRtdbRulesText } from '../../rtdb/rules-json.js';
import { loadDatabaseRules } from './database-rules-load.js';
import type { LocalSandbox } from 'pyric/sandbox';
import { getAdminFirestore, doc, setDoc } from 'pyric/firestore';
import { getAdminDatabase, ref as databaseRef, set as databaseSet } from 'pyric/database';
import { getAdminStorageSandbox, replaceStorageRules } from 'pyric/storage/internal';
import { ref as storageRef, uploadBytes } from 'pyric/storage';
import { getAuth, sandbox as authSandbox } from 'pyric/auth';
import { loadFirestoreRules } from './firestore-rules-load.js';
import { rememberUnloadedStorageRules } from './storage-rules.js';

/** One seeded user, as a plain data record rather than a validated Zod shape. */
export interface SeedUserEntry {
  uid: string;
  email?: string;
  customClaims?: Record<string, unknown>;
  tenantId?: string;
  /**
   * The real password to seed, rather than the synthetic `seed-<uid>` one.
   * `exportFixture` carries it unless the call passed `excludePasswords`, so a
   * fixture round trip preserves sign-in by default.
   */
  password?: string;
}

/** One seeded storage object. */
export interface SeedStorageEntry {
  path: string;
  contentBase64: string;
  contentType?: string;
  customMetadata?: Record<string, string>;
}

/** State to load into a sandbox. The harness's `EvalSeed` is an alias of this. */
export interface SandboxSeed {
  firestoreRules?: string;
  databaseRules?: string;
  storageRules?: string;
  users?: SeedUserEntry[];
  /** Document path to document data. */
  firestore?: Record<string, Record<string, unknown>>;
  /** Realtime Database tree written at the root. */
  database?: Record<string, unknown>;
  storage?: SeedStorageEntry[];
}

/** Address a seeded user needs when the record states none. */
function seedEmail(uid: string, declared: string | undefined): string {
  if (declared !== undefined) return declared;
  return `${uid}@pyric.invalid`;
}

/**
 * Seeded identities are never signed in as part of seeding, so the password is
 * a placeholder rather than a credential. It is derived from the uid so a
 * seeded sandbox is byte-identical across runs.
 */
function seedPassword(uid: string): string {
  return `seed-${uid}`;
}

/**
 * Write user records into the auth pool. `seedUsers` is the only entry point
 * that carries a tenant onto a stored record, so every seeded identity goes
 * through it, and `auth.importUsers` reaches the pool through this same
 * function rather than a second import path of its own.
 */
export function applyUsers(sandbox: LocalSandbox, users: readonly SeedUserEntry[]): void {
  if (users.length === 0) return;
  const auth = getAuth(sandbox);
  authSandbox.seedUsers(
    auth,
    users.map((user) => {
      const record: {
        uid: string;
        email: string;
        password: string;
        customClaims?: Record<string, unknown>;
        tenantId?: string;
      } = {
        uid: user.uid,
        email: seedEmail(user.uid, user.email),
        password: user.password ?? seedPassword(user.uid),
      };
      if (user.customClaims !== undefined) record.customClaims = user.customClaims;
      if (user.tenantId !== undefined) record.tenantId = user.tenantId;
      return record;
    }),
  );
}

/**
 * Install the rules a seed carries, before any data write. Returns why each
 * Firestore, Storage or Realtime Database source production would not load
 * was refused.
 *
 * A seed may carry such rules on purpose, for lint tasks, so a refusal does
 * not throw: the sandbox keeps the rules in force, and lint reads the refused
 * source (Firestore and Storage simulate read it too).
 */
export async function applyRules(sandbox: LocalSandbox, seed: SandboxSeed): Promise<string[]> {
  const refusals: string[] = [];
  const storageRules = seed.storageRules;
  if (storageRules !== undefined) {
    try {
      await replaceStorageRules(sandbox, storageRules);
    } catch (error) {
      getAdminStorageSandbox(sandbox);
      rememberUnloadedStorageRules(sandbox, storageRules);
      refusals.push(error instanceof Error ? error.message : String(error));
    }
  }
  const databaseRules = seed.databaseRules;
  if (databaseRules !== undefined) {
    const parsed = parseRtdbRulesText(databaseRules, (reason) => reason);
    const refused = loadDatabaseRules(sandbox, parsed);
    if (refused !== null) refusals.push(refused);
  }
  const firestoreRules = seed.firestoreRules;
  if (firestoreRules !== undefined) {
    const refused = loadFirestoreRules(sandbox, firestoreRules);
    if (refused !== null) refusals.push(refused);
  }
  return refusals;
}

/** Load the data a seed carries: users, documents, database tree, storage objects. */
export async function applyData(sandbox: LocalSandbox, seed: SandboxSeed): Promise<void> {
  applyUsers(sandbox, seed.users ?? []);

  const documents = seed.firestore ?? {};
  const db = getAdminFirestore(sandbox);
  for (const [path, data] of Object.entries(documents)) {
    await setDoc(doc(db, path), data);
  }

  const tree = seed.database;
  if (tree !== undefined) {
    const rtdb = getAdminDatabase(sandbox);
    for (const [key, value] of Object.entries(tree)) {
      await databaseSet(databaseRef(rtdb, `/${key}`), value);
    }
  }

  const objects = seed.storage ?? [];
  const storage = getAdminStorageSandbox(sandbox);
  for (const object of objects) {
    const bytes = Uint8Array.from(Buffer.from(object.contentBase64, 'base64'));
    const metadata: { contentType?: string; customMetadata?: Record<string, string> } = {};
    if (object.contentType !== undefined) metadata.contentType = object.contentType;
    if (object.customMetadata !== undefined) metadata.customMetadata = object.customMetadata;
    await uploadBytes(storageRef(storage, object.path), bytes, metadata);
  }
}
