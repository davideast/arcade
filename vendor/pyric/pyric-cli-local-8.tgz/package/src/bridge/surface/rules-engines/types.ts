/**
 * What a rules engine does for one service.
 *
 * The `rules` tool has one method per action and names its service in the
 * arguments, so each method dispatches on the service to the engine below.
 * Three services implement this, one file each, and a method record holds the
 * dispatch and nothing else.
 *
 * An engine carries everything that differs by service, including the request
 * methods that service evaluates and the check that its rules source compiles.
 * A service that gains Security Rules is therefore one new engine file and one
 * new entry in the record set, with no list elsewhere to keep in step.
 */
import type { OperationResult, SurfaceContext } from '../types.js';

/** One request to evaluate, as the `rules` tool spells it. */
export interface RulesRequest {
  operation: string;
  path: string;
  uid?: string;
  /**
   * The value the request carries. Firestore takes an object. Database takes
   * any JSON value, so `5` or `true` is a scalar write, and for an `update`
   * request it is the patch keyed by the paths written.
   */
  data?: unknown;
  /** The query a database `read` carries, in the members rules read as `query.*`. */
  query?: Record<string, unknown>;
  rules?: string;
  /**
   * The instant `request.time` (Firestore, Storage) or `now` (database)
   * evaluates at, as an ISO 8601 string. Omit to evaluate at the sandbox
   * clock's current instant.
   */
  requestTime?: string;
}

/** Why a rules source does not parse or compile for one service, in the caller's words. */
export interface RulesSourceProblem {
  /** What is wrong, as a sentence naming the position or the parser's message. */
  body: string;
  /** The edit that fixes it, opening with an imperative verb. */
  fix: string;
}

export interface RulesEngine {
  /** The request methods this service's rules evaluate. */
  readonly requestMethods: readonly string[];
  /**
   * Why one source cannot be installed for this service: it does not parse,
   * or production rejects it at compile time. Null when it compiles.
   */
  compileFailure(source: string): RulesSourceProblem | null;
  /** Check a ruleset for errors without evaluating a request. */
  lint(ctx: SurfaceContext, rules: string | undefined): Promise<OperationResult>;
  /** Evaluate one request and report allow or deny. */
  simulate(ctx: SurfaceContext, request: RulesRequest): Promise<OperationResult>;
  /** Install a ruleset into the running sandbox. */
  install(ctx: SurfaceContext, rules: string): Promise<OperationResult>;
}
