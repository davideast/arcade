/**
 * Reading a bucket out, and writing one back.
 *
 * Storage stays out of the sandbox's record bundle: it owns its own durability
 * through IndexedDB, and blobs are not JSON. So every part of the surface that
 * saves or replaces sandbox state has to walk the bucket itself, and this is
 * the one walk they share. A checkpoint captures it, a fixture exports it, a
 * scoped reset clears it, and the in-process server's sidecar file is the same
 * records written to disk.
 *
 * It is a leaf: it knows the SDK and nothing about the server, the surface's
 * context, or where any of this is stored.
 */
import {
  ref as storageRef,
  uploadBytes,
  listAll,
  type FirebaseStorage,
} from 'pyric/storage';
import { getStorageService, targetOf } from 'pyric/storage/internal';
import { BY_REFERENCE_ALTERNATIVE, assertInlineStorageFits, type InlineStorageDocument } from 'pyric/sandbox/internal';

/** One stored object, in the shape a capture holds it. */
export interface StorageObjectRecord {
  path: string;
  contentBase64: string;
  contentType?: string;
  metadata: Record<string, unknown>;
}

/**
 * Every object path in the bucket. `listAll` reports one level, so the walk
 * descends into each prefix it returns.
 */
export async function listStoredPaths(storage: FirebaseStorage): Promise<string[]> {
  const paths: string[] = [];
  const pending = [''];
  while (pending.length > 0) {
    const prefix = pending.pop() as string;
    const listing = await listAll(storageRef(storage, prefix));
    for (const item of listing.items) paths.push(item.fullPath);
    for (const child of listing.prefixes) pending.push(child.fullPath);
  }
  paths.sort();
  return paths;
}

/** Where a fixture export's Storage ends up, and what to use past the inline limit. */
export const FIXTURE_EXPORT_DOCUMENT: InlineStorageDocument = {
  document: 'A fixture export',
  instead: BY_REFERENCE_ALTERNATIVE,
};

/**
 * Read every object out of the bucket into records. Each object's bytes and
 * metadata are read as one pair from the same write, so an overwrite during
 * the export cannot pair one write's content type with another's bytes. An
 * object deleted after the listing is left out.
 *
 * The records carry their bytes inline, so the total is checked against the
 * inline limit from the listed sizes before a byte is read, and again as the
 * bytes are read, refused in the name of `target`.
 */
export async function exportStorage(
  storage: FirebaseStorage,
  target: InlineStorageDocument,
): Promise<StorageObjectRecord[]> {
  const backend = (await getStorageService(storage)).backend;
  const { bucket } = targetOf(storage);
  const paths = await listStoredPaths(storage);
  let listedBytes = 0;
  for (const path of paths) listedBytes += (await backend.getMetadata(path, bucket))?.size ?? 0;
  assertInlineStorageFits(listedBytes, target);
  const records: StorageObjectRecord[] = [];
  let readBytes = 0;
  for (const path of paths) {
    const object = await backend.getObject(path, bucket);
    const deletedSinceListing = object === undefined;
    if (deletedSinceListing) continue;
    const { blob, metadata } = object;
    readBytes += blob.size;
    // An overwrite after the listing can grow an object; refuse before encoding it.
    assertInlineStorageFits(readBytes, target);
    const record: StorageObjectRecord = {
      path,
      contentBase64: Buffer.from(await blob.arrayBuffer()).toString('base64'),
      metadata: metadata.customMetadata ?? {},
    };
    if (metadata.contentType !== undefined) record.contentType = metadata.contentType;
    records.push(record);
  }
  return records;
}

/** Write every record into a bucket. Returns the number of objects restored. */
export async function restoreStorage(
  storage: FirebaseStorage,
  records: readonly StorageObjectRecord[],
): Promise<number> {
  for (const record of records) {
    const bytes = Uint8Array.from(Buffer.from(record.contentBase64, 'base64'));
    const settable: { contentType?: string; customMetadata?: Record<string, string> } = {};
    if (record.contentType !== undefined) settable.contentType = record.contentType;
    const custom = toCustomMetadata(record.metadata);
    if (custom !== null) settable.customMetadata = custom;
    await uploadBytes(storageRef(storage, record.path), bytes, settable);
  }
  return records.length;
}

/** Storage custom metadata is a string map; anything else is dropped rather than coerced. */
export function toCustomMetadata(
  metadata: Record<string, unknown>,
): Record<string, string> | null {
  const entries: Record<string, string> = {};
  let found = false;
  for (const [key, value] of Object.entries(metadata)) {
    if (typeof value !== 'string') continue;
    entries[key] = value;
    found = true;
  }
  if (!found) return null;
  return entries;
}
