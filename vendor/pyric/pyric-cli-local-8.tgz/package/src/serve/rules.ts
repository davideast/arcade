/**
 * `pyric dev` rules wiring — load the project's `firestore.rules`, make it
 * executable for the in-page sandbox, and fail FAST at startup on broken
 * rules (a clear CLI error beats a silently rule-less page).
 *
 * `2+modules` sources are resolved node-side before embedding, with the
 * stdlib inlined and relative imports read from the project, so the page
 * runtime only ever sees plain-v2 source the in-browser evaluator understands. This is the
 * same lesson the playground's write_file learned (a capable model authored
 * correct modular rules that scored 0/5 unresolved — auth-sdk work, PR #525).
 */
import { createHash } from 'node:crypto';
import { readFileSync, watch, type FSWatcher } from 'node:fs';
import { readFile } from 'node:fs/promises';
import { dirname, isAbsolute, join } from 'node:path';
import {
  describeCompileLimitViolations,
  lintFirestoreRules,
  resolveModulesWithFiles,
  rulesSourceRejection,
  sourceCompileLimitViolations,
  type ResolveResult,
} from 'pyric/rules/internal';
import { asSentence } from 'pyric/sandbox/internal';
import { parseStorageRules } from 'pyric/storage';
import type { FirebaseJson } from '../cli/firebase-json.js';
import { rtdbRulesSourceRejection } from 'pyric/rules/internal/rtdb';
import { parseRtdbRulesText } from '../rtdb/rules-json.js';

export interface LoadedRules {
  /** Plain-v2 source ready for the sandbox, or null when the project has no
   *  rules file configured/present. */
  rules: string | null;
  rulesHash: string | null;
  /** Where it came from (diagnostics + the P3 watcher target). */
  sourcePath: string | null;
  /** Rules files of the project's own that the source imports, directly or
   *  through other modules. Watched alongside `sourcePath`. */
  moduleFiles: string[];
}

export interface LoadedStorageRules {
  /** Plain storage-rules source ready for the sandbox, or null when the
   *  project has no storage rules file configured/present. */
  rules: string | null;
  rulesHash: string | null;
  sourcePath: string | null;
}

export interface LoadedDatabaseRules {
  rules: { rules: Record<string, unknown> } | null;
  rulesHash: string | null;
  sourcePath: string | null;
  databaseUrl: string | null;
}

export function rulesHashOf(source: string): string {
  return createHash('sha256').update(source).digest('hex').slice(0, 12);
}

const MODULAR_SOURCE = /^\s*rules_version\s*=\s*['"]2\+modules['"]/m;

interface ProjectModulesResolution {
  result: ResolveResult;
  /** Every project file the resolver asked for, found or not, as absolute paths. */
  moduleFiles: string[];
}

/**
 * Resolve a modular source: the stdlib inlined, relative imports read from
 * beside `sourcePath`. The resolver names nested imports relative to the
 * source, so every file it asks for is under `sourcePath`'s directory.
 */
function resolveProjectModules(raw: string, sourcePath: string, sourceFile?: string): ProjectModulesResolution {
  const basePath = dirname(sourcePath);
  const moduleFiles: string[] = [];
  const readProjectRulesFile = (base: string, moduleName: string): string | null => {
    const fileName = moduleName.endsWith('.rules') ? moduleName : `${moduleName}.rules`;
    const file = join(base, fileName);
    if (!moduleFiles.includes(file)) moduleFiles.push(file);
    try {
      return readFileSync(file, 'utf8');
    } catch {
      return null;
    }
  };
  const options = sourceFile === undefined ? { basePath } : { basePath, sourceFile };
  const result = resolveModulesWithFiles(raw, readProjectRulesFile, options);
  return { result, moduleFiles };
}

export interface PreparedRules {
  rules: string;
  /** Rules files of the project's own that the source imports. */
  moduleFiles: string[];
}

/**
 * A rules source that failed to resolve, parse or lint. `moduleFiles` lists
 * the project files its resolution asked for, found or not, so a watcher can
 * reload when one of them is fixed or created.
 */
export class RulesPrepareError extends Error {
  readonly moduleFiles: readonly string[];

  constructor(message: string, moduleFiles: readonly string[]) {
    super(message);
    this.name = 'RulesPrepareError';
    this.moduleFiles = moduleFiles;
  }
}

/**
 * Resolve + lint a raw rules source into sandbox-ready plain v2.
 * Throws with an actionable message on unresolvable imports or lint errors.
 */
export function prepareRulesSource(raw: string, sourcePath: string): string {
  return prepareProjectRules(raw, sourcePath).rules;
}

/**
 * {@link prepareRulesSource}, also reporting the module files the source
 * imports. Throws a {@link RulesPrepareError} that lists the module files the
 * failed source asked for.
 */
export function prepareProjectRules(raw: string, sourcePath: string): PreparedRules {
  let source = raw;
  let moduleFiles: string[] = [];
  if (MODULAR_SOURCE.test(raw)) {
    const resolution = resolveProjectModules(raw, sourcePath);
    moduleFiles = resolution.moduleFiles;
    const resolved = resolution.result;
    if (!resolved.success) {
      throw new RulesPrepareError(
        `pyric sandbox: ${sourcePath} uses 2+modules but module resolution failed: ${resolved.error.message}`,
        moduleFiles,
      );
    }
    source = resolved.data.resolved;
  }
  // Production rejects a ruleset that does not parse, or is past its compile
  // limits, before it evaluates any request, so the sandbox does not serve
  // one either: the check every rules load path runs.
  const rejection = rulesSourceRejection(source);
  if (rejection?.kind === 'parse') {
    throw new RulesPrepareError(
      `pyric sandbox: ${sourcePath} failed to parse (line ${rejection.line}, col ${rejection.column}). Fix the rules before serving.`,
      moduleFiles,
    );
  }
  if (rejection?.kind === 'compile') {
    throw new RulesPrepareError(
      `pyric sandbox: ${sourcePath} does not compile: ${describeCompileLimitViolations(rejection.violations)} Fix the rules before serving.`,
      moduleFiles,
    );
  }
  const lint = lintFirestoreRules(source);
  const errors = lint.warnings.filter((w) => w.severity === 'error');
  if (errors.length > 0) {
    throw new RulesPrepareError(
      `pyric sandbox: ${sourcePath} has ${errors.length} rules error(s):\n` +
        errors.map((e) => `  - ${e.message}`).join('\n'),
      moduleFiles,
    );
  }
  return { rules: source, moduleFiles };
}

/**
 * The Firestore rules file the project deploys: `firebase.json`'s
 * `firestore.rules`, else `firestore.rules` in `cwd`. The file may not exist.
 */
export function firestoreRulesPath(cwd: string, config: FirebaseJson | null): string {
  const rel = config?.firestore?.rules ?? 'firestore.rules';
  return isAbsolute(rel) ? rel : join(cwd, rel);
}

/**
 * Load the project rules per `firebase.json` (`firestore.rules` path,
 * defaulting to `firestore.rules` in cwd when the key is absent but the file
 * exists). Missing file with no explicit config → `{ rules: null }` (serving
 * without rules is fine; the runtime logs it). Missing file that IS
 * explicitly configured → throw (the project says it should exist).
 */
export async function loadProjectRules(
  cwd: string,
  config: FirebaseJson | null,
): Promise<LoadedRules> {
  const configured = config?.firestore?.rules;
  const path = firestoreRulesPath(cwd, config);
  let raw: string;
  try {
    raw = await readFile(path, 'utf8');
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'ENOENT') {
      if (configured) {
        throw new Error(`pyric sandbox: firebase.json points firestore.rules at ${path}, but it does not exist.`);
      }
      return { rules: null, rulesHash: null, sourcePath: null, moduleFiles: [] };
    }
    throw e;
  }
  const { rules, moduleFiles } = prepareProjectRules(raw, path);
  return { rules, rulesHash: rulesHashOf(rules), sourcePath: path, moduleFiles };
}

/**
 * Resolve and validate a raw Storage rules source. Modular sources are
 * authored in storage.modules.rules and resolved in memory before the
 * sandbox sees them; firebase.json can continue to point at storage.rules.
 */
export function prepareStorageRulesSource(raw: string, sourcePath: string): string {
  let source = raw;
  if (MODULAR_SOURCE.test(raw)) {
    const resolved = resolveProjectModules(raw, sourcePath, sourcePath).result;
    if (!resolved.success) {
      throw new Error(
        `pyric sandbox: ${sourcePath} uses 2+modules but module resolution failed: ${resolved.error.message}`,
      );
    }
    source = resolved.data.resolved;
  }
  try {
    parseStorageRules(source);
  } catch (e) {
    const violations = sourceCompileLimitViolations(source);
    if (violations.length > 0) {
      throw new Error(
        `pyric sandbox: ${sourcePath} does not compile: ${describeCompileLimitViolations(violations)} Fix the rules before serving.`,
      );
    }
    throw new Error(
      `${asSentence(`pyric sandbox: ${sourcePath} failed to parse: ${e instanceof Error ? e.message : String(e)}`)} Fix the rules before serving.`,
    );
  }
  return source;
}

function configuredStorageRules(config: FirebaseJson | null): string | undefined {
  const block = config?.storage;
  const entries = block ? (Array.isArray(block) ? block : [block]) : [];
  return entries.find((e) => e && typeof e === 'object' && e.rules)?.rules;
}

/**
 * The Storage rules file the project deploys: the first `firebase.json`
 * `storage` entry with a `rules` path, else `storage.rules` in `cwd`. The
 * file may not exist.
 */
export function storageRulesPath(cwd: string, config: FirebaseJson | null): string {
  const rel = configuredStorageRules(config) ?? 'storage.rules';
  return isAbsolute(rel) ? rel : join(cwd, rel);
}

/** The notice a dev server logs when the Storage rules file it loaded is
 *  deleted and Storage returns to denying every client operation. */
export function formatStorageRulesRemoved(path: string): string {
  return `storage rules removed: ${path} does not exist, client Storage operations default to DENY`;
}

/**
 * Load the project's storage rules per `firebase.json` (`storage.rules`
 * path — the block may be a single object or an array of per-bucket
 * entries; v1 has one implicit bucket, so the FIRST entry with a `rules`
 * path wins, defaulting to `storage.rules` in cwd when the block is absent
 * but the file exists). Missing file with no explicit config → `{ rules:
 * null }` (serving without storage rules is fine — same posture as
 * `loadProjectRules`). Missing file that IS explicitly configured → throw
 * (the project says it should exist).
 */
export async function loadProjectStorageRules(
  cwd: string,
  config: FirebaseJson | null,
): Promise<LoadedStorageRules> {
  const configured = configuredStorageRules(config);
  const path = storageRulesPath(cwd, config);
  let raw: string;
  try {
    raw = await readFile(path, 'utf8');
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'ENOENT') {
      if (configured) {
        throw new Error(`pyric sandbox: firebase.json points storage.rules at ${path}, but it does not exist.`);
      }
      return { rules: null, rulesHash: null, sourcePath: null };
    }
    throw e;
  }
  const rules = prepareStorageRulesSource(raw, path);
  return { rules, rulesHash: rulesHashOf(rules), sourcePath: path };
}

function normalizeDatabaseEntries(block: unknown): Array<Record<string, unknown>> {
  if (!block) {
    return [];
  }
  if (Array.isArray(block)) {
    return block.filter((item): item is Record<string, unknown> => typeof item === 'object' && item !== null);
  }
  if (typeof block === 'object' && block !== null) {
    return [block as Record<string, unknown>];
  }
  return [];
}

function hasConfiguredRules(entry: Record<string, unknown>): entry is Record<string, unknown> & { rules: string } {
  return typeof entry.rules === 'string';
}

function hasConfiguredUrl(entry: Record<string, unknown>): entry is Record<string, unknown> & { url: string } {
  return typeof entry.url === 'string';
}

/**
 * The Realtime Database rules file the project deploys: the first
 * `firebase.json` `database` entry with a `rules` path, else
 * `database.rules.json` in `cwd`. The file may not exist.
 */
export function databaseRulesPath(cwd: string, config: FirebaseJson | null): string {
  const rel = normalizeDatabaseEntries(config?.database).find(hasConfiguredRules)?.rules ?? 'database.rules.json';
  return isAbsolute(rel) ? rel : join(cwd, rel);
}

/** The notice a dev server logs when the Realtime Database rules file it
 *  loaded is deleted and RTDB returns to its default policy. */
export function formatDatabaseRulesRemoved(path: string, policy: 'allow' | 'deny'): string {
  const access = policy === 'allow' ? 'are open (permissive mode)' : 'default to DENY (matching production Firebase)';
  return `rtdb rules removed: ${path} does not exist, client RTDB reads/writes ${access}`;
}

export async function loadProjectDatabaseRules(
  cwd: string,
  config: FirebaseJson | null,
): Promise<LoadedDatabaseRules> {
  const entries = normalizeDatabaseEntries(config?.database);
  const configuredEntry = entries.find(hasConfiguredRules);
  const configured = configuredEntry?.rules;
  const path = databaseRulesPath(cwd, config);
  const urlEntry = entries.find(hasConfiguredUrl);
  const databaseUrl = urlEntry?.url ?? null;
  let raw: string;
  try {
    raw = await readFile(path, 'utf8');
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'ENOENT') {
      if (configured) {
        throw new Error(`pyric sandbox: firebase.json points database.rules at ${path}, but it does not exist.`);
      }
      return {
        rules: null,
        rulesHash: null,
        sourcePath: null,
        databaseUrl,
      };
    }
    throw e;
  }

  const rules = parseRtdbRulesText(
    raw,
    (reason) => new Error(`pyric sandbox: ${path} did not parse as RTDB rules JSON: ${reason.message}.`),
  );

  // The check every rules load path runs: a ruleset production's deploy
  // would refuse is not served, and the rules in force stay in force.
  const rejection = rtdbRulesSourceRejection(rules);
  if (rejection !== null) {
    throw new Error(`pyric sandbox: ${path} is not valid RTDB rules. ${rejection.message} Fix the rules before serving.`);
  }

  return {
    rules,
    rulesHash: rulesHashOf(raw),
    sourcePath: path,
    databaseUrl,
  };
}

/**
 * Watch the rules file and invoke `onChange` with freshly prepared
 * (resolved + linted) source. Broken intermediate saves are LOGGED and
 * skipped — the last-good ruleset stays live (the write_file lesson:
 * never replace a working ruleset with un-evaluatable source).
 * Debounced; returns the watcher for shutdown.
 */
export function watchProjectRules(
  sourcePath: string,
  onChange: (next: { rules: string; rulesHash: string }) => void,
  onError: (message: string) => void,
  debounceMs = 150,
): FSWatcher {
  return watchRulesFile(sourcePath, prepareRulesSource, onChange, onError, debounceMs);
}

/**
 * Shared watch implementation. Broken intermediate saves are LOGGED and
 * skipped — the last-good ruleset stays live (the write_file lesson: never
 * replace a working ruleset with un-evaluatable source). Debounced; returns
 * the watcher for shutdown.
 */
function watchRulesFile(
  sourcePath: string,
  prepare: (raw: string, sourcePath: string) => string,
  onChange: (next: { rules: string; rulesHash: string }) => void,
  onError: (message: string) => void,
  debounceMs: number,
): FSWatcher {
  let timer: ReturnType<typeof setTimeout> | null = null;
  const watcher = watch(sourcePath, () => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      void readFile(sourcePath, 'utf8').then(
        (raw) => {
          try {
            const rules = prepare(raw, sourcePath);
            onChange({ rules, rulesHash: rulesHashOf(rules) });
          } catch (e) {
            onError(e instanceof Error ? e.message : String(e));
          }
        },
        (e) => onError(e instanceof Error ? e.message : String(e)),
      );
    }, debounceMs);
  });
  // An FSWatcher with no 'error' listener throws at the event-loop level on
  // watcher failure (EMFILE, the watched file renamed away on some platforms)
  // and would kill the serve process. Degrade to "no hot reload" instead.
  watcher.on('error', (e) =>
    onError(`rules watcher failed (hot reload off): ${e instanceof Error ? e.message : String(e)}`),
  );
  return watcher;
}
