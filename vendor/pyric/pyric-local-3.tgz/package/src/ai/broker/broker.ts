import { aiEndpoint, getAiEvidence, setAiEvidence, type AiEvidence } from '../../sandbox/internal/ai-evidence.js';
/**
 * The sandbox AI broker — the ONE in-process Gemini-wire model every plane
 * consumes (house pattern: the messaging broker):
 *
 *   - the client mirror (`pyric/ai`, next stage) calls generateContent /
 *     streamGenerateContent / countTokens exactly like `rtdb.*` / `auth.*`
 *     will over the worker protocol (cdd-deltas #98.3);
 *   - Pyric Studio & tracing consume the typed `service_mutation` events the
 *     broker emits onto the sandbox's unified `onEvent` stream;
 *   - answering is delegated through ONE seam ({@link AnswerEngine},
 *     cdd-deltas #97): `scripted` (default, zero-I/O) or `openai`.
 *
 * The broker validates requests LIKE PRODUCTION does — before any engine
 * runs — throwing {@link AiBrokerError} carrying the exact captured error
 * envelope:
 *   - empty/missing `contents`            → `ai-error-empty-contents`
 *   - a role outside the captured list    → `ai-error-bad-role`
 *   - a model-turn functionCall part with no thoughtSignature
 *                                         → `ai-error-fncall-missing-thought-signature`
 *
 * It also announces the refusals production does NOT throw for: a safety /
 * recitation / blocklist block arrives as a 200 with an empty candidate, so
 * the broker lands a `response_blocked` event ({@link emitBlockIfBlocked})
 * alongside the normal op event. Without it a filtered answer is
 * indistinguishable from a model that simply had nothing to say.
 *
 * The same goes for a model SUBSTITUTION ({@link emitModelSubstitution}): an
 * engine that redirects the requested model (an openai `modelMap` entry or
 * catch-all `model`, a gemini experimental alias) answers normally, so
 * nothing anywhere says the developer tested a model they never named.
 *
 * Event emission is best-effort behind one small choke-point ({@link emit}):
 * a throw from the emit path (or any event consumer downstream) must never
 * poison the AI operation the caller just completed — handler errors are the
 * consumer's problem, never the broker's (the sandbox's emit fan-out already
 * isolates listener throws; this guard covers the emit path itself).
 */

import type { Sandbox } from 'pyric/sandbox';
import { emitSandboxEvent, getClock, makeServiceMutationEvent } from 'pyric/sandbox/internal';
import type { AiEventOperation } from '../events.js';

import { describeResponseBlock } from '../blocked.js';
import { AiBrokerError, Synthesizer, badRole, emptyContents, missingThoughtSignature } from './synthesizer.js';
import { ScriptedEngine } from './scripted-engine.js';
import { OpenAiEngine } from './openai-engine.js';
import { GeminiEngine, GEMINI_DEFAULT_BASE_URL } from './gemini-engine.js';
import type {
  AnswerEngine,
  CountTokensRequest,
  CountTokensResponse,
  EngineConfig,
  GenerateContentRequest,
  ModelResolution,
  RawEnvelope,
  WireChunk,
  WireResponse,
} from './types.js';

/**
 * Roles production accepts, from the captured rejection text
 * (`ai-error-bad-role`): "Please use a valid role: SYSTEM, SYSTEM_1, USER,
 * ASSISTANT, DEVELOPER, CONTEXT, USER_CONTEXT, MODEL, USER." — compared
 * case-insensitively (the SDK sends lowercase `user`/`model`). `FUNCTION` is
 * additionally accepted: the captured message omits it, yet production
 * accepted the SDK's function-response turn (`ai-function-response-round`),
 * and the installed SDK threads those turns with role `function`.
 */
const ACCEPTED_ROLES = new Set([
  'SYSTEM',
  'SYSTEM_1',
  'USER',
  'ASSISTANT',
  'DEVELOPER',
  'CONTEXT',
  'USER_CONTEXT',
  'MODEL',
  'FUNCTION',
]);

export interface AiBrokerOptions {
  /** Engine config, or a fully custom engine. Default: zero-config scripted. */
  engine?: EngineConfig | AnswerEngine;
  /** When present, ops land on the sandbox's unified event stream. */
  sandbox?: Sandbox;
}

function isAnswerEngine(value: EngineConfig | AnswerEngine): value is AnswerEngine {
  return typeof (value as AnswerEngine).generateContent === 'function';
}

/** What Studio's stream (and the construction log line) name the engine. */
type EngineKind = 'scripted' | 'openai' | 'gemini' | 'custom';

/**
 * What a status read reports about the resolved engine: the mode it is
 * running in, the model and upstream it answers through when it has one, and
 * whether a key is configured. Never the key itself, its prefix, or its
 * length.
 */
export interface AiEngineStatus {
  engine: EngineKind;
  model?: string;
  upstream?: string;
  keyPresent: boolean;
}

export class AiBroker {
  readonly engine: AnswerEngine;
  private readonly sandbox: Sandbox | undefined;
  private readonly engineKind: EngineKind;
  private readonly engineModel: string | undefined;
  private readonly engineBaseUrl: string | undefined;

  constructor(options: AiBrokerOptions = {}) {
    this.sandbox = options.sandbox;
    const engine = options.engine ?? { kind: 'scripted' as const };
    if (isAnswerEngine(engine)) {
      this.engine = engine;
      this.engineKind = 'custom';
    } else if (engine.kind === 'scripted') {
      this.engine = new ScriptedEngine(engine.script ?? [], new Synthesizer());
      this.engineKind = 'scripted';
    } else if (engine.kind === 'gemini') {
      this.engine = new GeminiEngine(engine);
      this.engineKind = 'gemini';
      this.engineBaseUrl = engine.baseUrl;
    } else {
      this.engine = new OpenAiEngine(engine);
      this.engineKind = 'openai';
      this.engineModel = engine.model;
      this.engineBaseUrl = engine.baseUrl;
    }
    console.info(this.describeEngine());
  }

  /** Snapshot routing before execution; never treat a scripted modelVersion as identity. */
  observationIdentity(model: string): AiEvidence {
    let routed: ModelResolution | undefined;
    try { routed = this.engine.resolveEffectiveModel?.(model); } catch { /* Diagnostic only. */ }
    return { requestedModel: model, engine: this.engineKind,
      ...(routed ? { routedModel: routed.model, mappingReason: routed.reason } : {}),
      endpoint: aiEndpoint(this.engineBaseUrl ?? (this.engineKind === 'gemini' ? GEMINI_DEFAULT_BASE_URL : undefined)),
      usageSource: this.engineKind === 'scripted' ? 'scripted' : 'unknown' };
  }
  private annotate<T extends WireResponse>(response: T, identity: AiEvidence): T {
    const usage = response.usageMetadata;
    const original = getAiEvidence(response);
    const valid = (n: unknown) => typeof n === 'number' && Number.isFinite(n) && n >= 0 ? n : undefined;
    return setAiEvidence(response, { ...identity,
      ...(identity.engine === 'gemini' ? { reportedModel: response.modelVersion, usageSource: usage ? 'backend' as const : 'unknown' as const } : {}),
      ...original, inputTokens: valid(usage?.promptTokenCount), outputTokens: valid(usage?.candidatesTokenCount), totalTokens: valid(usage?.totalTokenCount) });
  }

  /** One-line construction-time summary of what this broker resolved to. */
  private describeEngine(): string {
    const isOpenAiEngine = this.engineKind === 'openai';
    if (isOpenAiEngine) {
      return `[pyric/ai] engine resolved: openai (model=${this.engineModel ?? 'passthrough'}, upstream=${this.engineBaseUrl})`;
    }
    const isGeminiEngine = this.engineKind === 'gemini';
    if (isGeminiEngine) {
      return `[pyric/ai] engine resolved: gemini (upstream=${this.engineBaseUrl ?? 'https://generativelanguage.googleapis.com'})`;
    }
    const isCustomEngine = this.engineKind === 'custom';
    if (isCustomEngine) {
      return '[pyric/ai] engine resolved: custom AnswerEngine';
    }
    return '[pyric/ai] engine resolved: scripted (zero-config unless a script is queued)';
  }

  /**
   * The engine, model, upstream, and whether a key is configured, for a
   * status read. Never the key itself: only {@link GeminiEngine.hasKeyConfigured}'s
   * boolean crosses this seam.
   */
  describeStatus(): AiEngineStatus {
    const keyPresent = this.engine instanceof GeminiEngine ? this.engine.hasKeyConfigured() : false;
    const status: AiEngineStatus = { engine: this.engineKind, keyPresent };
    if (this.engineModel !== undefined) status.model = this.engineModel;
    const upstream =
      this.engineKind === 'gemini' ? (this.engineBaseUrl ?? GEMINI_DEFAULT_BASE_URL) : this.engineBaseUrl;
    if (upstream !== undefined) status.upstream = upstream;
    return status;
  }

  /** Additive detail fields every emitted event carries so Studio can show the engine. */
  private engineDetail(): Record<string, unknown> {
    const detail: Record<string, unknown> = {
      engine: this.engineKind,
    };
    const isOpenAiEngine = this.engineKind === 'openai';
    if (isOpenAiEngine) {
      detail.model = this.engineModel;
      detail.baseUrl = this.engineBaseUrl;
    }
    const isGeminiEngine = this.engineKind === 'gemini';
    if (isGeminiEngine) {
      detail.baseUrl = this.engineBaseUrl ?? 'https://generativelanguage.googleapis.com';
    }
    return detail;
  }

  /**
   * Announce a SAFETY / RECITATION / BLOCKLIST / … block on the event stream.
   *
   * A block is the broker's SILENT refusal: unlike `request_rejected` nothing
   * throws (production answers 200 with an empty candidate), so an app that
   * renders whatever `text()` gave it just shows nothing, and the developer
   * gets no signal anywhere. Emitting at RESPONSE time (not from the response
   * helpers, which only fire if someone reaches for content) means the event
   * lands whether or not the caller ever asks for the text.
   *
   * Detection is `blocked.ts`'s, shared verbatim with the response helpers'
   * throw path, so the stream and the thrown error can never disagree.
   *
   * Returns whether the envelope WAS blocked, so the stream wrapper can
   * announce at most once across its chunks.
   */
  private emitBlockIfBlocked(model: string, response: WireResponse): boolean {
    const block = describeResponseBlock(response);
    if (block === null) return false;
    this.emit('response_blocked', model, { ...block });
    return true;
  }

  /**
   * Announce that the engine will answer as a DIFFERENT model than the one
   * requested.
   *
   * A substitution is the quietest failure the broker has: nothing throws,
   * content comes back, and the developer concludes they tested model X when
   * model Y answered (an openai `modelMap` entry or catch-all `model`, a
   * gemini experimental alias). Only engines that actually redirect implement
   * {@link AnswerEngine.resolveEffectiveModel}; the rest are silent by
   * construction.
   *
   * Fired at REQUEST time, before delegating: the swap is a property of the
   * call about to go out, so it lands even when that call then fails.
   * Comparison is bare-vs-bare, since `models/x` to `x` is the wire's prefix
   * convention rather than a substitution, and an exact match emits nothing.
   *
   * `countTokens` is deliberately not announced: the openai engine never
   * sends a model there at all (the count is synthesized locally), so an
   * announcement would name an upstream call that never happens.
   */
  private emitModelSubstitution(model: string): void {
    const resolve = this.engine.resolveEffectiveModel;
    if (typeof resolve !== 'function') return;
    let effective: ModelResolution;
    try {
      effective = resolve.call(this.engine, model);
    } catch {
      // A misbehaving engine's self-report must never fail the op.
      return;
    }
    const requestedBare = model.startsWith('models/') ? model.slice('models/'.length) : model;
    if (effective.model === requestedBare) return;
    this.emit('model_substituted', model, {
      requestedModel: model,
      effectiveModel: effective.model,
      reason: effective.reason,
    });
  }

  private emitRejectionIfBrokerError(model: string, err: unknown): void {
    const code = err instanceof AiBrokerError ? err.envelope.error.code : 500;
    const status = err instanceof AiBrokerError ? err.envelope.error.status : 'INTERNAL';
    const message = err instanceof AiBrokerError
      ? err.envelope.error.message
      : err instanceof Error ? err.message : String(err);
    this.emit('request_rejected', model, { code, status, message });
  }

  async generateContent(req: GenerateContentRequest, model: string): Promise<WireResponse> {
    const identity = this.observationIdentity(model);
    this.validate(req, model);
    this.emitModelSubstitution(model);
    try {
      const response = await this.engine.generateContent(req, model);
      this.emit('generate_content', model, {
        contentCount: req.contents.length,
        finishReason: response.candidates?.[0]?.finishReason,
        totalTokenCount: response.usageMetadata?.totalTokenCount,
        responseId: response.responseId,
      });
      this.emitBlockIfBlocked(model, response);
      return this.annotate(response, identity);
    } catch (err) {
      this.emitRejectionIfBrokerError(model, err);
      throw err;
    }
  }

  /**
   * Chunk objects with the captured framing SEMANTICS (finishReason last
   * chunk only, usageMetadata every chunk). Validation runs EAGERLY — a bad
   * request throws here, before iteration, the way production answers with
   * an HTTP error instead of a stream.
   */
  streamGenerateContent(req: GenerateContentRequest, model: string): AsyncIterable<WireChunk> {
    const identity = this.observationIdentity(model);
    this.validate(req, model);
    this.emitModelSubstitution(model);
    const inner = this.engine.streamGenerateContent(req, model);
    const annotate = (chunk: WireChunk) => this.annotate(chunk, identity);
    const emit = (chunkCount: number) =>
      this.emit('stream_generate_content', model, {
        contentCount: req.contents.length,
        chunkCount,
      });
    const emitRejection = (err: unknown) => this.emitRejectionIfBrokerError(model, err);
    // A block surfaces on whichever chunk carries the finish reason (the last
    // one, per the captured framing), so it is announced DURING iteration:
    // an abandoned stream still reports why it produced nothing. At most one
    // per stream: the aggregate has a single blocking reason, not one per chunk.
    let announcedBlock = false;
    const emitBlock = (chunk: WireChunk) => {
      if (announcedBlock) return;
      announcedBlock = this.emitBlockIfBlocked(model, chunk);
    };
    return (async function* wrapped(): AsyncGenerator<WireChunk> {
      let chunkCount = 0;
      try {
        for await (const chunk of inner) {
          chunkCount++;
          emitBlock(chunk);
          yield annotate(chunk);
        }
        emit(chunkCount);
      } catch (err) {
        emitRejection(err);
        throw err;
      }
    })();
  }

  async countTokens(req: CountTokensRequest, model: string): Promise<CountTokensResponse> {
    const identity = this.observationIdentity(model);
    this.validateContents(req, model);
    try {
      const response = await this.engine.countTokens(req, model);
      this.emit('count_tokens', model, { totalTokens: response.totalTokens });
      return setAiEvidence(response, { ...identity, totalTokens: response.totalTokens, usageSource: this.engineKind === 'gemini' ? 'backend' : this.engineKind === 'openai' ? 'estimated' : this.engineKind === 'scripted' ? 'scripted' : 'unknown' });
    } catch (err) {
      this.emitRejectionIfBrokerError(model, err);
      throw err;
    }
  }

  // ── Production-shaped validation ──────────────────────────────────────────

  private validate(req: GenerateContentRequest, model: string): void {
    this.validateContents(req, model);
    // Model turns threading a functionCall back in MUST carry the
    // thoughtSignature production minted (`ai-error-fncall-missing-thought-signature`).
    for (let i = 0; i < req.contents.length; i++) {
      const content = req.contents[i]!;
      if ((content.role ?? '').toUpperCase() !== 'MODEL') continue;
      for (const part of content.parts ?? []) {
        if (part.functionCall && part.thoughtSignature === undefined) {
          // `position` is the 1-based index of the offending content turn.
          this.reject(model, missingThoughtSignature(part.functionCall.name, i + 1));
        }
      }
    }
  }

  private validateContents(req: { contents: unknown }, model: string): void {
    const contents = req.contents;
    if (!Array.isArray(contents) || contents.length === 0) {
      this.reject(model, emptyContents());
    }
    for (const content of contents as GenerateContentRequest['contents']) {
      const role = content.role ?? '';
      if (!ACCEPTED_ROLES.has(role.toUpperCase())) {
        this.reject(model, badRole(role));
      }
    }
  }

  /** Emit the rejection onto the event stream, then throw the wire envelope. */
  private reject(model: string, envelope: AiBrokerError['envelope']): never {
    this.emit('request_rejected', model, {
      code: envelope.error.code,
      status: envelope.error.status,
      message: envelope.error.message,
    });
    throw new AiBrokerError(envelope);
  }

  // ── Event emission (Studio stream consumer seam) ──────────────────────────

  /**
   * Land a broker operation on the sandbox's unified event stream.
   * Best-effort, storage-precedent: a throw from the emit path must never
   * fail the AI operation the caller just completed.
   */
  private emit(op: AiEventOperation, model: string, detail: Record<string, unknown>): void {
    if (this.sandbox === undefined) return;
    try {
      emitSandboxEvent(
        this.sandbox,
        makeServiceMutationEvent({
          at: getClock(this.sandbox).now(),
          service: 'ai',
          op,
          path: model,
          auth: null,
          detail: { ...detail, ...this.engineDetail() },
        }),
        { service: 'ai' },
      );
    } catch {
      // Observational — never let event emission break an AI op.
    }
  }
}

/**
 * Fixture helper: extract `behavior.raw` from a parsed oracle observation
 * JSON so a capture pastes straight into a script entry
 * (`{ respond: loadObservationEnvelope(obs) }`). Captures are the corpus.
 */
export function loadObservationEnvelope(obsJson: unknown): RawEnvelope {
  const raw = (obsJson as { behavior?: { raw?: unknown } })?.behavior?.raw;
  if (
    raw === null ||
    typeof raw !== 'object' ||
    !Array.isArray((raw as RawEnvelope).candidates)
  ) {
    throw new Error(
      'loadObservationEnvelope: observation has no behavior.raw response envelope (expected a capture with candidates)',
    );
  }
  return structuredClone(raw) as RawEnvelope;
}
