/**
 * `pyric/sandbox/internal` — adapter-only protocol surface.
 *
 * Service adapter packages (`pyric-admin`, future `pyric/firestore`,
 * `pyric/auth`, etc.) consume this subpath to reach the underlying
 * `LocalEnvironment` and any other primitives that need to flow
 * through the sandbox boundary.
 *
 * **Not part of the public API.** The shape is subject to change
 * without breaking-change semantics across `pyric/sandbox` versions.
 * External adapter authors shouldn't rely on this — when the protocol
 * stabilizes (post-multi-service architecture) it'll be promoted.
 *
 * Documented in the design rationale section "Migration
 * scope summary".
 */
export { getInternalEnv } from './sandbox-impl.js';
export { decodeImportBundle, validatePersistenceEncoding } from '../persistence/import-bundle.js';
export { validatePersistedService, persistedServiceHasData, UnsupportedPersistedServiceError } from '../persistence/validate-services.js';
export { seedUserSchema, storedMetadataSchema } from './state-schemas.js';
export { captureIndexQuery, analyzeIndexQuery, readIndexConfig, type IndexQuery, type IndexFinding } from '../../rules/indexes/query-analysis.js';
export type { IndexesConfig, IndexesConfigEntry } from '../../rules/indexes/types.js';
export {
  analyzeServiceIndex, captureDatabaseIndexQuery, databaseIndexLocations, indexService, isDatabaseIndexQuery,
  type DatabaseIndexQuery, type DatabaseIndexDefinition, type DatabaseIndexConfig,
  type ServiceIndexQuery, type ServiceIndexConfig, type ServiceIndexDefinition, type ServiceIndexFinding,
} from '../../rules/indexes/service-query.js';
export { observationService, type SdkObservation } from './sdk-observation.js';
export { runSdkWrite } from './sdk-write-activity.js';
export { createSdkRates, createSdkRateMonitor, sdkRates } from './sdk-rates.js';
export type { AiRequestObservation, SdkRateSnapshot, SdkServiceRate, SdkMethodRate, SdkRateBucket } from './sdk-rates.js';
export { sdkMethodCoverage } from './sdk-coverage.js';
export type { SdkMethodCoverage, SdkMethodCategory } from './sdk-coverage.js';
export {
  createSdkActivityJournal,
  finishSdkRead,
  sdkActivity,
  type SdkActivityEvent,
  type SdkActivityHandle,
  type SdkActivityRecord,
  type SdkActivitySource,
} from './sdk-activity.js';
// Listener attribution: the owner records pyric stamps onto its own listener
// events. Every mirrored surface with listeners reaches these, so they live in
// the cross-surface runtime rather than in one surface's backend.
export {
  configureListenerAttribution,
  listenerAttributionEnabled,
  listenerAttributionMode,
  type ListenerAttributionMode,
} from '../attribution/attribution-mode.js';
export {
  callerFrameFromStack,
  captureCreationFrame,
  listenerAttachOwners,
  tagOwnerFor,
  type ComponentOwnerInput,
  type ListenerAttribution,
  type ListenerOwnerHint,
  type RecordedListenerOwners,
} from '../attribution/listener-owners.js';
export { recordEffectRegions } from '../attribution/effect-regions.js';
export {
  isSelectableElement,
  ownerSelectorFor,
  tagNameOf,
  type SelectableElement,
} from '../attribution/element-selector.js';
export { getClock } from '../clock.js';
export { stampProvenance } from './provenance.js';
export { bindOperationContext } from '../sandbox-context.js';
export {
  provenanceForOperationContext,
  resolveOperationContext,
} from '../operation-record.js';

// Pyric Studio event-unification seam: the provenance-stamping emit
// choke-point non-Firestore services (auth/storage/rtdb) call to land
// activity on the unified `onEvent`/`history()` stream. Firestore rides
// the env→sandbox fan-out and doesn't need this. `stampProvenance` is
// exported for callers that need to compute the stamped shape without
// dispatching (e.g. branch/replay tooling). See the design rationale.
// `makeServiceMutationEvent` builds the generic cross-service mutation
// envelope (id/at minted from the shared counter) auth/storage/rtdb emit.
export {
  emitSandboxEvent,
  primeEventHistory,
  makeSandboxCommitEvent,
  makeSandboxListenerEvent,
  makeSandboxOperationEvent,
  makeSandboxRuntimeErrorEvent,
  makeServiceMutationEvent,
} from './sandbox-impl.js';

// LocalEnvironment + its closest siblings moved here in Slice 7.
// Surfacing them through the /internal sub-path keeps the public
// surface narrow (consumers compose via `getFirestore(ctx)`, not by
// constructing LocalEnvironment directly) while letting adapter
// packages reach the runtime.
//
// Star re-exports because admin-compat (in sdk) reaches in for a
// long tail of helper symbols (DELETE_MARKER, KEEP,
// FIRESTORE_ERROR_CODES, etc.). Anyone changing the moved files'
// public exports automatically gets them propagated here.
// local-environment exports BatchResult as its own outer shape;
// local-state has a different (internal) BatchResult — alias the
// local-state one to disambiguate. Same trick for DocumentData
// (one canonical export from local-state; local-environment
// re-exports it).
export * from '../../firestore/sandbox/local-environment.js';
export {
  LocalState,
  type BatchOperation,
  type BatchResult as LocalStateBatchResult,
  type CreateResult,
  type UpdateResult,
  type SetResult,
  type DeleteResult,
} from '../../firestore/sandbox/local-state.js';
export * from '../../firestore/sandbox/event-log.js';
export * from '../../firestore/sandbox/auto-id.js';
export * from '../../firestore/sandbox/transaction.js';
export * from '../../firestore/sandbox/transaction-merge.js';
export * from '../../firestore/sandbox/transaction-types.js';
export * from '../../firestore/sandbox/errors.js';
export * from '../../firestore/sandbox/value-resolver.js';
export * from '../../firestore/sandbox/converters/timestamp.js';
export * from '../../firestore/sandbox/converters/user-timestamp.js';
export * from '../../firestore/sandbox/converters/reference.js';
export * from '../../firestore/sandbox/converters/vector.js';
export * from '../../firestore/sandbox/converters/fieldvalue.js';
export * from '../../firestore/sandbox/converters/bytes-geopoint.js';
export * from '../../firestore/sandbox/snapshot-listeners.js';
// Wire-encoder: produces Firestore JSON wire-format from sandbox
// values. Used by the discover crawler's sandbox adapter (in
// pyric/firestore/discover) to bridge LocalEnvironment ↔ the wire
// decoder.
export * from '../../firestore/sandbox/wire-encoder.js';

// Pre-mortem H3 — the star re-exports above are NOT auditable by
// reading this file. If two of the re-exported modules introduce a
// same-named symbol, `tsc --noEmit` fails loudly at build time (this
// has happened: BatchResult / DocumentData collisions, both
// disambiguated above). When adding a new symbol to any of the
// listed modules, check for collisions against the other modules in
// this list first. Future-us should consider replacing the stars
// with explicit named re-exports once the admin-compat layer's
// surface stops drifting.
export { createSandboxRoot } from './root.js';

export { assertCompleteHistory } from './history-integrity.js';
export { EventHistory } from './event-history.js';
export { firestoreReadUsage } from './usage-evidence.js';
export type { UsageEvidence } from './usage-evidence.js';

export { OBSERVATION_HISTORY_LIMITS } from './observation-history.js';
export { observationPayload, observationText } from './observation-payload.js';

export { aiCompletionUsage } from './usage-evidence.js';
export { requestStatusLabel } from '../types/request-observation.js';

export { createActiveListenerState } from '../active-listeners.js';
