/** Cross-service operation identity and Security Rules disposition. */

import type { MutationEventService } from './service-event-records.js';

/** Which sandbox service emitted an event. Firestore is named directly because
 * it rides its own rule-eval-shaped `request`/`write` path rather than the
 * cross-service mutation envelope; every other service reaches this union by
 * declaring an event record beside its own code. */
export type EventService = 'firestore' | 'runtime' | MutationEventService;

/** Who initiated the operation behind an event. Missing source is represented
 * explicitly as `unattributed`; it is never silently promoted to app traffic. */
export type EventActor =
  | { kind: 'app'; journeyId?: string }
  | { kind: 'studio' }
  | { kind: 'agent'; name: string }
  | { kind: 'app-builder' }
  | { kind: 'unattributed' };

/** The identity/rules lens an operation actually ran under. */
export type AuthLens =
  | { mode: 'admin' }
  | { mode: 'as'; uid: string; tenant?: string; token?: Record<string, unknown> }
  | { mode: 'app-session' }
  | { mode: 'anon' };

/** Immutable operation provenance, bound where an operation is issued.
 * Source and auth lens are deliberately orthogonal: Studio may evaluate rules
 * as a user, while an app or agent may use an admin lens. */
export interface OperationContext {
  readonly source: EventActor;
  readonly authLens: AuthLens;
  readonly planId?: string;
}

/** An evaluated/deny disposition records a local rejection, not proof completeness
 * or Firebase parity. Consumers must also inspect accompanying queryProof.
 * What happened at the Security Rules seam. Admin is a lens; `bypassed` is
 * the rules disposition. */
export type RulesDisposition =
  | { kind: 'evaluated'; verdict: 'allow' | 'deny' }
  | { kind: 'bypassed'; reason: 'admin' }
  | {
      kind: 'not-evaluated';
      /** External execution supplies an SDK outcome, without a local rules evaluation. */
      reason: 'no-rules' | 'unsupported' | 'not-a-rules-operation' | 'runtime-error' | 'external-execution';
    };

/** Provenance consumed only by the firestore activity diagnostics. Bundled in
 * one optional record so the shared operation type carries a single
 * activity-owned seam rather than loose per-feature fields. */
export interface ActivityEventProvenance {
  /** Stable host subscription identity used only by activity diagnostics. */
  listenerId?: string;
  /** Marks lifecycle caused by transparent auth reauthorization, not app code. */
  listenerLifecycle?: 'reauthorize';
  /** Marks worker-split operations that belong to a transaction for activity diagnostics. */
  groupKind?: 'transaction';
}

/** Compatibility provenance carried by sandbox events while producers and
 * consumers migrate to the canonical `operationContext`. */
export interface EventProvenance {
  /** Wall-clock observation time, independent of the simulated service clock. */
  observedAt?: number;
  service?: EventService;
  actor?: EventActor;
  authLens?: AuthLens;
  operationContext?: OperationContext;
  /** Set when the op is part of an agent plan. */
  planId?: string;
  /** Firestore activity-diagnostics provenance; absent outside that flow. */
  activity?: ActivityEventProvenance;
}
