/**
 * `pyric/firestore` — document writes.
 *
 * `setDoc` / `updateDoc` / `deleteDoc` / `addDoc` and the modular
 * `SetOptions` shape. Operations route through the sandbox's chainable
 * adapter, running any converter on `setDoc` / `addDoc`.
 */
import { runSdkWrite } from '../sandbox/internal/sdk-write-activity.js';
import { beginFirestoreActivity } from './sdk-activity.js';
import type {
  DocumentData,
  SetOptions as ChainSetOptions,
} from 'pyric/sandbox/admin-firestore';

import {
  targetOf,
  converterOf,
  chainDocFor,
  chainCollFor,
  tagSandboxRef,
  buildSandboxShell,
} from './state.js';
import type {
  DocumentReference,
  CollectionReference,
  FirestoreDataConverter,
} from './types.js';
import { withFirestoreFirebaseError } from './errors.js';
import { clientStateFor } from './client-state.js';
import {
  boundedActivityIdentity,
  registerActivityValue,
} from './sandbox/activity-value-registry.js';
import {
  copyQueryValueRegistration,
  registerReferenceQueryValue,
} from './sandbox/query-value-registry.js';

// ─── Writes ───────────────────────────────────────────────────────────

/**
 * Modular Web-SDK-shaped `SetOptions`. Either flag controls how `data`
 * combines with the existing document; passing nothing replaces the
 * existing doc entirely (Firestore default).
 *
 *   - `{ merge: true }` — shallow-merge every top-level field in
 *     `data` into the existing document, preserving fields not in
 *     `data`. Equivalent to `firebase/firestore`'s `setDoc(ref, data,
 *     { merge: true })`.
 *   - `{ mergeFields: [...] }` — project `data` to just the listed
 *     top-level fields, then merge. Other fields in `data` are
 *     ignored; other fields in the existing doc are preserved.
 *
 * `merge` and `mergeFields` are mutually exclusive; passing both is
 * a programming error (`mergeFields` wins on the sandbox path,
 * matching the JS SDK's effective behavior).
 */
export interface SetOptions {
  merge?: boolean;
  mergeFields?: readonly string[];
}

export async function setDoc<T = DocumentData>(
  ref: DocumentReference<T>,
  data: T,
  options?: SetOptions,
): Promise<void> {
  const target = targetOf(ref);
  return runSdkWrite(beginFirestoreActivity(target, ref, 'setDoc', 'operation'), async () => {
    const conv = converterOf(ref);
    const payload = conv
      ? (conv as FirestoreDataConverter<T>).toFirestore(data)
      : (data as unknown as DocumentData);
    return clientStateFor(target).runWrite(
      () => withFirestoreFirebaseError(() =>
        chainDocFor(target, ref).set(payload, options as ChainSetOptions | undefined),
      ),
      ref.path,
    );
  });
}

/**
 * `updateDoc` does NOT run the converter. Matches `firebase/firestore`'s
 * Web SDK shape — partial updates can target any subset of fields, so
 * a translator built around a full `AppModelType` would be a type-shape
 * mismatch. Use the underlying `DocumentData` view (`withConverter(ref,
 * null)`) for typed-and-untyped mixed access if you need both styles
 * against the same path.
 */
export async function updateDoc(ref: DocumentReference, data: DocumentData): Promise<void> {
  const target = targetOf(ref);
  return runSdkWrite(beginFirestoreActivity(target, ref, 'updateDoc', 'operation'), async () => {
    return clientStateFor(target).runWrite(
      () => withFirestoreFirebaseError(() => chainDocFor(target, ref).update(data)),
      ref.path,
    );
  });
}

export async function deleteDoc(ref: DocumentReference): Promise<void> {
  const target = targetOf(ref);
  return runSdkWrite(beginFirestoreActivity(target, ref, 'deleteDoc', 'operation'), async () => {
    return clientStateFor(target).runWrite(
      () => withFirestoreFirebaseError(() => chainDocFor(target, ref).delete()),
      ref.path,
    );
  });
}

export async function addDoc<T = DocumentData>(
  coll: CollectionReference<T>,
  data: T,
): Promise<DocumentReference<T>> {
  const target = targetOf(coll);
  return runSdkWrite(beginFirestoreActivity(target, coll, 'addDoc', 'operation'), async () => {
    const conv = converterOf(coll);
    const payload = conv
      ? (conv as FirestoreDataConverter<T>).toFirestore(data)
      : (data as unknown as DocumentData);
    const ref = await clientStateFor(target).runWrite(async () => {
      const created = await withFirestoreFirebaseError(() => chainCollFor(target, coll).add(payload));
      clientStateFor(target).cachePath(created.path);
      return created;
    });
    const absPath = (ref as unknown as { path: string }).path;
    const tagged = tagSandboxRef(
      ref as object,
      target,
      (fresh) => fresh.doc(absPath) as unknown as object,
    );
    registerActivityValue(tagged, boundedActivityIdentity('reference', absPath));
    registerReferenceQueryValue(tagged, absPath, target, tagged);
    if (conv) {
      const shell = buildSandboxShell(
        tagged as { id: string; path: string },
        target,
        conv,
      );
      copyQueryValueRegistration(tagged, shell);
      return shell as DocumentReference<T>;
    }
    return tagged as DocumentReference<T>;
  });
}

import { writeBatch } from './transactions.js';
import type { Firestore, WriteBatch } from './types.js';

export function ensureFirestoreConfigured(db: Firestore): void {
  targetOf(db);
}

export async function executeWrite<T>(db: Firestore, action: (batch: WriteBatch) => Promise<T>): Promise<T> {
  const batch = writeBatch(db);
  const result = await action(batch);
  await batch.commit();
  return result;
}

