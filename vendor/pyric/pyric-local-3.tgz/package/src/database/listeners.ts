import { sdkActivity, type SdkActivityHandle } from '../sandbox/internal/sdk-activity.js';
import { beginDatabaseActivity } from './sdk-activity.js';
import type { AuthState } from 'pyric/sandbox';
import { ListenerRegistry, type ListenerRegistration } from './listener-registry.js';
import { jsonValuesEqual, type JsonValue } from './sandbox/data-tree.js';
import { authFor, targetOf, type Target } from './routing.js';
import { isDefaultQuerySpec, isQuery, queryIdentifier } from './query-shape.js';
import { executeQuery, type QueryRow } from './internal/query-projection.js';
import type { DataSnapshot, DatabaseReference, ListenOptions, Query, Unsubscribe } from './types.js';
import type { ListenerAttribution } from '../sandbox/attribution/listener-owners.js';
import { child } from './references.js';
import { buildSandboxQuerySnap, buildSandboxSnapFromRaw } from './snapshots.js';

// ─── Listeners (Tier 2) ──────────────────────────────────────────────

/**
 * RTDB evaluates a listener with the Auth instance attached to its app. When
 * that app's session changes, replace the backend registration with one made
 * under the new identity. Registrations belonging to other app sessions are
 * untouched even though all equal-config apps share one data backend.
 */
function subscribeWithLiveAuth(
  target: Target,
  subscribe: (auth: AuthState, onCanceled: () => void) => Unsubscribe,
  onTerminal?: () => void,
): Unsubscribe {
  let stopped = false;
  let backendUnsubscribe: Unsubscribe = () => {};
  let sessionUnsubscribe: Unsubscribe | undefined;
  let release: Unsubscribe | undefined;
  const stop = (): void => {
    if (stopped) return;
    stopped = true;
    sessionUnsubscribe?.();
    backendUnsubscribe();
    release?.();
    onTerminal?.();
  };

  backendUnsubscribe = subscribe(authFor(target), stop);
  sessionUnsubscribe = target.kind === 'sandbox-live'
    ? target.onCurrentUserChanged?.(() => {
      if (stopped) return;
      backendUnsubscribe();
      try {
        backendUnsubscribe = subscribe(authFor(target), stop);
      } catch {
        backendUnsubscribe = () => {};
        stop();
      }
    })
    : undefined;
  release = target.kind === 'sandbox-live' ? target.own?.(stop) : undefined;
  return stop;
}

/**
 * The attribution a listen call carries, or `undefined` when it carries none.
 * The backend takes both inputs as one argument.
 */
function attributionOf(options: ListenOptions | undefined): ListenerAttribution | undefined {
  if (options === undefined) return undefined;
  if (options.owner === undefined && options.owners === undefined) return undefined;
  return { owner: options.owner, owners: options.owners };
}

/**
 * The listen options a recursive `onlyOnce` subscribe should keep: the
 * attribution, never `onlyOnce` itself, which the outer call already honored.
 */
function ownerOnlyOptions(options: ListenOptions | undefined): ListenOptions | undefined {
  return attributionOf(options);
}

function queryScope(r: DatabaseReference | Query): string {
  return queryIdentifier(r._spec);
}

/**
 * `onValue(ref, cb)` — subscribe to value changes at the ref's path.
 *
 * Fires immediately on subscribe with the current value (or
 * `null` + `exists: false` for an absent path), then on every
 * subsequent write that touches the path or any descendant.
 *
 * Returns an unsubscribe function. The unsubscribe is idempotent;
 * calling it twice is a no-op.
 *
 * `options.onlyOnce` (DB-B12): when `true`, the listener auto-unsubscribes
 * after its first fire (mirrors `api/Reference_impl.ts:975-980`).
 *
 * With a cancellation callback, an initially denied listen returns normally
 * and reports the Firebase `PERMISSION_DENIED` error asynchronously. Without
 * one, the sandbox preserves its legacy synchronous throw.
 */
export function onValue(
  r: DatabaseReference | Query,
  cb: (snap: DataSnapshot) => void,
  cancelCallbackOrOptions?: ((error: Error) => void) | ListenOptions,
  options?: ListenOptions,
): Unsubscribe {
  const listenOptions = typeof cancelCallbackOrOptions === 'function' ? options : cancelCallbackOrOptions;
  const activity = beginDatabaseActivity(r, 'onValue', 'subscription', attributionOf(listenOptions));
  // onlyOnce may detach before invoking a captured initial callback.
  const lifecycle = listenOptions?.onlyOnce ? { ...activity, close: () => queueMicrotask(() => activity.close()) } : activity;
  const next = (snap: DataSnapshot): void => { activity.delivered(snap); cb(snap); };
  try {
    return sdkActivity.registering(activity, () => onValueInternal(r, next, cancelCallbackOrOptions, options, cb, lifecycle));
  } catch (error) { activity.fail(); throw error; }
}

function observeConnectionMetadata(
  query: Query,
  callback: (snapshot: DataSnapshot) => void,
  registryCallback: (snapshot: DataSnapshot) => void,
  activity: SdkActivityHandle,
): Unsubscribe {
  const reference = query.ref;
  const target = targetOf(reference);
  const isMetadataRoot = reference._path === '/.info';
  const scope = queryScope(query);
  const hasConstraints = !isDefaultQuerySpec(query._spec);
  let stopped = false;
  let stopObserving: Unsubscribe = () => {};
  let release: Unsubscribe | undefined;
  let previousRows: QueryRow[] | undefined;
  const stop = (): void => {
    if (stopped) return;
    stopped = true;
    stopObserving();
    release?.();
    listenerRegistry.removeExact(target, reference._path, 'value', registryCallback, registration, scope);
    activity.close();
  };
  const registration: ListenerRegistration = { unsubscribe: stop };
  listenerRegistry.add(target, reference._path, 'value', registryCallback, registration, scope);
  const hasAppLifetime = target.kind === 'sandbox-live';
  if (hasAppLifetime) release = target.own?.(stop);
  stopObserving = target.connection.observeConnection((connected) => {
    if (stopped) return;
    const value = isMetadataRoot ? { connected, serverTimeOffset: 0 } : connected;
    const filtersChildren = isMetadataRoot && hasConstraints;
    let snapshot: DataSnapshot;
    if (filtersChildren) {
      const rows = executeQuery(value, query._spec);
      const isUnchangedSelection = jsonValuesEqual(previousRows, rows);
      if (isUnchangedSelection) return;
      previousRows = rows;
      snapshot = buildSandboxQuerySnap(target, reference, rows);
    } else {
      snapshot = buildSandboxSnapFromRaw(target, reference, value);
    }
    try {
      callback(snapshot);
    } catch {
      // Match ordinary RTDB listener isolation.
    }
  });
  if (stopped) stopObserving();
  return stop;
}

function onValueInternal(
  r: DatabaseReference | Query,
  cb: (snap: DataSnapshot) => void,
  cancelCallbackOrOptions: ((error: Error) => void) | ListenOptions | undefined,
  options: ListenOptions | undefined,
  registryCallback: (snap: DataSnapshot) => void,
  activity: SdkActivityHandle,
): Unsubscribe {
  const hasCancelCallback = typeof cancelCallbackOrOptions === 'function';
  const cancelCallback = hasCancelCallback ? cancelCallbackOrOptions : undefined;
  const reportsCancel = cancelCallback !== undefined;
  const listenOptions = hasCancelCallback ? options : cancelCallbackOrOptions;
  // `onlyOnce` (DB-B12): wrap the callback so it unsubscribes itself
  // after the first fire. The unsub is filled in once the real
  // subscription is created below.
  const isOnce = listenOptions?.onlyOnce === true;
  if (isOnce) {
    let unsub: Unsubscribe | null = null;
    let fired = false;
    const onceCb = (snap: DataSnapshot): void => {
      if (fired) return;
      fired = true;
      // `unsub` may not be assigned yet if the initial fire is
      // synchronous (the backend fires during subscribe, before
      // `onValue` returns). The post-subscribe check below covers it.
      const currentUnsubscribe = unsub;
      const hasUnsubscribe = currentUnsubscribe !== null;
      if (hasUnsubscribe) currentUnsubscribe();
      cb(snap);
    };
    unsub = onValueInternal(r, onceCb, cancelCallback, ownerOnlyOptions(listenOptions), registryCallback, activity);
    // Synchronous initial fire: `onceCb` ran before `unsub` was set, so
    // remove the now-stale listener here.
    if (fired) {
      unsub();
      return () => {};
    }
    return unsub;
  }
  const reference = r.ref;
  const isConnectionValue = reference._path === '/.info/connected';
  const isMetadataRoot = reference._path === '/.info';
  const hasDefaultQuery = isDefaultQuerySpec(r._spec);
  const observesConnection = isMetadataRoot || (hasDefaultQuery && isConnectionValue);
  if (observesConnection) return observeConnectionMetadata(r, cb, registryCallback, activity);
  // Query branch — fire only when the windowed result changes.
  // Locked by oracle observation `rtdb-modular-onvalue-with-query.json`:
  // a write OUTSIDE the window does NOT re-fire the listener; a write
  // INSIDE or one that displaces a member DOES.
  const isQueryTarget = isQuery(r);
  if (isQueryTarget) {
    const q = r;
    const target = targetOf(q.ref);
    const isAdmin = target.admin === true;
    const scope = queryScope(q);
    const deliver = (raw: { val: JsonValue; key: string | null; rows?: QueryRow[] }): void => {
      const rows = raw.rows ?? [];
      const snap = buildSandboxQuerySnap(target, q.ref, rows);
      try {
        cb(snap);
      } catch {
        // Listener throws are swallowed.
      }
    };
    // Admin (rules-bypass) listeners skip the read-rule gate entirely — the
    // listen-plane sibling of `adminGet`/`adminSet` (#401). `admin` is set
    // only on server-minted `getAdminDatabase` handles, never anything a page
    // controls, so a page's `onValue` stays on the rule-gated path below.
    let registration: ListenerRegistration | undefined;
    const unregister = (): void => {
      activity.close();
      const currentRegistration = registration;
      const hasRegistration = currentRegistration !== undefined;
      if (hasRegistration) {
        listenerRegistry.removeExact(target, q.ref._path, 'value', registryCallback, currentRegistration, scope);
      }
    };
    let subscribed: Unsubscribe;
    if (isAdmin) {
      subscribed = target.backend.adminOnValue(q.ref._path, deliver, q._spec);
    } else {
      subscribed = subscribeWithLiveAuth(
        target,
        (auth, onCanceled) => target.backend.onValue(
          auth,
          q.ref._path,
          deliver,
          q._spec,
          reportsCancel ? (error) => { activity.fail(); cancelCallback(error); } : undefined,
          () => { activity.fail(); onCanceled(); },
          attributionOf(listenOptions),
        ),
        unregister,
      );
    }
    let unsub = subscribed;
    if (isAdmin) unsub = () => { unregister(); subscribed(); };
    registration = { unsubscribe: unsub };
    listenerRegistry.add(target, q.ref._path, 'value', registryCallback, registration, scope);
    return unsub;
  }
  const ref0 = reference;
  const target = targetOf(ref0);
  const isAdmin = target.admin === true;
  const wrapper = (raw: { val: JsonValue; key: string | null }): void => {
    const snap = buildSandboxSnapFromRaw(target, ref0, raw.val);
    try {
      cb(snap);
    } catch {
      // Listener throws are swallowed — match `firebase/database`'s
      // behavior where one observer's exception doesn't block others.
    }
  };
  let registration: ListenerRegistration | undefined;
  const unregister = (): void => {
    activity.close();
    const currentRegistration = registration;
    const hasRegistration = currentRegistration !== undefined;
    if (hasRegistration) listenerRegistry.removeExact(target, ref0._path, 'value', registryCallback, currentRegistration);
  };
  let subscribed: Unsubscribe;
  if (isAdmin) {
    subscribed = target.backend.adminOnValue(ref0._path, wrapper);
  } else {
    subscribed = subscribeWithLiveAuth(
      target,
      (auth, onCanceled) => target.backend.onValue(
        auth,
        ref0._path,
        wrapper,
        undefined,
        reportsCancel ? (error) => { activity.fail(); cancelCallback(error); } : undefined,
        () => { activity.fail(); onCanceled(); },
        attributionOf(listenOptions),
      ),
      unregister,
    );
  }
  let unsub = subscribed;
  if (isAdmin) unsub = () => { unregister(); subscribed(); };
  registration = { unsubscribe: unsub };
  listenerRegistry.add(target, ref0._path, 'value', registryCallback, registration);
  return unsub;
}

/**
 * `onChildAdded(ref, cb)` — subscribe to child-added events at the
 * ref's path.
 *
 * Semantics (locked by oracle observations under
 * `packages/conformance/observations/rtdb-modular/rtdb-modular-onchildadded-*.json`):
 *
 *   - On subscribe, replays every existing direct child of `ref`'s path
 *     (one fire per existing key, in default priority/key order).
 *   - After subscribe, fires exactly once per new direct child write.
 *
 * Also accepts a {@link Query} (a `query(ref, ...)` with `orderBy*` /
 * `limitTo*` constraints): child events are then computed against the
 * ordered, windowed result — a child ENTERING the window fires
 * `child_added`; on subscribe the current window is replayed in window
 * order.
 *
 * Returns an unsubscribe; calling it twice is a no-op.
 */
export function onChildAdded(
  r: DatabaseReference | Query,
  cb: (snap: DataSnapshot, previousChildName: string | null) => void,
  cancelCallbackOrOptions?: ((error: Error) => void) | ListenOptions,
  options?: ListenOptions,
): Unsubscribe {
  return subscribeChild(r, 'child_added', cb, cancelCallbackOrOptions, options);
}

/**
 * `onChildChanged(ref, cb)` — subscribe to child-changed events.
 *
 * Semantics (oracle: `rtdb-modular-onchildchanged-fires-on-update`):
 *
 *   - No initial replay.
 *   - Fires when an existing direct child's value transitions to a
 *     NEW non-null value. Snapshot carries the NEW value.
 *   - Does NOT fire for added or removed children.
 *
 * Also accepts a {@link Query}: fires when a child that is IN the query
 * window changes value (an in-window update).
 */
export function onChildChanged(
  r: DatabaseReference | Query,
  cb: (snap: DataSnapshot, previousChildName: string | null) => void,
  cancelCallbackOrOptions?: ((error: Error) => void) | ListenOptions,
  options?: ListenOptions,
): Unsubscribe {
  return subscribeChild(r, 'child_changed', cb, cancelCallbackOrOptions, options);
}

/**
 * `onChildRemoved(ref, cb)` — subscribe to child-removed events.
 *
 * Semantics (oracle: `rtdb-modular-onchildremoved-fires-on-delete`):
 *
 *   - No initial replay.
 *   - Fires when a direct child is deleted (via `remove(child)` or
 *     `set(child, null)`).
 *   - Snapshot carries the PRIOR (now-removed) value — the listener
 *     sees what was there before deletion.
 *
 * Also accepts a {@link Query}: a child LEAVING the query window (e.g.
 * displaced past a `limitTo*` boundary or filtered out) fires
 * `child_removed` carrying its prior value.
 */
export function onChildRemoved(
  r: DatabaseReference | Query,
  cb: (snap: DataSnapshot, previousChildName: string | null) => void,
  cancelCallbackOrOptions?: ((error: Error) => void) | ListenOptions,
  options?: ListenOptions,
): Unsubscribe {
  return subscribeChild(r, 'child_removed', cb, cancelCallbackOrOptions, options);
}

/**
 * `onChildMoved(ref, cb)` — subscribe to child-moved events.
 *
 * Semantics (oracle: `rtdb-modular-onchildmoved-with-orderby`):
 *
 *   - Explicit queries use their active `orderBy*` index.
 *   - Plain refs use Firebase's default priority index, so changing a
 *     child's priority can move it while an ordinary value-only write does not.
 *
 * Accepts a {@link Query} and fires when the active ordered value changes,
 * including the Firebase `previousChildName` second callback argument.
 */
export function onChildMoved(
  r: DatabaseReference | Query,
  cb: (snap: DataSnapshot, previousChildName: string | null) => void,
  cancelCallbackOrOptions?: ((error: Error) => void) | ListenOptions,
  options?: ListenOptions,
): Unsubscribe {
  return subscribeChild(r, 'child_moved', cb, cancelCallbackOrOptions, options);
}

type ChildEvent = 'child_added' | 'child_changed' | 'child_removed' | 'child_moved';

function subscribeChild(
  r: DatabaseReference | Query,
  event: ChildEvent,
  cb: (snap: DataSnapshot, previousChildName: string | null) => void,
  cancelCallbackOrOptions?: ((error: Error) => void) | ListenOptions,
  options?: ListenOptions,
): Unsubscribe {
  const registryCallback = cb;
  const requestedOptions = typeof cancelCallbackOrOptions === 'function' ? options : cancelCallbackOrOptions;
  const method = { child_added: 'onChildAdded', child_changed: 'onChildChanged', child_removed: 'onChildRemoved', child_moved: 'onChildMoved' }[event];
  const activity = beginDatabaseActivity(r, method, 'subscription', attributionOf(requestedOptions));
  const lifecycle = requestedOptions?.onlyOnce ? { ...activity, close: () => queueMicrotask(() => activity.close()) } : activity;
  cb = (snap, previous) => { activity.delivered(snap); registryCallback(snap, previous); };
  const attach = (next: typeof cb, cancel: ((error: Error) => void) | undefined): Unsubscribe => {
    try {
      return sdkActivity.registering(activity, () => onChildEvent(r, event, next, cancel ? (error) => { activity.fail(); cancel(error); } : undefined, registryCallback, lifecycle));
    } catch (error) { activity.fail(); throw error; }
  };
  const cancelCallback = typeof cancelCallbackOrOptions === 'function'
    ? cancelCallbackOrOptions
    : undefined;
  const listenOptions = typeof cancelCallbackOrOptions === 'function'
    ? options
    : cancelCallbackOrOptions;
  if (!listenOptions?.onlyOnce) return attach(cb, cancelCallback);

  if (event === 'child_added') {
    let attaching = true;
    const initial: Array<[DataSnapshot, string | null]> = [];
    let stopped = false;
    let unsubscribe: Unsubscribe = () => {};
    const wrapped = (snap: DataSnapshot, previousChildName: string | null): void => {
      if (stopped) return;
      if (attaching) {
        initial.push([snap, previousChildName]);
        return;
      }
      stopped = true;
      unsubscribe();
      cb(snap, previousChildName);
    };
    unsubscribe = attach(wrapped, cancelCallback);
    attaching = false;
    if (initial.length > 0) {
      stopped = true;
      unsubscribe();
      // Firebase queues an existing child_added batch before its only-once
      // detach takes effect and delivers that batch in reverse key order.
      for (const [snap, previousChildName] of initial.reverse()) {
        try {
          cb(snap, previousChildName);
        } catch {
          // Listener exceptions are isolated; one child in the captured
          // initial batch must not abort the remaining deliveries.
        }
      }
    }
    return unsubscribe;
  }

  let unsubscribe: Unsubscribe | null = null;
  let fired = false;
  const once = (snap: DataSnapshot, previousChildName: string | null): void => {
    if (fired) return;
    fired = true;
    unsubscribe?.();
    cb(snap, event === 'child_removed' ? null : previousChildName);
  };
  unsubscribe = attach(once, cancelCallback);
  // Initial child_added delivery is synchronous, before `unsubscribe` is
  // assigned. Remove the registration after attachment in that case.
  if (fired) unsubscribe();
  return unsubscribe;
}

const listenerRegistry = new ListenerRegistry();

function cancelSubscriptions(
  target: Target,
  path: string,
  event?: 'value' | ChildEvent,
  scope?: string,
): void {
  for (const registration of listenerRegistry.takeMatching(target, path, event, scope)) {
    registration.unsubscribe();
  }
}

/**
 * Internal shared implementation for the four `onChild*` variants.
 *
 * Accepts a plain {@link DatabaseReference} OR a {@link Query}
 * (a `query(ref, ...)` with `orderBy*` / `limitTo*`). For a query, the
 * child-event diff is computed against the ordered, windowed result rather
 * than the raw child
 * key-set — a child entering/leaving the window fires `child_added` /
 * `child_removed`, an in-window value change fires `child_changed`. (Note
 * `child_moved` fires when the query's active ordered value changes.)
 */
function onChildEvent(
  r: DatabaseReference | Query,
  event: ChildEvent,
  cb: (snap: DataSnapshot, previousChildName: string | null) => void,
  cancelCallback: ((error: Error) => void) | undefined,
  registryCallback: typeof cb,
  activity: SdkActivityHandle,
): Unsubscribe {
  // Unwrap a Query into its base ref + spec; a plain ref has no spec.
  const isQ = isQuery(r as object);
  const baseRef = isQ ? (r as Query).ref : (r as DatabaseReference);
  const spec = isQ ? (r as Query)._spec : undefined;
  const target = targetOf(baseRef as unknown as object);
  const scope = isQuery(r as object) ? queryScope(r) : undefined;
  const wrapper = (raw: {
    key: string;
    val: JsonValue;
    previousChildName: string | null;
  }): void => {
    // Synthesize a snapshot rooted at the child path so `snap.key`
    // and `snap.val()` match the upstream `onChildAdded` snapshot
    // shape (key = the child's key, val = the child's value).
    const childRef = child(baseRef, raw.key);
    const snap = buildSandboxSnapFromRaw(target, childRef, raw.val);
    try {
      cb(snap, event === 'child_removed' ? null : raw.previousChildName);
    } catch {
      // Listener throws are swallowed — match `firebase/database`'s
      // behavior where one observer's exception doesn't block others.
    }
  };
  let registration: ListenerRegistration | undefined;
  const unregister = (): void => {
    activity.close();
    if (registration) {
      listenerRegistry.removeExact(target, baseRef._path, event, registryCallback, registration, scope);
    }
  };
  const unsub = subscribeWithLiveAuth(
    target,
    (auth, onCanceled) => target.backend.onChild(
      auth,
      event,
      baseRef._path,
      wrapper,
      spec,
      cancelCallback,
      () => { activity.fail(); onCanceled(); },
    ),
    unregister,
  );
  registration = { unsubscribe: unsub };
  listenerRegistry.add(target, baseRef._path, event, registryCallback, registration, scope);
  return unsub;
}

/**
 * `off(ref, eventType?, callback?)` — unsubscribe variant.
 *
 * Semantics (locked by oracle observation
 * `packages/conformance/observations/rtdb-modular/rtdb-modular-off-stops-child-fires.json`):
 *
 *   - `off(ref)` (no eventType) removes ALL listeners at that ref —
 *     value + every child event variety.
 *   - `off(ref, 'value')` removes only `value` listeners.
 *   - `off(ref, 'child_added')` (or any child event type) removes only
 *     that variety.
 *   - `off(ref, eventType, cb)` removes only the matching callback.
 *
 * The returned-unsubscribe pattern from `onValue` / `onChild*` is
 * functionally equivalent to `off(ref, eventType, cb)` for a specific
 * registration — both are supported.
 */
export function off(
  r: DatabaseReference | Query,
  eventType?: 'value' | ChildEvent,
  callback?: (snap: DataSnapshot) => void,
): void {
  const baseRef = isQuery(r as object) ? (r as Query).ref : r as DatabaseReference;
  const scope = isQuery(r as object) && !isDefaultQuerySpec(r._spec) ? queryScope(r) : undefined;
  const target = targetOf(baseRef as unknown as object);
  if (callback !== undefined && eventType !== undefined) {
    listenerRegistry.takeFirst(target, baseRef._path, eventType, callback, scope)?.unsubscribe();
    return;
  }
  cancelSubscriptions(target, baseRef._path, eventType, scope);
}
