import { runSdkWrite } from '../sandbox/internal/sdk-write-activity.js';
import { generatePushId } from './sandbox/push-id.js';
import { joinPath, pathSegments, type JsonValue } from './sandbox/data-tree.js';
import { authFor, targetOf } from './routing.js';
import { isQuery } from './query-shape.js';
import { finishSdkRead } from '../sandbox/internal/sdk-activity.js';
import { beginDatabaseActivity } from './sdk-activity.js';
import type { DataSnapshot, DatabaseReference, Query, ThenableReference } from './types.js';
import { buildSandboxRef } from './references.js';
import { buildSandboxQuerySnap, buildSandboxSnap } from './snapshots.js';

// ─── Reads ───────────────────────────────────────────────────────────

/**
 * `get(ref)` — one-shot read at the ref's path. Resolves to a
 * `DataSnapshot`-shaped object.
 *
 * Runs through the sandbox rule engine; denial throws the plain-`Error`
 * shape locked by the oracle.
 *
 * Absent path → `snap.val() === null && snap.exists() === false`.
 * Matches the SDK's `DataSnapshot.val()` contract.
 */
export function get(r: DatabaseReference | Query): Promise<DataSnapshot> {
  const query = isQuery(r as object) ? r as Query : undefined;
  const ref0 = query?.ref ?? r as DatabaseReference;
  const target = targetOf(ref0 as object);
  const activity = beginDatabaseActivity(r, 'get', 'operation');
  // Keep the existing single Promise reaction and exact backend error object.
  return Promise.resolve().then(() => {
    try {
      if (query) {
        const rows = target.admin
          ? target.backend.adminGetQuery(query.ref._path, query._spec)
          : target.backend.getQuery(authFor(target), query.ref._path, query._spec);
        return finishSdkRead(activity, buildSandboxQuerySnap(target, query.ref, rows));
      }
      const val = target.admin
        ? target.backend.adminGet(ref0._path)
        : target.backend.get(authFor(target), ref0._path);
      return finishSdkRead(activity, buildSandboxSnap(target, ref0, val));
    } catch (error) {
      activity.fail();
      throw error;
    }
  });
}

/**
 * `set(ref, value)` — replace the value at `ref`'s path. `null`
 * deletes (matches the RTDB invariant — locked by oracle observation
 * `rtdb-remove-vs-set-null.json`).
 *
 * `serverTimestamp()` sentinels are resolved at write time.
 */
export async function set(r: DatabaseReference, value: unknown): Promise<void> {
  const target = targetOf(r as unknown as object);
  return runSdkWrite(beginDatabaseActivity(r, 'set', 'operation'), () => {
    if (target.admin) {
      target.backend.adminSet(r._path, value as JsonValue);
    } else {
      target.backend.set(authFor(target), r._path, value as JsonValue);
    }
  });
}

export async function setPriority(
  r: DatabaseReference,
  priority: string | number | null,
): Promise<void> {
  const target = targetOf(r as unknown as object);
  return runSdkWrite(beginDatabaseActivity(r, 'setPriority', 'operation'), () => {
    if (target.admin) {
      target.backend.adminSetPriority(r._path, priority);
    } else {
      target.backend.setPriority(authFor(target), r._path, priority);
    }
  });
}

export async function setWithPriority(
  r: DatabaseReference,
  value: unknown,
  priority: string | number | null,
): Promise<void> {
  const target = targetOf(r as unknown as object);
  return runSdkWrite(beginDatabaseActivity(r, 'setWithPriority', 'operation'), () => {
    if (target.admin) {
      target.backend.adminSetWithPriority(r._path, value as JsonValue, priority);
    } else {
      target.backend.setWithPriority(authFor(target), r._path, value as JsonValue, priority);
    }
  });
}

/**
 * `update(ref, values)` — partial update.
 *
 *   - When `values` keys contain `/`, the call is a **multi-path atomic
 *     update**: every listed path is written as one transaction (any
 *     denial fails the whole batch).
 *   - Otherwise it's a **shallow merge** at the ref's path: each
 *     top-level key replaces the corresponding child. `null` values
 *     delete.
 *
 * Both behaviors are sandbox-implemented per the RtdbBackend's
 * `update` method (`rtdb-modular`-spec atomic claim, matrix row #23).
 */
export function update(
  r: DatabaseReference,
  values: Record<string, unknown>,
): Promise<void> {
  const target = targetOf(r as unknown as object);
  validateUpdatePaths(values);
  return runSdkWrite(beginDatabaseActivity(r, 'update', 'operation'), () => {
    return Promise.resolve().then(() => {
      if (target.admin) {
        target.backend.adminUpdate(r._path, values as Record<string, JsonValue>);
      } else {
        target.backend.update(
          authFor(target),
          r._path,
          values as Record<string, JsonValue>,
        );
      }
    });
  });
}

function validateUpdatePaths(values: Record<string, unknown>): void {
  const paths = Object.keys(values).map((path) => `/${pathSegments(path).join('/')}`);
  for (let leftIndex = 0; leftIndex < paths.length; leftIndex++) {
    for (let rightIndex = leftIndex + 1; rightIndex < paths.length; rightIndex++) {
      const left = paths[leftIndex]!;
      const right = paths[rightIndex]!;
      const [ancestor, descendant] = left.length <= right.length
        ? [left, right]
        : [right, left];
      if (ancestor === descendant || descendant.startsWith(`${ancestor}/`)) {
        throw new Error(
          `update failed: values argument contains a path ${ancestor} that is ancestor of another path ${descendant}`,
        );
      }
    }
  }
}

/**
 * `remove(ref)` — delete the subtree at the ref's path.
 *
 * RTDB invariant (oracle: `rtdb-remove-vs-set-null.json`): equivalent
 * to `set(ref, null)`. The sandbox backend dispatches `remove` through
 * the same code path as `set(_, null)`.
 */
export async function remove(r: DatabaseReference): Promise<void> {
  const target = targetOf(r as unknown as object);
  return runSdkWrite(beginDatabaseActivity(r, 'remove', 'operation'), () => {
    if (target.admin) {
      target.backend.adminRemove(r._path);
    } else {
      target.backend.remove(authFor(target), r._path);
    }
  });
}

/**
 * `push(ref, value?)` — mint an auto-id child key under `ref`'s path,
 * optionally writing `value` at the new child.
 *
 * Returns a ref at the new child path. The ref's `key` is the minted
 * id (locked by oracle observation `rtdb-push-autoid-format.json`:
 * 20 chars, leading `-`, lex-sortable).
 *
 * Production note: the key is minted **client-side** (no server
 * round-trip required); it's available synchronously on the returned
 * ref even when the optional write is denied by rules. The oracle
 * observation confirms this — the sandbox matches.
 */
export function push(r: DatabaseReference, value?: unknown): ThenableReference {
  const target = targetOf(r as unknown as object);
  // Mint the key SYNCHRONOUSLY (client-side, no rule check) so the
  // returned ref + `.key` are available even if the optional write is
  // later denied (DB-B7). The write is deferred onto the thenable's
  // promise — a rules denial REJECTS the promise rather than throwing
  // here and discarding the key.
  const key = target.backend.mintKey();
  const childPath = joinPath([...pathSegments(r._path), key]);
  // Two refs (mirroring upstream): `thenablePushRef` gets then/catch and
  // is returned; `pushRef` is a SEPARATE plain ref used as the promise's
  // fulfilled value — so resolving the promise doesn't re-enter the
  // thenable's own `then` (the self-reference unwrap trap).
  const thenablePushRef = buildSandboxRef(target, childPath);
  const pushRef = buildSandboxRef(target, childPath);
  let promise: Promise<DatabaseReference>;
  if (value === undefined) {
    promise = Promise.resolve(pushRef);
  } else {
    promise = runSdkWrite(beginDatabaseActivity(pushRef, 'push', 'operation'), () => {
      if (target.admin) target.backend.adminSet(childPath, value as JsonValue);
      else target.backend.set(authFor(target), childPath, value as JsonValue);
      return pushRef;
    });
  }
  return makeThenable(thenablePushRef, promise);
}

/**
 * Attach `then`/`catch` to a ref so it satisfies {@link ThenableReference}.
 * Mirrors upstream's `thenablePushRef.then = promise.then.bind(promise)`
 * (`api/Reference_impl.ts:627-629`). The ref's own fields are untouched —
 * it stays a usable {@link DatabaseReference}.
 */
function makeThenable(
  pushRef: DatabaseReference,
  promise: Promise<DatabaseReference>,
): ThenableReference {
  const thenable = pushRef as ThenableReference;
  thenable.then = promise.then.bind(promise) as ThenableReference['then'];
  thenable.catch = promise.catch.bind(promise) as ThenableReference['catch'];
  return thenable;
}

/**
 * Pre-mint a push key without writing. Used by callers that need the
 * key for a multi-path update (`update(rootRef, { [\`/users/${key}\`]: ... })`).
 * Returns a freshly-minted key.
 */
export function pushKey(): string {
  return generatePushId();
}
