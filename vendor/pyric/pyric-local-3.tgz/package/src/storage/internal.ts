/**
 * `pyric/storage/internal` — host-only admin plane for the sandbox
 * storage backend.
 *
 * The public `pyric/storage` surface is deliberately rules-honest:
 * every operation on a handle from `getStorageSandbox` evaluates the
 * configured storage rules against the handle's context identity.
 * Hosts that must serve firebase-admin semantics (the SharedWorker
 * host resolving `actAs: { mode: 'admin' }` storage ops for
 * `pyric-admin`'s remote dispatch arm, Pyric Studio's admin lens)
 * need a rules-BYPASS handle onto the SAME per-sandbox store.
 *
 * This subpath exists so that bypass never leaks onto the public
 * modular surface — mirroring how `pyric/sandbox/internal` carries
 * the sandbox's host-only seams.
 */

export {
  bindStorageOperationContext,
  getAdminStorageSandbox,
  getStorageService,
  storageAuth,
  storageOperationProvenance,
  targetOf,
  installStorageBackend,
  getStorageCrossServiceIam,
  getStorageRulesResolution,
  replaceCrossServiceIam,
  replaceStorageRules,
} from './service.js';
export { enforceRules, storageFirestoreLookup } from './enforce.js';
export { requestResourceFor, resourceFromStored } from './sandbox/rules-resources.js';
export { patchObjectMetadata, toFullMetadata, type AdminMetadataPatch } from './metadata.js';
export {
  decodeString,
  defaultRawContentType,
} from './upload.js';
export { arrayBufferToBase64, base64ToBytes } from './base64.js';
export { isStorageUrl, parseStorageUrl, refPathOf, type StorageLocation } from './url.js';
export type { StorageRulesResolution } from './rules-resolution.js';
export {
  snapshotStorageState, restoreStorageState, resetStorageState, referenceStorageState, restoreStorageReferences,
  type StorageStateRecord, type StorageReferenceRecord,
} from './sandbox/persistence-state.js';
export type { StorageBackend, StoredMetadata } from './persistence.js';
export { fetchFromByteRoute, uploadOverByteRoute, type RemoteByteRoute, type RemoteReadRequest, type RemoteUploadRequest } from './remote-bytes.js';

export { observeStorageOperation, storageTaskProgress, storageTaskResult } from '../sandbox/internal/storage-activity.js';
