/**
 * Download + delete operations: `getBytes`, `getBlob`,
 * `getDownloadURL`, `deleteObject`.
 *
 * Rules are evaluated via `enforceRules`; denials surface as a
 * `StorageError` with `.code === 'storage/unauthorized'`. The other
 * failure modes — all `StorageError`-shaped now (ST-B1) — are:
 *
 *   - `storage/object-not-found` when no entry exists at the
 *     reference's `fullPath`.
 *   - `storage/invalid-root-operation` when `fullPath` is empty —
 *     matches Firebase's pre-flight on root refs.
 *   - When `maxDownloadSizeBytes` is set, returns at most that many
 *     bytes (truncates). Matches upstream `getBytesInternal` /
 *     `getBlobInternal`, which slice after fetch because GCS may ignore
 *     Range on small objects — see COMPAT row 55.
 */
import { emitSandboxEvent, getClock, makeServiceMutationEvent } from 'pyric/sandbox/internal';
import type { EventProvenance } from 'pyric/sandbox';
import { getStorageService, storageAuth, storageOperationProvenance, targetOf } from './service.js';
import { enforceRules } from './enforce.js';
import { resourceFromStored } from './sandbox/rules-resources.js';
import { objectNotFound, invalidRootOperation } from './errors.js';
import { arrayBufferToBase64 } from './base64.js';
import type { StorageReference } from './reference.js';

/**
 * Read the blob at `ref` and return its contents as an
 * `ArrayBuffer`. Honors the optional `maxDownloadSizeBytes` cap by
 * truncating to that length.
 */
export async function getBytes(
  ref: StorageReference,
  maxDownloadSizeBytes?: number,
): Promise<ArrayBuffer> {
  guardNonRoot(ref, 'getBytes');
  const blob = await fetchBlob(ref, maxDownloadSizeBytes);
  return blob.arrayBuffer();
}

/**
 * Read the blob at `ref` and return it as a `Blob`. Same semantics
 * as `getBytes` but skips the `arrayBuffer()` conversion when the
 * caller wants a `Blob` directly (e.g. for streaming or
 * `URL.createObjectURL`). Note: this is the browser-side
 * counterpart of the JS SDK's `getBlob` — the v1 scope doesn't ship
 * a Node-stream variant.
 */
export async function getBlob(
  ref: StorageReference,
  maxDownloadSizeBytes?: number,
): Promise<Blob> {
  guardNonRoot(ref, 'getBlob');
  return fetchBlob(ref, maxDownloadSizeBytes);
}

/**
 * Return a URL that reads the sandbox object, built from the same
 * rules-checked blob as {@link getBlob}.
 *
 * The URL is a `data:<contentType>;base64,<payload>` URI: the object's bytes
 * are carried inside the string itself. That makes it resolvable wherever the
 * string travels (Node.js, an SSR render, a worker, a page) rather than only
 * inside the realm that produced it. Production returns a token-signed HTTPS
 * URL served by Google Cloud Storage instead; a consumer can rely on `fetch`
 * of either form yielding the object's bytes and its content type.
 *
 * Objects stored without a content type read back as
 * `application/octet-stream`.
 */
export async function getDownloadURL(ref: StorageReference): Promise<string> {
  guardNonRoot(ref, 'getDownloadURL');
  const blob = await fetchBlob(ref, undefined);
  const contentType = blob.type || 'application/octet-stream';
  const base64 = arrayBufferToBase64(await blob.arrayBuffer());
  return `data:${contentType};base64,${base64}`;
}

/**
 * Delete the object at `ref` — removes both the blob and the
 * metadata atomically. No-op when the path doesn't exist (the
 * persistence layer's `delete` is no-op on missing keys).
 *
 * NOTE: the JS SDK's `deleteObject` throws
 * `storage/object-not-found` when the path is missing. The v1 scope
 * keeps the persistence-layer no-op behavior for now; Slice 8 will
 * reconsider whether to mirror the strict throw.
 *
 * `provenance` (host-only): op {@link EventProvenance} bound at ISSUE time,
 * threaded EXPLICITLY onto the emitted `object_delete` event. The delete
 * awaits the backend before emitting, so it escapes the sandbox's
 * synchronous ambient-provenance window — see the note on `uploadBytes`.
 */
export async function deleteObject(
  ref: StorageReference,
  provenance?: EventProvenance,
): Promise<void> {
  guardNonRoot(ref, 'deleteObject');
  const target = targetOf(ref.storage);
  const operationProvenance = storageOperationProvenance(target, provenance);
  const service = await getStorageService(ref.storage);
  const existing = await service.backend.getMetadata(ref.fullPath);
  enforceRules(service, {
    request: {
      auth: storageAuth(target),
      method: 'delete',
      path: ref.fullPath,
    },
    resource: resourceFromStored(existing),
  }, target, operationProvenance);
  await service.backend.delete(ref.fullPath);
  try {
    emitSandboxEvent(
      target.sandbox,
      makeServiceMutationEvent({
        at: getClock(target.sandbox).now(),
        service: 'storage',
        op: 'object_delete',
        path: ref.fullPath,
        auth: storageAuth(target),
        before: existing ?? undefined,
        detail: { bucket: ref.bucket },
      }),
      operationProvenance,
    );
  } catch {
    // Observational — never let event emission break a storage delete.
  }
}

// ─── Helpers ───────────────────────────────────────────────────────

async function fetchBlob(
  ref: StorageReference,
  maxDownloadSizeBytes: number | undefined,
): Promise<Blob> {
  const target = targetOf(ref.storage);
  const operationProvenance = storageOperationProvenance(target);
  const service = await getStorageService(ref.storage);
  // Rule check uses the existing object's metadata (when present)
  // as `resource`. `unauthorized` supersedes `not-found`: the rule
  // check runs FIRST, so an unauthorized read of a missing path
  // reports `unauthorized`, not `not-found`. This matches prod — the
  // server won't disclose object existence to a caller that lacks
  // read permission.
  const existing = await service.backend.getMetadata(ref.fullPath);
  enforceRules(service, {
    request: {
      auth: storageAuth(target),
      method: 'get',
      path: ref.fullPath,
    },
    resource: resourceFromStored(existing),
  }, target, operationProvenance);
  const blob = await service.backend.getBlob(ref.fullPath);
  if (!blob) {
    throw objectNotFound(ref.fullPath);
  }
  // Upstream slices after download: GCS may not honor Range for small
  // files (`packages/storage/src/reference.ts` getBytesInternal /
  // getBlobInternal). Match that truncate-not-throw contract.
  if (
    typeof maxDownloadSizeBytes === 'number' &&
    blob.size > maxDownloadSizeBytes
  ) {
    return blob.slice(0, maxDownloadSizeBytes);
  }
  return blob;
}

function guardNonRoot(ref: StorageReference, op: string): void {
  if (ref.fullPath === '') {
    throw invalidRootOperation(op);
  }
}
