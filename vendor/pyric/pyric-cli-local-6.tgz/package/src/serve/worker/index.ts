/**
 * Browser-safe SharedWorker and hosted CLIENT surface (Studio/Playground data plane).
 *
 * This barrel exports ONLY the leaf client + the wire-protocol types — the
 * pieces a browser app (the served page, or Pyric Studio's Vite app) imports to
 * connect by SharedWorker MessagePort or hosted WebSocket. It deliberately
 * does NOT re-export `host.ts`/`entry.ts`:
 *   - `host.ts` imports the full `pyric/firestore` + `pyric/auth` engine (it IS
 *     the backend) — node/engine-heavy, never wanted in a page bundle.
 *   - `entry.ts` references `SharedWorkerGlobalScope` and is esbuild-only.
 *
 * `client.ts` imports only the value codec
 * (`pyric/firestore/internal/value-codec`, a leaf internal seam)
 * and type-only `pyric/sandbox` (erased at build), so this entry stays free of
 * the ~10 MB rules/sandbox engine — safe to import from any browser app.
 *
 * Exposed by `@pyric/cli`'s `./serve/worker` package export so Studio can
 * `import { getFirestore, subscribeEvents, setLens } from
 * '@pyric/cli/serve/worker'` and reach the SharedWorker backend.
 * `readHostedTarget` reads the host declaration; `getHostedFirestore` opens its
 * WebSocket client. Both are supported adapter exports used by Studio/Playground.
 */

export {
  PYRIC_WORKER_NAME,
  PYRIC_WORKER_URL,
  readPyricRuntimeManifest,
  type PyricRuntimeManifest,
} from '../runtime/manifest.js';
export {
  PYRIC_WORKER_GENERATION_KEY,
  preflightWorkerEpochStorage,
  rememberWorkerEpoch,
  workerNameForEpoch,
} from '../runtime/worker-generation.js';
export {
  createWorkerReplacement,
  type WorkerReplacement,
} from '../runtime/worker-replacement.js';
export {
  onWorkerRuntimeReload,
  retireWorkerRuntime,
} from './client/runtime-control.js';
export {
  disconnectClient,
  type DisconnectClientOptions,
} from './client/disconnect.js';
export { ownClientUntilPagehide } from './client/pagehide.js';

export {
  // Bridge-peer relay seams (leaf-safe: ids are re-minted in-page, frames go
  // over the worker port). The served page wires these into `connectBridge`'s
  // `dispatcher`/`workerRelay` (entries/runtime.ts); Pyric Studio reuses the
  // SAME wiring (studio's clients/bridge-peer.ts) so a Studio-only session
  // still serves agent tool-calls + remote worker-ops.
  callTool,
  relayWorkerOp,
  relayWorkerSub,
  // Op provenance: Studio declares itself as the issuer of the ops THIS
  // client-module instance constructs (per-bundle state; the served app's
  // own bundle remains app-attributed by its service handles). Traffic uses the resulting source to
  // filter Studio-driven ops out of the app's stream.
  setOpIssuer,
  // Connect + handles
  getFirestore,
  getAuth,
  getWorkerVersion,
  getWorkerInstanceId,
  exportWorkerState,
  importWorkerState,
  saveWorkerCheckpoint,
  listWorkerCheckpoints,
  restoreWorkerCheckpoint,
  deleteWorkerCheckpoint,
  type WorkerCheckpoint,
  type ClientDb,
  type ClientAuth,
  type ClientUser,
  type ClientUserCredential,
  type DocRefHandle,
  type CollRefHandle,
  type QueryHandle,
  type AnyHandle,
  type Unsubscribe,
  type ClientDocSnapshot,
  type ClientQuerySnapshot,
  // Path + query factories
  doc,
  collection,
  collectionGroup,
  query,
  where,
  and,
  or,
  orderBy,
  limit,
  limitToLast,
  startAt,
  startAfter,
  endAt,
  endBefore,
  // Sentinels
  serverTimestamp,
  increment,
  arrayUnion,
  arrayRemove,
  deleteField,
  // Firestore execution
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  addDoc,
  getCountFromServer,
  getAggregateFromServer,
  count,
  sum,
  average,
  listRootCollections,
  listSubcollections,
  onSnapshot,
  writeBatch,
  runTransaction,
  setRules,
  setFirestoreRules,
  setDatabaseRules,
  getActiveRules,
  getRulesStatus,
  adminGetDocument,
  adminListDocuments,
  adminSetDocument,
  adminDeleteDocument,
  adminReadState,
  type ClientWriteBatch,
  type ClientTransaction,
  // Auth
  createUserWithEmailAndPassword,
  // Admin user-DB ops (Pyric Studio data browse)
  listUsers,
  adminCreateUser,
  adminUpdateUser,
  adminDeleteUser,
  adminClearUsers,
  // Sign-in provider config (Pyric Studio S-AUTH)
  getProviderConfig,
  setProviderConfig,
  signInWithEmailAndPassword,
  signInAnonymously,
  signOut,
  acceptProviderCredential,
  onAuthStateChanged,
  onIdTokenChanged,
  getIdToken,
  getIdTokenResult,
  setPersistence,
  connectAuthEmulator,
  inMemoryPersistence,
  browserSessionPersistence,
  browserLocalPersistence,
  // Auth lens (Pyric Studio & Runtime Chip — admin / impersonation / app-session)
  setLens,
  getLens,
  subscribeLens,
  AUTH_LENS_STORAGE_KEY,
  hydrateLensFromStorage,
  // Storage (Pyric Studio data browse): worker-backed FirebaseStorage mirror
  getStorage,
  ref,
  listAll,
  getMetadata,
  getBlob,
  getDownloadURL,
  // Storage byte ops (worker-mode uploads/reads via the base64 protocol)
  uploadBytes,
  uploadString,
  uploadBytesResumable,
  getBytes,
  deleteObject,
  type ClientFirebaseStorage,
  type ClientStorageReference,
  type ClientSettableMetadata,
  type ClientUploadTask,
  type ClientUploadTaskSnapshot,
  // Event stream (Pyric Studio keystone — onEvent/history over the port)
  subscribeEvents,
  eventHistory,
  // Connected-page presence (#227)
  startPresence,
  subscribePresence,
  mintPresenceClientId,
  PRESENCE_HEARTBEAT_INTERVAL_MS,
  PRESENCE_STALE_MS,
  type PresenceSession,
  type PresenceSnapshot,
  type PresenceClientKind,
  type PresenceVisibility,
  // Sandbox snapshot export (Pyric Studio rules re-run: fork + test edited rules)
  getSnapshot,
  // Sandbox-owned full reset (issue #359): Firestore + every registered service
  resetAll,
} from './client.js';

// RTDB bridge families are exported directly from their owning modules. This
// public package index is the sole aggregation point for the worker surface.
export { rtdbGetDatabase, rtdbRef, rtdbChild } from './client/rtdb-references.js';
export { rtdbGet } from './client/rtdb-reads.js';
export {
  rtdbSet,
  rtdbSetPriority,
  rtdbSetWithPriority,
  rtdbUpdate,
  rtdbRemove,
  rtdbPush,
} from './client/rtdb-writes.js';
export {
  rtdbOnValue,
  rtdbOnChildAdded,
  rtdbOnChildChanged,
  rtdbOnChildMoved,
  rtdbOnChildRemoved,
  rtdbOff,
} from './client/rtdb-listeners.js';
export { rtdbRunTransaction } from './client/rtdb-transactions.js';
export {
  rtdbOnDisconnect,
  rtdbGoOffline,
  rtdbGoOnline,
  RtdbOnDisconnect,
} from './client/rtdb-connection-lifecycle.js';
export {
  rtdbServerTimestamp,
  rtdbConnectDatabaseEmulator,
} from './client/rtdb-controls.js';
export {
  adminReadRtdbState,
  adminSetRtdbValue,
  adminUpdateRtdbValue,
  adminDeleteRtdbValue,
  adminSubscribeRtdbValue,
} from './client/rtdb-admin.js';
export type {
  ClientRtdb,
  RtdbRefHandle,
  RtdbDataSnapshot,
} from './client/handles.js';

export type {
  AuthPersistenceMode,
  SerializedUser,
  SerializedUserCredential,
  SerializedIdTokenResult,
  ResolvedIdentity,
} from './protocol.js';

export { getHostedFirestore } from './client/websocket-connection.js';
export { readHostedTarget } from '../runtime/hosted-target.js';
export { takeAuthMail } from './client/auth-action-codes.js';
// A port an app opens to the worker itself, such as one it hands to a worker
// of its own, is wired and released with these, and carries the AI calls.
export { wirePort, disconnectPort } from './client/core.js';
export { aiGenerateContent, aiStreamGenerateContent, aiCountTokens } from './client/ai.js';
