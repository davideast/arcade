import { setAiEvidence } from 'pyric/ai/internal';
/**
 * Worker-client transport core — the shared singleton machinery every API
 * family (firestore, auth, rtdb, storage) rides on: port wiring, RPC
 * correlation, the pending/subscriber maps, the Pyric Studio auth-lens default,
 * and the op-source (issuer) stamp.
 *
 * This module owns the client's mutable module state. Because ES module
 * bindings are live, family modules import `_defaultLens` (and the maps) and
 * observe every `setLens(...)` update through the same singleton — exactly as
 * they did when all of this lived inline in `client.ts`.
 */
import type { InboundMessage, OutboundMessage } from '../protocol.js';
import type { RuntimeReloadMessage } from '../protocol.js';
// TYPE-ONLY — the auth-lens contract + the cross-service event envelope, shared
// with the worker host + the sandbox's event provenance. Erased at build, so the
// leaf client bundle stays engine-free.
import type { AuthLens, SandboxEvent } from 'pyric/sandbox';
import { FirebaseError } from 'pyric/app';
import { receiveClockState } from './clock.js';
import type { ClientPort } from './handles.js';
import { createOperationBudget } from '../../../bridge/operation-budget.js';
import { hasValidOutboundEnvelope, hasValidReplyOutcome, snapshotError } from '../outbound-validation.js';

// ─── Port + correlation machinery ─────────────────────────────────────────

let _opCounter = 0;
let _subCounter = 0;

export function nextId(): string { return `op-${++_opCounter}`; }
export function nextSubId(): string { return `sub-${++_subCounter}`; }

/**
 * Pending RPC resolvers. Keyed by correlation id.
 * Resolves with the `value` field on success; rejects with a typed error
 * on failure.
 */
export const _pending = new Map<string, {
  port: ClientPort;
  clientSessionId?: string;
  budget?: ReturnType<typeof createOperationBudget>;
  release?: () => void;
  resolve: (v: unknown) => void;
  reject: (e: Error & { code: string }) => void;
}>();

/**
 * Active snapshot subscribers. Keyed by subId.
 * `next` is the user-supplied callback; `error` is the optional error handler.
 */
export const _snapSubs = new Map<string, {
  port: ClientPort;
  next: (snap: unknown) => void;
  error?: (err: unknown) => void;
  /** Firestore listeners abort on app deletion; RTDB/Auth stop silently. */
  service?: 'firestore';
  message?: InboundMessage;
  close?: () => void;
}>();

/**
 * Active event-stream subscribers (Pyric Studio keystone). Keyed by subId.
 * `next` receives each delivered BATCH of `SandboxEvent`s — the first batch is
 * the initial `history()` snapshot, subsequent batches are single live events.
 */
export const _eventSubs = new Map<string, {
  port: ClientPort;
  next: (events: readonly SandboxEvent[]) => void;
  message: InboundMessage;
  error?: (error: Error & { code: string }) => void;
  /** Called when the subscription is sent again; the host replies with its whole history. */
  restored?: () => void;
}>();
const disconnectedPorts = new WeakSet<ClientPort>();
const runtimeReloadListeners = new Set<(message: RuntimeReloadMessage) => void>();

export function subscribeRuntimeReload(
  listener: (message: RuntimeReloadMessage) => void,
): () => void {
  runtimeReloadListeners.add(listener);
  return () => runtimeReloadListeners.delete(listener);
}

function appDeletedError(): Error & { code: string } {
  return Object.assign(new Error('Firebase App was deleted'), { code: 'app/app-deleted' });
}

export function isDisconnectedPort(port: ClientPort): boolean {
  return disconnectedPorts.has(port);
}

/** Atomically register and post a subscription unless its app port is closed. */
export function openSnapshotSubscription(
  port: ClientPort,
  subId: string,
  subscription: (typeof _snapSubs extends Map<string, infer T> ? T : never),
  message: InboundMessage,
): boolean {
  const isDeleted = disconnectedPorts.has(port);
  if (isDeleted) return false;
  _snapSubs.set(subId, { ...subscription, message });
  try {
    port.postMessage(message);
  } catch (error) {
    _snapSubs.delete(subId);
    throw error;
  }
  return true;
}

/** Atomically register an event-stream subscription unless its port is closed. */
export function openEventSubscription(
  port: ClientPort,
  subId: string,
  next: (events: readonly SandboxEvent[]) => void,
  message: InboundMessage,
  error?: (error: Error & { code: string }) => void,
  restored?: () => void,
): boolean {
  const isDeleted = disconnectedPorts.has(port);
  if (isDeleted) { error?.(appDeletedError()); return false; }
  _eventSubs.set(subId, { port, next, error, message, restored });
  port.postMessage(message);
  return true;
}

/** Move existing observers when getToken selects a different Service Worker scope. */
export function retargetMessagingSubscriptions(port: ClientPort, recipientId: string): void {
  for (const [subId, subscription] of _snapSubs) {
    const message = subscription.message;
    const ownsSubscription = subscription.port === port && message?.t === 'sub';
    if (!ownsSubscription) continue;
    const isMessaging = message.target === 'messaging.foreground' || message.target === 'messaging.background';
    if (!isMessaging) continue;
    port.postMessage({ t: 'unsub', subId });
    message.recipientId = recipientId;
    port.postMessage(message);
  }
}

/** Reattach Messaging observers without replaying sends or token mutations. */
export function restoreMessagingSubscriptions(port: ClientPort, postMessage: ClientPort['postMessage']): void {
  const visibility = port.messagingVisibility;
  if (visibility) postMessage({ ...visibility, id: nextId() });
  for (const [subId, subscription] of _snapSubs) {
    const message = subscription.message;
    const ownsSubscription = subscription.port === port && message?.t === 'sub';
    if (!ownsSubscription) continue;
    const isMessaging = message.target === 'messaging.foreground' || message.target === 'messaging.background';
    if (!isMessaging) continue;
    postMessage({ t: 'unsub', subId });
    postMessage(message);
  }
}

/** Re-establish live observations without replaying operations or AI requests. */
export function restoreObservationSubscriptions(
  port: ClientPort,
  postMessage: ClientPort['postMessage'] = message => port.postMessage(message),
): void {
  for (const [subId, subscription] of _snapSubs) {
    const message = subscription.message;
    const ownsSubscription = subscription.port === port && message?.t === 'sub';
    if (!ownsSubscription) continue;
    const isRtdbTarget = typeof message.target === 'object' && 'service' in message.target && message.target.service === 'rtdb';
    const observesDatabase = subscription.service === 'firestore' || isRtdbTarget;
    const observesPresence = message.target === 'presence';
    const restoresObservation = observesDatabase || observesPresence;
    if (restoresObservation) {
      postMessage({ t: 'unsub', subId });
      postMessage(message);
    }
  }
  for (const [subId, subscription] of _eventSubs) {
    const ownsSubscription = subscription.port === port;
    if (!ownsSubscription) continue;
    subscription.restored?.();
    postMessage({ t: 'unsub', subId });
    postMessage(subscription.message);
  }
}

/** A replacement host has no Auth observers, even when the app retains its handle. */
export function restoreAuthSubscriptions(port: ClientPort, postMessage: ClientPort['postMessage']): void {
  for (const subscription of _snapSubs.values()) {
    const message = subscription.message;
    const ownsSubscription = subscription.port === port && message?.t === 'sub';
    if (ownsSubscription) {
      const observesAuth = message.target === 'authState' || message.target === 'idToken';
      if (observesAuth) postMessage(message);
    }
  }
}

/** Remove a local subscription and notify only a live app port. */
export function closeSubscription(
  port: ClientPort,
  subId: string,
  clientSessionId?: string,
): void {
  _snapSubs.delete(subId);
  _eventSubs.delete(subId);
  const isDeleted = disconnectedPorts.has(port);
  if (isDeleted) return;
  const message: InboundMessage = { t: 'unsub', subId };
  const hasSessionId = clientSessionId !== undefined && clientSessionId !== '';
  if (hasSessionId) message.clientSessionId = clientSessionId;
  try {
    port.postMessage(message);
  } catch {
    // Local cancellation is complete even when the host cannot be notified.
  }
}

/** Settle outstanding calls without claiming that the owning app was deleted. */
export function rejectPendingRequests(port: ClientPort, error: Error & { code: string }): void {
  for (const [id, pending] of [..._pending]) {
    const isOwnedRequest = pending.port === port;
    if (isOwnedRequest) {
      takePendingRequest(id);
      pending.reject(error);
    }
  }
}

/** Drop every client-side correlation owned by a closing app port. */
export function disconnectPort(port: ClientPort): void {
  disconnectedPorts.add(port);
  rejectPendingRequests(port, appDeletedError());
  for (const [id, subscription] of [..._snapSubs]) {
    const isForeignSubscription = subscription.port !== port;
    if (isForeignSubscription) continue;
    _snapSubs.delete(id);
    const isFirestoreSubscription = subscription.service === 'firestore';
    if (isFirestoreSubscription) {
      subscription.error?.(new FirebaseError('aborted', 'The operation was aborted.'));
    }
    subscription.close?.();
  }
  for (const [id, subscription] of [..._eventSubs]) {
    const isForeignSubscription = subscription.port !== port;
    if (isForeignSubscription) continue;
    _eventSubs.delete(id);
    subscription.error?.(appDeletedError());
  }
  port.onmessage = null;
}

// ─── Denial relay (headless dev visibility) ────────────────────────────────
//
// An agent driving `pyric dev` in process never sees the browser console, so
// a rules denial is otherwise invisible to it. Relay every denial (an error
// carrying `denialContext`) to the dev server, which prints it to the
// terminal — regardless of whether the app itself catches/handles the
// error. Fire-and-forget: never throws, never awaited into app flow, and a
// relay failure (dev server down, no `fetch`, non-pyric host) is swallowed
// silently — this is a diagnostics side channel, not a correctness path.

/** Shape POSTed to the dev server's `/__pyric/denials` endpoint. */
interface DenialRelayPayload {
  kind: 'listener' | 'read';
  code: string;
  message: string;
  denialContext: unknown;
  /** Sibling of denialContext on the sandbox error (query-proof denials
   *  attach the suggested where() fix there); forwarded when present. */
  remediation?: string;
}

/** POST a denial to the dev server for terminal visibility. No-op when the
 *  error carries no `denialContext` (only rules denials are relayed) or when
 *  `fetch` isn't available (non-browser host). */
function relayDenial(
  kind: 'listener' | 'read',
  err: { message: string; code: string; denialContext?: unknown; remediation?: unknown },
): void {
  if (err.denialContext === undefined) return;
  if (typeof fetch !== 'function') return;
  const payload: DenialRelayPayload = {
    kind,
    code: err.code,
    message: err.message,
    denialContext: err.denialContext,
    ...(typeof err.remediation === 'string' ? { remediation: err.remediation } : {}),
  };
  try {
    void fetch('/__pyric/denials', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    }).catch(() => {});
  } catch {
    /* fire-and-forget — never let the relay disturb app flow */
  }
}

/** Wire up the port's onmessage handler (idempotent per-port). */
export function wirePort(port: ClientPort): void {
  port.onmessage = (ev: MessageEvent<OutboundMessage>) => {
    const msg = ev.data;
    const hasInvalidEnvelope = !hasValidOutboundEnvelope(msg);
    if (hasInvalidEnvelope) {
      const error = new FirebaseError('unavailable',
        'The sandbox sent a malformed reply envelope. The operation may have completed; check state before retrying.');
      rejectPendingRequests(port, error);
      for (const [id, subscription] of _snapSubs) {
        const ownsSubscription = subscription.port === port;
        if (ownsSubscription) { closeSubscription(port, id); subscription.error?.(error); }
      }
      for (const [id, subscription] of _eventSubs) {
        const ownsSubscription = subscription.port === port;
        if (ownsSubscription) { closeSubscription(port, id); subscription.error?.(error); }
      }
      return;
    }
    const isResponse = msg.t === 'res';
    const isSnapshot = msg.t === 'snap';
    const isEventBatch = msg.t === 'event';
    const isRuntimeReload = msg.t === 'runtime-reload';
    const isClock = msg.t === 'clock';
    if (isResponse) {
      const pending = _pending.get(msg.id);
      const isForeignRequest = pending === undefined || pending.port !== port;
      if (isForeignRequest) return;
      takePendingRequest(msg.id);
      const hasInvalidOutcome = !hasValidReplyOutcome(msg);
      if (hasInvalidOutcome) {
        pending.reject(new FirebaseError('unavailable', 'The sandbox sent a malformed operation reply. The operation may have completed; check state before retrying.'));
        return;
      }
      const succeeded = msg.ok;
      if (succeeded) {
        pending.resolve(msg.value);
      } else {
        const err = new Error(msg.error.message) as Error & {
          code: string;
          denialContext?: unknown;
          aiEnvelope?: unknown;
        };
        err.code = msg.error.code;
        // Structured denial context (spike gap 6): re-attach so consumers —
        // and the bridge relay, which re-serializes thrown errors — see the
        // same shape a local SandboxError carries.
        const hasDenialContext = msg.error.denialContext !== undefined;
        if (hasDenialContext) {
          err.denialContext = msg.error.denialContext;
        }
        // AI wire error envelope (pyric/ai): re-attach so the served
        // `firebase/ai` entry can mint the exact SDK AIError decoration the
        // in-process plane applies (see entries/ai.ts).
        const aiEvidence = msg.error.aiEvidence;
        const hasAiEvidence = aiEvidence !== undefined;
        if (hasAiEvidence) setAiEvidence(err, aiEvidence);
        const hasAiEnvelope = msg.error.aiEnvelope !== undefined;
        if (hasAiEnvelope) {
          err.aiEnvelope = msg.error.aiEnvelope;
        }
        relayDenial('read', err);
        pending.reject(err);
      }
    } else if (isSnapshot) {
      const sub = _snapSubs.get(msg.subId);
      const isForeignSubscription = sub === undefined || sub.port !== port;
      if (isForeignSubscription) return;
      const errPayload = snapshotError(msg);
      const hasError = errPayload !== undefined;
      if (hasError) {
        closeSubscription(port, msg.subId, sub.message?.clientSessionId);
        const err = new Error(errPayload.message) as Error & { code: string; denialContext?: unknown; aiEnvelope?: unknown };
        err.code = errPayload.code;
        const hasDenialContext = errPayload.denialContext !== undefined;
        if (hasDenialContext) err.denialContext = errPayload.denialContext;
        const aiEvidence = errPayload.aiEvidence;
        const hasAiEvidence = aiEvidence !== undefined;
        if (hasAiEvidence) setAiEvidence(err, aiEvidence);
        const hasAiEnvelope = errPayload.aiEnvelope !== undefined;
        if (hasAiEnvelope) err.aiEnvelope = errPayload.aiEnvelope;
        relayDenial('listener', err);
        // Surface an unobserved listener error instead of swallowing it — the
        // worker-path twin of the in-page default (a denied listener after a
        // rules change / sign-out must not fail silently on the page console).
        const handleError = sub.error;
        const hasErrorHandler = handleError !== undefined;
        if (hasErrorHandler) handleError.call(sub, err);
        else console.error('pyric/firestore: Uncaught Error in snapshot listener:', err);
        return;
      }
      sub.next(msg.value);
    } else if (isEventBatch) {
      // Event-stream batch (Pyric Studio keystone). Plain JSON SandboxEvents —
      // no rehydration. Deliver the whole batch to the registered subscriber.
      const subscription = _eventSubs.get(msg.subId);
      const ownsSubscription = subscription !== undefined && subscription.port === port;
      if (ownsSubscription) subscription.next(msg.events);
    } else if (isRuntimeReload) {
      for (const listener of runtimeReloadListeners) listener(msg);
    } else if (isClock) {
      receiveClockState(msg.state);
    }
  };
  // Ask for the clock mirror as the port is wired, so the values the page
  // mints synchronously (push ids, in-flight upload stamps) read the sandbox's
  // clock rather than the wall clock from the first op onward.
  port.postMessage({ t: 'clock-subscribe' } satisfies InboundMessage);
}

// ─── Auth lens (Pyric Studio) ──────────────────────────────────────────────
//
// The default per-op auth lens carried on every FIRESTORE DATA op this client
// sends. The host resolves a data handle from it (`lensDb` in host.ts):
//   - `{ mode: 'app-session' }` (the default): the served app's own session.
//   - `{ mode: 'as', uid }`: impersonate — rules evaluate as that user.
//   - `{ mode: 'admin' }`: admin lens (rule bypass; see host.ts gap note).
//
// Studio sets this so its data grids / rules-debug "re-run as user" views run
// under the chosen identity without threading `actAs` through every call. AUTH
// ops (`auth.*`) and `getVersion` are NEVER lensed — they operate the worker's
// session, not data — so the lens is stamped only on the data-op path.

export const AUTH_LENS_STORAGE_KEY = 'pyric:auth-lens';

type PersistedAuthLens =
  | Extract<AuthLens, { mode: 'admin' }>
  | Extract<AuthLens, { mode: 'as' }>
  | Extract<AuthLens, { mode: 'anon' }>;

export function isPersistedAuthLens(value: unknown): value is PersistedAuthLens {
  if (!value || typeof value !== 'object') return false;
  const candidate = value as { mode?: unknown; uid?: unknown };
  if (candidate.mode === 'admin' || candidate.mode === 'anon') return true;
  return candidate.mode === 'as' && typeof candidate.uid === 'string';
}

function normalizePersistedAuthLens(value: unknown): PersistedAuthLens | undefined {
  if (isPersistedAuthLens(value)) return value;
  return undefined;
}

/** Read persisted auth lens from sessionStorage safely. */
export function hydrateLensFromStorage(): AuthLens | undefined {
  if (typeof sessionStorage === 'undefined') return undefined;
  try {
    const raw = sessionStorage.getItem(AUTH_LENS_STORAGE_KEY);
    if (!raw) return undefined;
    const parsed: unknown = JSON.parse(raw);
    const persistedLens = normalizePersistedAuthLens(parsed);
    if (persistedLens) return persistedLens;
    sessionStorage.removeItem(AUTH_LENS_STORAGE_KEY);
    return undefined;
  } catch {
    try {
      sessionStorage.removeItem(AUTH_LENS_STORAGE_KEY);
    } catch {
      // Ignore storage restrictions
    }
    return undefined;
  }
}

/** Module-level default lens. `undefined` ⇒ the worker treats the op as the
 *  app's session (the additive default — existing senders omit `actAs`).
 *
 *  Exported as a LIVE binding: family modules read it to stamp the lens onto
 *  subscriptions (`onSnapshot`, `rtdbOnValue`), and see `setLens(...)` updates
 *  through this one singleton. */
export let _defaultLens: AuthLens | undefined = hydrateLensFromStorage();

const lensListeners = new Set<(lens: AuthLens | undefined) => void>();

/**
 * Register a listener for auth lens mutations.
 * Returns an unsubscribe function that removes the listener.
 */
export function subscribeLens(listener: (lens: AuthLens | undefined) => void): () => void {
  lensListeners.add(listener);
  return () => {
    lensListeners.delete(listener);
  };
}

/**
 * Set the default auth lens applied to subsequent Firestore DATA ops from this
 * client (Pyric Studio & Runtime Chip). Pass `{ mode: 'as', uid }` to read/write AS a user
 * (rules apply), `{ mode: 'admin' }` for the admin lens, or
 * `{ mode: 'app-session' }` / `undefined` to revert to the app's own session.
 *
 * The lens is process-wide for this client module (one served page = one
 * worker port), mirroring how Studio drives a single active identity at a time.
 * Auth ops are unaffected — they always operate the real session.
 *
 * Persists active admin and impersonation lenses to sessionStorage under
 * AUTH_LENS_STORAGE_KEY, and removes the key when cleared or reverted to the
 * app session.
 * Notifies all registered subscribeLens listeners.
 */
export function setLens(lens: AuthLens | undefined): void {
  _defaultLens = normalizePersistedAuthLens(lens);

  if (typeof sessionStorage !== 'undefined') {
    try {
      if (_defaultLens) {
        sessionStorage.setItem(AUTH_LENS_STORAGE_KEY, JSON.stringify(_defaultLens));
      } else {
        sessionStorage.removeItem(AUTH_LENS_STORAGE_KEY);
      }
    } catch {
      // Ignore quota or disabled storage restrictions
    }
  }

  for (const listener of [...lensListeners]) {
    try {
      listener(_defaultLens);
    } catch (err) {
      console.error('Error in subscribeLens listener:', err);
    }
  }
}

/** The active default lens (read-only view), for Studio UI to reflect state. */
export function getLens(): AuthLens | undefined {
  return _defaultLens;
}

/** Alias for {@link setLens} exposed on the public Web Auth surface. */
export const switchAuthLens = setLens;

/** Alias for {@link getLens} exposed on the public Web Auth surface. */
export const getAuthLens = getLens;

/** Alias for {@link subscribeLens} exposed on the public Web Auth surface. */
export const onAuthLensChanged = subscribeLens;

/**
 * Module-level op-source declaration (Pyric Studio traffic attribution).
 * When set, every op/sub message THIS CLIENT MODULE CONSTRUCTS is stamped
 * `source: 'studio'` on the wire; the host maps that onto the unified
 * event stream's `actor` field so Traffic can filter Studio's own
 * viewer/editor ops out of the app's stream.
 *
 * Studio's live plane sets this once at connect (`connectWorkerLive`);
 * the served APP page never calls it (its service handles remain the source
 * of app attribution), and RELAYED frames bypass Studio stamping entirely —
 * the bridge relay ({@link relayWorkerOp} / {@link relayWorkerSub}) clears the
 * Studio issuer and marks remote frames through {@link rawRpc} / a direct postMessage, so a
 * user's own admin-SDK traffic through the remote bridge is never
 * mislabeled as Studio's even though it rides the same port.
 */
let _opIssuer: 'studio' | undefined;

/** Declare who issues the ops this client module constructs. See {@link _opIssuer}. */
export function setOpIssuer(source: 'studio' | undefined): void {
  _opIssuer = source;
}

/** Stamp the declared op source onto a client-constructed message. Ops and
 *  subscriptions only — control frames (`tool`, `unsub`) never carry it
 *  (agent tool-calls dispatched through this port must not inherit
 *  Studio's source; their inner ops are attributed by the host). */
export function stampIssuer<T extends { t?: string }>(msg: T): T {
  return _opIssuer && (msg.t === 'op' || msg.t === 'sub')
    ? { ...msg, issuer: _opIssuer }
    : msg;
}

/**
 * Send an already-final message and return a promise for its result — no
 * implicit stamping. The RELAY path ({@link relayWorkerOp}) explicitly owns
 * the final remote provenance fields before sending through this function.
 */
export function rawRpc(
  port: ClientPort,
  msg: InboundMessage,
  postMessage: ClientPort['postMessage'] = message => port.postMessage(message),
): Promise<unknown> {
  const isDeleted = disconnectedPorts.has(port);
  if (isDeleted) return Promise.reject(appDeletedError());
  const isOperation = msg.t === 'op' || msg.t === 'tool';
  const budget = isOperation ? operationBudget(port, msg.clientSessionId) : undefined;
  const reservation = budget?.reserve(msg);
  const isRefused = reservation?.accepted === false;
  if (isRefused) return Promise.reject(new FirebaseError(reservation.error.code, reservation.error.message));
  return new Promise<unknown>((resolve, reject) => {
    const opMsg = msg as { id: string };
    _pending.set(opMsg.id, {
      port,
      clientSessionId: msg.clientSessionId,
      budget,
      release: reservation?.release,
      resolve,
      reject,
    });
    try {
      postMessage(msg);
    } catch (error) {
      takePendingRequest(opMsg.id);
      reject(error);
    }
  });
}

function operationBudget(port: ClientPort, clientSessionId: string | undefined): ReturnType<typeof createOperationBudget> {
  for (const request of _pending.values()) {
    const belongsToClient = request.port === port && request.clientSessionId === clientSessionId;
    const budget = request.budget;
    const hasClientBudget = belongsToClient && budget !== undefined;
    if (hasClientBudget) return budget;
  }
  return createOperationBudget();
}

/** Removing correlation releases its operation charge, including local cancellation. */
function takePendingRequest(id: string) {
  const request = _pending.get(id);
  _pending.delete(id);
  request?.release?.();
  return request;
}

/** Send a CLIENT-CONSTRUCTED message: stamps the declared op source, then sends. */
export function rpc(port: ClientPort, msg: InboundMessage): Promise<unknown> {
  return rawRpc(port, stampIssuer(msg));
}

/**
 * Send a client RPC with a bounded wait, while keeping correlation cleanup
 * inside the transport module that owns the pending-request registry.
 */
export function rpcWithTimeout(
  port: ClientPort,
  msg: InboundMessage,
  timeoutMs: number,
  timeoutMessage: string,
): Promise<unknown> {
  const id = (msg as { id: string }).id;
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      const isAlreadySettled = takePendingRequest(id) === undefined;
      if (isAlreadySettled) return;
      reject(new Error(timeoutMessage));
    }, timeoutMs);
  });
  return Promise.race([rpc(port, msg), timeout]).finally(() => {
    const hasTimer = timer !== undefined;
    if (hasTimer) clearTimeout(timer);
  });
}

/**
 * Like {@link rpc} but stamps the active default auth lens onto the op message
 * (Pyric Studio). Used by data-service ops so a `setLens(...)` choice
 * carries per op without every call site threading `actAs`. Auth ops + version
 * use the bare {@link rpc} so they never carry a lens.
 *
 * `actAs` is only attached when a lens is active — when none is set the wire
 * message is byte-identical to before, preserving the additive contract.
 */
export function dataRpc(port: ClientPort, msg: InboundMessage & { t: 'op' }): Promise<unknown> {
  if (disconnectedPorts.has(port) && !msg.method.startsWith('rtdb.')) {
    return Promise.reject(
      new FirebaseError('failed-precondition', 'The client has already been terminated.'),
    );
  }
  const withLens = _defaultLens ? { ...msg, actAs: _defaultLens } : msg;
  return rpc(port, withLens);
}
