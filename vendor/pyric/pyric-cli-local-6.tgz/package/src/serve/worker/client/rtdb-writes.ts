/**
 * RTDB writes, priorities, and push-ID generation over the worker port.
 *
 * `push()` hands its caller a reference before the write lands, so the key is
 * minted here rather than by the host. The first eight characters of a key
 * encode the instant it was minted at, and that instant is the sandbox's, read
 * from the clock mirror, so a key minted under a pinned clock sorts where the
 * pin says rather than where the wall clock does.
 */
import { runSdkWrite } from 'pyric/sandbox/internal';
import { beginWorkerDatabaseActivity } from './sdk-activity.js';
import { sandboxNow } from './clock.js';
import { dataRpc, nextId } from './core.js';
import type { RtdbRefHandle } from './handles.js';
import { makeRtdbRef } from './rtdb-references.js';

const RTDB_PUSH_CHARS = '-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz';
let lastRtdbPushTime = 0;
const lastRtdbRandChars: number[] = new Array(12).fill(0);

function generateRtdbPushId(now: number): string {
  const duplicateTime = now === lastRtdbPushTime;
  lastRtdbPushTime = now;
  const timestampChars: string[] = new Array(8);
  let timestamp = now;
  for (let i = 7; i >= 0; i--) {
    timestampChars[i] = RTDB_PUSH_CHARS.charAt(timestamp % 64);
    timestamp = Math.floor(timestamp / 64);
  }
  if (timestamp !== 0) throw new Error('RTDB push-id: timestamp overflow.');
  if (!duplicateTime) {
    for (let i = 0; i < 12; i++) lastRtdbRandChars[i] = Math.floor(Math.random() * 64);
  } else {
    let i: number;
    for (i = 11; i >= 0 && lastRtdbRandChars[i] === 63; i--) lastRtdbRandChars[i] = 0;
    if (i < 0) {
      for (let j = 0; j < 12; j++) lastRtdbRandChars[j] = Math.floor(Math.random() * 64);
    } else {
      lastRtdbRandChars[i] = (lastRtdbRandChars[i] ?? 0) + 1;
    }
  }
  return timestampChars.join('') + lastRtdbRandChars.map((n) => RTDB_PUSH_CHARS.charAt(n)).join('');
}

export async function rtdbSet(ref: RtdbRefHandle, value: unknown): Promise<void> {
  await runSdkWrite(beginWorkerDatabaseActivity(ref, 'set', 'operation'), async () => {
    await dataRpc(ref.port, { t: 'op', id: nextId(), method: 'rtdb.set', path: ref.path, value });
  });
}

export async function rtdbSetPriority(ref: RtdbRefHandle, priority: string | number | null): Promise<void> {
  await runSdkWrite(beginWorkerDatabaseActivity(ref, 'setPriority', 'operation'), async () => {
    await dataRpc(ref.port, { t: 'op', id: nextId(), method: 'rtdb.setPriority', path: ref.path, priority });
  });
}

export async function rtdbSetWithPriority(
  ref: RtdbRefHandle,
  value: unknown,
  priority: string | number | null,
): Promise<void> {
  await runSdkWrite(beginWorkerDatabaseActivity(ref, 'setWithPriority', 'operation'), async () => {
    await dataRpc(ref.port, {
      t: 'op', id: nextId(), method: 'rtdb.setWithPriority', path: ref.path, value, priority,
    });
  });
}

export async function rtdbUpdate(ref: RtdbRefHandle, values: Record<string, unknown>): Promise<void> {
  await runSdkWrite(beginWorkerDatabaseActivity(ref, 'update', 'operation'), async () => {
    await dataRpc(ref.port, { t: 'op', id: nextId(), method: 'rtdb.update', path: ref.path, values });
  });
}

export async function rtdbRemove(ref: RtdbRefHandle): Promise<void> {
  await runSdkWrite(beginWorkerDatabaseActivity(ref, 'remove', 'operation'), async () => {
    await dataRpc(ref.port, { t: 'op', id: nextId(), method: 'rtdb.remove', path: ref.path });
  });
}

export function rtdbPush(
  ref: RtdbRefHandle,
  value?: unknown,
): RtdbRefHandle & PromiseLike<RtdbRefHandle> {
  const key = generateRtdbPushId(sandboxNow());
  const pushed = makeRtdbRef(ref.port, `${ref.path}/${key}`);
  const settledRef = makeRtdbRef(ref.port, pushed.path);
  let promise: Promise<RtdbRefHandle>;
  if (value === undefined) {
    promise = Promise.resolve(settledRef);
  } else {
    promise = runSdkWrite(beginWorkerDatabaseActivity(pushed, 'push', 'operation'), async () => {
      await dataRpc(ref.port, { t: 'op', id: nextId(), method: 'rtdb.push', path: ref.path, key, value });
      return settledRef;
    });
  }
  return Object.assign(pushed, {
    then: promise.then.bind(promise),
    catch: promise.catch.bind(promise),
  });
}
