/**
 * SharedWorker host — Pyric Studio control ops.
 *
 * The sandbox-snapshot export Studio forks for rules re-run (`getSnapshot`).
 * Kept as its own family to mirror the client's `studio` module.
 *
 * Routed here by the host dispatcher. Never imports the dispatcher.
 */

import { setRules } from 'pyric/sandbox/firestore';
import { sandbox as rtdbSandbox } from 'pyric/database';
import { ensureRtdb } from './core.js';
import { normalizeDatabaseRules } from './rules.js';

import type { OpMessage } from '../protocol.js';
import { type HostCtx, type PortLike, ok, fail, bestEffortFlush } from '../host-context.js';
import { restoreFirestoreSubscriptions } from './subscriptions.js';

/** The Studio control op methods routed to {@link handleStudioOp}. */
const STUDIO_METHODS = new Set<string>([
  'getSnapshot',
  'resetAll',
]);

export function isStudioOp(method: OpMessage['method']): boolean {
  return STUDIO_METHODS.has(method);
}

export async function handleStudioOp(
  ctx: HostCtx,
  port: PortLike,
  msg: OpMessage,
): Promise<void> {
  switch (msg.method) {
    case 'getSnapshot': {
      // Export the current sandbox snapshot (Pyric Studio rules re-run): Studio
      // forks it locally to test edited rules / re-issue as the user on a branch.
      ok(port, msg.id, ctx.sandbox.snapshot());
      break;
    }

    case 'resetAll': {
      // Sandbox-owned full reset (issue #359): the ONE wipe-everything path.
      // `resetAll` iterates the worker sandbox's persistable-service registry,
      // so auth users, the RTDB tree, AND storage objects clear along with the
      // Firestore env — Studio can't forget a service the sandbox knows about.
      // Awaited (storage clears IndexedDB stores) before the ack. Op-level
      // failures reply as errors; per-service reset failures ride the reply
      // payload's `errors` so Studio can surface a half-clear instead of
      // reporting a clean reset.
      try {
        const { errors } = await ctx.sandbox.resetAll();
        // Reset clears Firestore and RTDB rules. Restore the active project
        // policy before serving reads or reattaching Firestore listeners.
        const firestoreRules = ctx.activeRules?.firestore;
        const hasActiveRules = firestoreRules?.status === 'active';
        const source = hasActiveRules ? firestoreRules.source : firestoreRules?.lastKnownGood;
        const hasRulesSource = typeof source === 'string';
        if (hasRulesSource) setRules(ctx.sandbox, source);
        const databaseRules = ctx.activeRules?.database;
        const hasActiveDatabaseRules = databaseRules?.status === 'active';
        const databaseSource = hasActiveDatabaseRules ? databaseRules.source : databaseRules?.lastKnownGood;
        const hasDatabaseSource = databaseSource !== undefined;
        if (hasDatabaseSource) rtdbSandbox.setRules(ensureRtdb(ctx), normalizeDatabaseRules(databaseSource));
        restoreFirestoreSubscriptions(ctx);
        // The server capture (`.pyric/last-session.json`) persists the event
        // history a rebooting worker re-primes into Traffic. Flush it NOW —
        // reset just emptied `sandbox.history()`, and waiting out the
        // capture debounce leaves a window where a worker death resurrects
        // the wiped session's events on the next boot.
        await ctx.captureFlush?.();
        // The hosted policy waits for earlier saves and persists the cleared state.
        await bestEffortFlush(ctx, msg.method);
        ok(port, msg.id, { errors });
      } catch (e) {
        const isError = e instanceof Error;
        if (isError) fail(port, msg.id, e);
        else fail(port, msg.id, new Error(String(e)));
      }
      break;
    }

    default: {
      fail(port, msg.id, new Error(`Unknown method: ${String(msg.method)}`));
    }
  }
}
