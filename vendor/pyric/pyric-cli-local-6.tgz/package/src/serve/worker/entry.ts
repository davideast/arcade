/**
 * SharedWorker entry point — the actual SharedWorker script.
 *
 * WHY A SEPARATE ENTRY
 * --------------------
 * `host.ts` is pure-ish: it accepts an injected `{ db, sandbox }` and
 * fake ports, so tests can drive it without a real SharedWorker runtime.
 * This file is the integration shell: it creates the ONE real sandbox,
 * attaches IDB persistence, deploys permissive starter rules, and wires
 * every connecting port to `handleMessage`.
 *
 * Do NOT import this file in tests — import `host.ts` directly.
 *
 * LIFECYCLE
 * ---------
 * The SharedWorker lives while at least one tab holds a port. When all
 * tabs close or navigate away, the worker is GC'd. IDB persistence means
 * data survives full close → reopen cycles: on the next connect the sandbox
 * restores from IDB, and the tab reconnects to a warm state.
 *
 * PERSISTENCE KEY
 * ---------------
 * Project-scoped: `'pyric-shared-worker:<projectKey>'`, derived inside
 * `buildWorkerCtx` from the init payload's `projectKey` (issue #359 family —
 * IndexedDB is origin-scoped, so the old fixed key shared one sandbox
 * snapshot database across every project on a localhost port). The legacy
 * `'pyric-shared-worker'` key applies only when no project identity exists
 * (older servers, standalone workers); see `workerPersistenceKey` in
 * serve-init.ts for the orphan-don't-delete migration decision.
 *
 * RULES
 * -----
 * We deploy a permissive starter ruleset on first init. Callers change
 * rules at runtime via `{ t:'op', method:'setRules', source }` messages.
 *
 * SINGLE SANDBOX GUARANTEE
 * ------------------------
 * `_ctx` is module-level. The first `connect` event lazily creates it;
 * all subsequent ports reuse the same ctx — one sandbox, one Firestore
 * backend for all tabs. This is the architectural invariant the whole
 * SharedWorker approach depends on.
 */

// SharedWorkerGlobalScope is not in the default TypeScript lib (it's in
// lib.webworker.d.ts which conflicts with lib.dom.d.ts). This entry file is
// browser-only and only bundled with esbuild (never compiled by tsc for
// production). We declare the minimal interface we need so tsc can type-check
// without enabling the full webworker lib.
interface SharedWorkerGlobalScope {
  onconnect: ((e: MessageEvent) => void) | null;
  close(): void;
}

import { createIndexedDBBackend } from 'pyric/sandbox';

import {
  handleMessage,
  type HostCtx,
} from './host.js';
import { fail } from './host-context.js';
import { buildWorkerCtx, type EventSourceLike } from './serve-init.js';
import type { InboundMessage } from './protocol.js';
import { refuseInvalidInboundMessage } from './inbound-validation.js';
import {
  SERVICE_WORKER_CHANNEL,
  type ServiceWorkerChannelMessage,
} from './service-worker-channel.js';
import { createServiceWorkerRelay } from './service-worker-relay.js';
import { createWorkerRetirement } from './retirement.js';
import { createContextResolver } from './context-resolver.js';
import { createPortLifecycleManager } from './port-lifecycle.js';
import { createClientMessageQueue } from './client-message-queue.js';

declare const __PYRIC_WORKER_VERSION__: string;
const workerEpoch = typeof __PYRIC_WORKER_VERSION__ !== 'undefined'
  ? __PYRIC_WORKER_VERSION__
  : 'dev';
const workerScope = self as unknown as SharedWorkerGlobalScope;
const contextResolver = createContextResolver(buildCtx);
const portLifecycle = createPortLifecycleManager();
const retirement = createWorkerRetirement({
  closeWorker: () => workerScope.close(),
  beforeAnnounce: async () => { await contextResolver.current()?.captureFlush?.(); },
});

// ─── Singleton context ────────────────────────────────────────────────────

/**
 * Return the shared context, memoizing the in-flight init promise so
 * concurrent first messages await ONE build. If initialization rejects,
 * the rejection is cleared so subsequent connection attempts can retry.
 * Any ports that closed while initialization was in flight are drained immediately.
 */
async function getCtx(): Promise<HostCtx> {
  const ctx = await contextResolver.get();
  portLifecycle.drainClosedPorts(ctx);
  return ctx;
}

/**
 * Build the ONE shared sandbox + Firestore handle. Invoked exactly once per
 * worker lifetime via the `getCtx` memo — never concurrently. The real boot
 * logic lives in `buildWorkerCtx` (serve-init.ts) so it is testable without
 * a SharedWorker runtime; this shell only supplies the real ambients.
 *
 * NOTE (#754): no worker-side session restore. Sessions are per-port; each
 * PAGE re-establishes its own session from web storage via
 * `auth.restorePortSession` (runtime.ts). The user DB itself is restored
 * from the persisted snapshot inside buildWorkerCtx (#629).
 */
async function buildCtx(): Promise<HostCtx> {
  // ONE IDB backend for the whole worker. createIndexedDBBackend's guard
  // checks `typeof indexedDB === 'undefined'` — SharedWorkers have full
  // IndexedDB access, so this succeeds. The persistence controller's
  // window.addEventListener('beforeunload', ...) is guarded by
  // `typeof window !== 'undefined'`, so enablePersistence is worker-safe.
  const ctx = await buildWorkerCtx({
    fetch,
    idb: createIndexedDBBackend(),
    // EventSource is available in workers; guard anyway for exotic hosts.
    makeEventSource:
      typeof EventSource !== 'undefined'
        ? (url) => new EventSource(url) as unknown as EventSourceLike
        : null,
  });
  return ctx;
}

// ─── SharedWorker connect handler ─────────────────────────────────────────

/**
 * `self` in a SharedWorker is `SharedWorkerGlobalScope`, not `Window`.
 * Each tab that opens the SharedWorker fires one `connect` event.
 * Each tab gets its own `MessagePort`; we start() it (required for
 * classic-mode workers to un-pause the message queue) and wire onmessage.
 */
workerScope.onconnect = (e: MessageEvent) => {
  const port = e.ports[0];
  port.start();
  retirement.connect(port);
  void getCtx().catch(() => undefined);

  const enqueue = createClientMessageQueue({
    async handle(message) {
      const wasClosed = portLifecycle.isPortClosed(port);
      if (wasClosed) return;
      try {
        const ctx = await getCtx();
        const closedDuringInit = portLifecycle.isPortClosed(port);
        if (closedDuringInit) return;
        await handleMessage(ctx, port, message);
      } catch (error) {
        console.error('[pyric worker] message handler error:', error, 'msg:', message);
        // A request whose handler threw, including a sandbox that failed to
        // start, still gets its reply, so the page does not wait on it.
        const canReply = 'id' in message && !portLifecycle.isPortClosed(port);
        if (canReply) fail(port, message.id, error);
      }
    },
    refuse(message, error) {
      port.postMessage({
        t: 'res', id: message.id, clientSessionId: message.clientSessionId, ok: false,
        error,
      });
    },
  });
  port.onmessage = (ev: MessageEvent<InboundMessage>) => {
    const message = ev.data;
    const isRefused = refuseInvalidInboundMessage(port, message);
    if (isRefused) return;
    const readsEpoch = message.t === 'op' && message.method === 'getRuntimeEpoch';
    if (readsEpoch) {
      port.postMessage({
        t: 'res',
        id: message.id,
        ok: true,
        value: {
          version: workerEpoch,
        },
      });
      return;
    }
    const retiresWorker = message.t === 'op' && message.method === 'retireRuntime';
    if (retiresWorker) {
      void retirement.retire(port, message.id, message.targetEpoch);
      return;
    }
    const isRetiring = !retirement.accepting();
    if (isRetiring) {
      const hasRequestId = 'id' in message;
      if (hasRequestId) {
        port.postMessage({
          t: 'res', id: message.id, ok: false,
          error: { code: 'pyric/worker-retiring', message: 'The Pyric worker is restarting.' },
        });
      }
      return;
    }
    // A physical disconnect is a barrier across all this port's client queues.
    // Track every accepted task: the latest client's tail cannot represent them all.
    retirement.trackDetached(enqueue(message));
  };

  // Best-effort port cleanup on tab close/navigation.
  // Chrome doesn't reliably fire 'close' on MessagePort — handled as
  // best-effort; subscriptions also GC when the worker itself dies.
  port.addEventListener('close', () => {
    retirement.disconnect(port);
    portLifecycle.onPortClosed(port, contextResolver.current());
  });
};

// ServiceWorkerGlobalScope cannot construct a SharedWorker, but both worker
// kinds share BroadcastChannel. Adapt each SW app connection to the host's
// existing PortLike seam so it reaches this exact context/broker instead of
// constructing a second in-Service-Worker sandbox.
if (typeof BroadcastChannel !== 'undefined') {
  const channel = new BroadcastChannel(SERVICE_WORKER_CHANNEL);
  const relay = createServiceWorkerRelay({
    getCtx,
    send(message) { channel.postMessage(message); },
    onError(error, envelope) {
      console.error(
        '[pyric worker] service-worker relay error:',
        (error as Error)?.stack ?? error,
        'msg:',
        envelope,
      );
    },
  });
  channel.onmessage = (event: MessageEvent<ServiceWorkerChannelMessage>) => {
    const envelope = event.data;
    if (envelope.direction !== 'host') return;
    // A generation-targeted replacement can briefly overlap this old worker
    // with its successor. Only the accepting generation may answer the shared
    // service-worker relay channel, otherwise both workers would reply.
    if (!retirement.accepting()) return;
    const work = relay.handle(envelope);
    retirement.trackDetached(work);
  };
}
