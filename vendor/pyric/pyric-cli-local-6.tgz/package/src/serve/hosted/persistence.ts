import { requireNodePersistence } from './persistence/sqlite.js';
import { join } from 'node:path';
import { CHECKPOINT_STORE_RELATIVE } from 'pyric/sandbox/checkpoints/directory';
import { openHostedDatabase } from './persistence/database.js';
import { createHostedStateView } from './persistence/state-view.js';
import { validateHostedDatabase, type StorageMetadataRepair } from './persistence/validate.js';
import { archiveHostedDirectory } from './persistence/archive.js';
import type { SweepReport, SweepSignal } from './persistence/blob-store.js';

export const HOSTED_NAMESPACE = 'hosted';
export const hostedStateDirectory = (projectDir: string): string => join(projectDir, '.pyric', 'state', 'hosted');

/** Node owns one durable store; existing browser/MCP files are unrelated. */
export async function createHostedPersistence(projectDir: string, options: { fresh?: boolean } = {}) {
  requireNodePersistence();
  const directory = hostedStateDirectory(projectDir);
  let archive: string | undefined;
  const startsFresh = options.fresh === true;
  if (startsFresh) archive = await archiveHostedDirectory(directory);
  const database = await openHostedDatabase(directory).catch(error => { throw restorationFailure(directory, error); });
  try {
    const repairedObjects = validateHostedDatabase(database);
    // Checkpoints an earlier release kept as files are imported once, on the upgrade that adds their tables.
    database.activate({ checkpointFiles: join(projectDir, CHECKPOINT_STORE_RELATIVE) });
    const state = createHostedStateView(projectDir, directory, database, HOSTED_NAMESPACE);
    const savedArchive = archive;
    const hasArchive = savedArchive !== undefined;
    if (hasArchive) state.backupPath = savedArchive;
    const signal: SweepSignal = { cancelled: false };
    return {
      backend: database.records, storage: database.storage, checkpoints: database.checkpoints, state, repairedObjects,
      /** Removal of object files no row names, begun after startup; closing stops it. */
      sweep: sweepInBackground(database, signal),
      close(): void {
        signal.cancelled = true;
        database.close();
      },
      status: database.status, onFailure: database.onFailure, markUnhealthy: database.markUnhealthy,
      seed: state.seed,
    };
  } catch (error) {
    database.close();
    throw restorationFailure(directory, error);
  }
}

export type HostedPersistence = Awaited<ReturnType<typeof createHostedPersistence>>;

/**
 * Sweep after the current turn, so startup and the first requests never wait
 * for it. It reads the hashes to keep once, then touches only files.
 */
function sweepInBackground(database: Awaited<ReturnType<typeof openHostedDatabase>>, signal: SweepSignal): Promise<SweepReport> {
  return new Promise<void>(resolve => setImmediate(resolve)).then(() => {
    const stopped = signal.cancelled;
    if (stopped) return { removed: 0, bytesRemoved: 0 };
    const startedAt = Date.now();
    return database.objects.sweep(database.referencedObjects(), startedAt, signal);
  }).catch((error: unknown) => {
    // Unreferenced files cost disk space, never correctness; the next start retries.
    console.warn(`[pyric] Sweeping unreferenced Storage object files failed: ${error instanceof Error ? error.message : String(error)}`);
    return { removed: 0, bytesRemoved: 0 };
  });
}

/** Consistent offline export; read-only opening never creates a missing database. */
export async function loadHostedSnapshot(projectDir: string) {
  const directory = hostedStateDirectory(projectDir);
  const database = await openHostedDatabase(directory, { readOnly: true });
  try {
    validateHostedDatabase(database);
    return createHostedStateView(projectDir, directory, database, HOSTED_NAMESPACE).load();
  } finally { database.close(); }
}

/** Startup lines naming each Storage object the stored bytes corrected. */
export function formatStorageRepairs(repairs: readonly StorageMetadataRepair[]): string[] {
  const nothingRepaired = repairs.length === 0;
  if (nothingRepaired) return [];
  return [
    '  ⚠ Repaired Storage metadata that disagreed with the stored bytes; the bytes are unchanged.',
    ...repairs.map(repair => `    • ${repair.bucket}/${repair.path}: recorded size ${repair.recordedSize}, actual size ${repair.actualSize}`),
  ];
}

function restorationFailure(directory: string, cause: unknown): Error {
  return new Error(`Hosted state could not be restored. Preserve '${directory}' and run pyric sandbox salvage --source <hosted-directory> --out <new-directory>.`, { cause });
}
