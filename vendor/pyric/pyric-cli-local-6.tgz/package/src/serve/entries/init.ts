/**
 * `/__pyric/sdk/init.js` — the script tag `pyric dev` injects into every
 * served HTML page. Pulls the shared runtime and mounts the sign-in helper.
 * In worker mode the helper reads the worker user directory and owns UI state
 * only; in fallback mode it mints credentials via `createSignInCredential`
 * so OAuth users carry real provider metadata.
 */
import {
  getAuth,
  sandbox as authSandbox,
} from 'pyric/auth';
import {
  getAuth as getWorkerAuth,
  listUsers,
  setLens,
} from '../worker/client.js';
import {
  switchAllAuthUsers,
  signOutAllAuths,
  commitCredentialToAllAuths,
  getActiveAuthUser,
  subscribeToActiveAuth,
  registerActiveAuth,
} from './active-auth.js';
import { initPayload } from './init-payload.js';
import { sandbox } from './app-backend.js';
import { installAvatarUpgrades } from './avatar-upgrade.js';
import { useWorker, workerDb } from './worker-runtime.js';
import { ServeAuthHelper, customClaimsFromTokenClaims } from './auth-helper-core.js';
import { installServeAuthResolver } from './auth-helper-runtime.js';
import { mountAuthHelperDialog } from './auth-helper-dom.js';
import { configureListenerAttribution } from 'pyric/sandbox/internal';
import { installPyricRuntimeChip } from '../runtime/chip-install.js';
import { sandboxEventSource } from '../runtime/listener-event-source.js';
import { getPyricRuntimeStatus } from '../runtime/status.js';
import { projectRuntimeIdentity } from '../runtime/identity.js';

if (typeof document !== 'undefined' && typeof window !== 'undefined') {
  const localAuth = useWorker ? null : getAuth(sandbox);
  const workerAuth = useWorker && workerDb ? getWorkerAuth(workerDb) : null;
  if (workerAuth) registerActiveAuth(workerAuth);
  if (localAuth) registerActiveAuth(localAuth);
  const helper = workerAuth
    ? new ServeAuthHelper({
        list: async () => (await listUsers(workerAuth)).map((user) => ({
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          // Boundary map: the stored record's `photoUrl` becomes the picker
          // identity's `photoURL`, so re-picking an identity hands its existing
          // photo back to `auth.acceptIdentity`.
          photoURL: user.photoUrl,
          customClaims: user.customClaims,
        })),
      })
    : new ServeAuthHelper(
        {
          list: () => authSandbox.listIdentities(localAuth!),
        },
        (request) => {
          if (request.kind === 'pick') {
            return authSandbox.createSignInCredential(localAuth!, {
              providerId: request.providerId,
              uid: request.identity.uid,
            });
          }
          return authSandbox.createSignInCredential(localAuth!, {
            providerId: request.providerId,
            spec: {
              email: request.spec.email,
              displayName: request.spec.displayName,
              // Boundary map: helper `photoURL` becomes the backend spec's
              // `photoUrl`.
              photoUrl: request.spec.photoURL,
              customClaims: request.spec.customClaims,
            },
          });
        },
      );
  const resolver = helper.resolver();
  installServeAuthResolver(resolver);
  if (localAuth) authSandbox.setAuthFlowResolver(localAuth, resolver);

  mountAuthHelperDialog(helper);
  // A slow avatar source finishes after the browser already painted a
  // placeholder. This page-level listener swaps in the finished image, so
  // application code stays `<img src={user.photoURL}>` with nothing to poll.
  // Not awaited: nothing below depends on the payload.
  void initPayload.then((payload) => {
    installAvatarUpgrades(payload?.avatarUpgrades === true);
  });
  // A served page is a development host whatever the app's bundle says: the
  // template's served build is a Vite production build, which folds the
  // bundled-production check to true and would leave listener attribution off.
  configureListenerAttribution('on');
  installPyricRuntimeChip({
    runtime: getPyricRuntimeStatus(),
    document,
    listenerEvents: sandboxEventSource({ workerDb, sandbox }),
    identity: {
      listUsers: async () => {
        if (workerAuth) {
          return listUsers(workerAuth);
        }
        if (localAuth) {
          return authSandbox.listUsers(localAuth);
        }
        return [];
      },
      switchUser: async (uid: string) => {
        await switchAllAuthUsers(uid);
        setLens(undefined);
      },
      signOut: async () => {
        await signOutAllAuths();
        setLens(undefined);
      },
      openCreateUser: async () => {
        try {
          const cred = await helper.promptCreateUser('password');
          const tokenResult = await cred.user.getIdTokenResult();
          const customClaims = customClaimsFromTokenClaims(
            (tokenResult.claims ?? {}) as Record<string, unknown>,
          );
          const identity = {
            uid: cred.user.uid,
            email: cred.user.email,
            displayName: cred.user.displayName,
            photoURL: cred.user.photoURL,
            customClaims,
            providerId: 'password',
          };
          await commitCredentialToAllAuths(identity);
          await switchAllAuthUsers(identity.uid);
          setLens(undefined);
        } catch (err) {
          console.error('[pyric] openCreateUser error:', err);
        }
      },
      getCurrentUser: () => {
        const active = getActiveAuthUser();
        if (active) return active;
        if (workerAuth?.currentUser) {
          return projectRuntimeIdentity(workerAuth.currentUser);
        }
        if (localAuth?.currentUser) {
          return projectRuntimeIdentity(localAuth.currentUser);
        }
        return null;
      },
      subscribeAuth: (listener) => {
        const unsubActive = subscribeToActiveAuth((user) => {
          listener(projectRuntimeIdentity(user));
        });
        return unsubActive;
      },
    },
  });
}

export {};
