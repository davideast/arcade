/**
 * Wire protocol shared by `@pyric/cli/bridge` (Node bridge) and
 * `@pyric/cli/bridge` (in-browser sandbox connector).
 *
 * The bridge process speaks MCP HTTP to external agents (Claude Code,
 * Cursor) on `/mcp` and WebSocket to the in-browser sandbox on
 * `/sandbox`. Data-plane and sandbox-management tool calls received
 * over MCP are forwarded to whichever browser tab is currently
 * connected; the browser dispatches them into the local
 * `LocalEnvironment` and returns the result.
 *
 * This module has NO runtime imports — only types — so it can be
 * referenced from both the `node` and `browser` builds without
 * pulling Node-specific or DOM-specific modules into the wrong
 * environment.
 */

import type { AuthLens } from 'pyric/sandbox';
import type { OpMessage, SubMessage } from '../serve/worker/protocol.js';

export type { AuthLens };


/** Health report returned by the bridge's `GET /health` endpoint. */
export interface HealthReport {
  status: 'ok';
  /** Constant provenance marker: the programmatic bridge is sandbox-only. */
  mode: 'sandbox';
  /** Sandbox identifier surfaced in health and audit metadata. */
  project: string;
  /** Whether a browser tab is currently connected over `/sandbox`. */
  sandboxConnected: boolean;
  /** Bridge package version. */
  version: string;
  /** ISO timestamp the bridge started. */
  startedAt: string;
  /**
   * Random identity, stable for this bridge process's lifetime. The discovery
   * pointer (`.pyric/serve.json`) records the same value, so a proxy can confirm
   * it reached the SAME server the pointer names — two sandboxes can collide on
   * one port across loopback families (IPv4 `*:P` + IPv6 `[::1]:P`), and `mode`
   * alone can't tell them apart. (Not `version` — that's hardcoded.)
   */
  instanceId: string;
}

/** Default port the standalone bridge binds to. */
export const DEFAULT_BRIDGE_PORT = 5174;

/** Encoded bridge message limit, including its envelope and base64 payloads. */
export const MAX_BRIDGE_FRAME_BYTES = 12 * 1024 * 1024;

/** Mounted MCP sessions and Node execution owners retained until their work drains. */
export const MAX_MOUNTED_MCP_SESSIONS = 64;

/** Maximum accepted operations awaiting completion for one client. */
export const MAX_PENDING_OPERATIONS = 256;

/** Encoded UTF-8 bytes of accepted operation messages awaiting completion per client. */
export const MAX_QUEUED_OPERATION_BYTES = 24 * 1024 * 1024;

/** Default WS path the browser connects to. */
export const DEFAULT_SANDBOX_PATH = '/sandbox';

/** Default HTTP path the MCP client connects to. */
export const DEFAULT_MCP_PATH = '/mcp';

/** Default health endpoint path. */
export const DEFAULT_HEALTH_PATH = '/health';

/**
 * WS close code the transport sends a sandbox peer when a NEWER registration
 * displaces it (last-connection-wins). Application-defined (4000–4999 per RFC
 * 6455 §7.4.2) so it survives every WS stack verbatim. The browser client
 * treats this close as "the slot is legitimately held by another tab" and
 * enters STANDBY (poll the health endpoint, reconnect only when the slot is
 * vacant) instead of re-helloing — two open tabs used to kick each other in a
 * perpetual last-wins fight, re-firing every relayed subscription and failing
 * all in-flight worker ops once per cycle. Any OTHER close (server restart,
 * network drop, tab-refresh takeover) keeps the immediate-reconnect loop.
 */
export const PEER_REPLACED_CLOSE_CODE = 4001;

/** Human-readable reason sent with {@link PEER_REPLACED_CLOSE_CODE}. */
export const PEER_REPLACED_CLOSE_REASON = 'replaced by a newer sandbox peer';

// ── Bridge ↔ browser WebSocket protocol ──────────────────────────────
//
// All messages are JSON. Each message has a `type` discriminator.
// Both directions share the same envelope shape so the wire can be
// audited with a single parser.

/** Browser → bridge: "I'm here and ready to receive tool calls." */
export interface HelloFromClient {
  type: 'hello';
  /** Protocol version. Bump if the wire format changes incompatibly. */
  protocol: 1;
  /** Tool names the browser can dispatch. Bridge uses this to size MCP tool surface. */
  tools: string[];
  /** Stable identifier for this sandbox session (for audit log). */
  sandboxId: string;
  /**
   * Optional peer capabilities (additive). The bridge only sends `worker-*`
   * frames to a peer that declared {@link WORKER_RELAY_CAPABILITY} — an old
   * peer that omits it simply never receives them, and worker ops against it
   * fail fast with a clear error instead of timing out.
   */
  capabilities?: string[];
}

/** Bridge → browser: acknowledge connection. */
export interface HelloFromBridge {
  type: 'hello-ack';
  protocol: 1;
  /** Bridge version, for compatibility checks. */
  bridgeVersion: string;
}

/** Bridge → browser: please dispatch this tool call into the sandbox. */
export interface ToolCallRequest {
  type: 'tool-call';
  /** Server-owned MCP caller identity for execution ordering, separate from its auth lens. */
  callerId?: string;
  /** Correlation id — browser must echo in `ToolCallResponse`. */
  id: string;
  /** Tool name (e.g. `firestore_simulator_create`). */
  name: string;
  /** Tool arguments (JSON-serializable). */
  args: Record<string, unknown>;
  /**
   * The identity the bridge holds for the MCP caller that made this call
   * (`auth_impersonate` / `auth_reset` write it; `auth_whoami` reads it). The
   * peer applies it as the DEFAULT identity for the dispatch: a tool argument
   * that names an identity itself still wins for that call, and a family with
   * no identity seam ignores it. Additive and OMITTED for the default
   * `{ mode: 'app-session' }`, so an un-impersonated call is byte-identical to
   * what the bridge has always sent.
   */
  actAs?: AuthLens;
}

/** Browser → bridge: tool call result. */
export interface ToolCallResponse {
  type: 'tool-result';
  /** Correlation id from the matching request. */
  id: string;
  /** When `ok===false`, `error` is populated and `result` is omitted. */
  ok: boolean;
  /** Tool result (matches `ToolResult` shape from `@inbrowser/agent`). */
  result?: {
    ok: boolean;
    summary: string;
    data?: unknown;
  };
  error?: {
    code: string;
    message: string;
  };
}

// ── Generic worker relay (remote sandbox, slice 1) ───────────────────
//
// Beyond `tool-call`, the bridge can relay ANY SharedWorker-protocol op or
// (snap-delivering) subscription between a Node consumer and the browser
// peer. The SAME frame shapes travel both legs:
//
//   Node consumer ──ws──> bridge ──ws──> browser tab ──port──> worker
//
// Correlation ids/subIds are re-minted per hop (consumer-minted on the
// consumer leg, bridge-minted UUIDs on the peer leg, page-local ids on the
// worker port) so each hop's pending/registry maps stay collision-free.

/** Peer capability flag: "I can relay worker-op / worker-sub frames". */
export const WORKER_RELAY_CAPABILITY = 'worker-relay';

/**
 * Peer capability flag: "Storage bytes travel over the HTTP byte route at
 * `/__pyric/storage/v0/b/`". Only the Node host has one.
 */
export const STORAGE_BYTE_ROUTE_CAPABILITY = 'storage-byte-route';

/** Full port traffic, including app configuration, clock updates, and teardown. */
export const WORKER_PORT_CAPABILITY = 'worker-port';

/** After this interruption window a client must request a fresh logical session. */
export const WORKER_SESSION_RETENTION_MS = 60_000;
/** A recognized released grant requires fresh admission and Auth restoration. */
export const WORKER_SESSION_EXPIRED_CLOSE_CODE = 4004;

export interface WorkerMessageFrame {
  type: 'worker-message';
  clientSessionId?: string;
  message: import('../serve/worker/protocol.js').InboundMessage;
}

export interface WorkerMessageResultFrame {
  type: 'worker-message-result';
  clientSessionId: string;
  message: import('../serve/worker/protocol.js').OutboundMessage;
}

/** `Omit` distributed over a union (plain `Omit` collapses union members). */
type DistributiveOmit<T, K extends PropertyKey> = T extends unknown
  ? Omit<T, K>
  : never;

/** A worker one-shot op, minus the port-level `t`/`id` the relay re-mints. */
export type WorkerOpPayload = DistributiveOmit<OpMessage, 't' | 'id'> & {
  resumeSession?: boolean;
};

/**
 * A worker subscription, minus the port-level `t`/`subId`. Slice 1 relays
 * snap-delivering subs (RTDB value, auth state, Firestore); the unified
 * event stream (`target: 'events'`) is NOT relayable yet — it needs bounded
 * backpressure first (slice 2).
 */
export type WorkerSubPayload = DistributiveOmit<SubMessage, 't' | 'subId'> & {
  resumeSession?: boolean;
};

/** Node consumer → bridge: attach as a worker-relay consumer (NOT a peer —
 *  a consumer never replaces the browser tab in last-connection-wins). */
export interface AttachFromConsumer {
  type: 'attach';
  protocol: 1;
  transport?: 'worker-port';
  /** Host-issued capability for resuming a worker port's original identity. */
  resumeToken?: string;
  /** The process that issued the resume grant; a replacement requires fresh admission. */
  hostInstanceId?: string;
  /** Optional client-supplied session ID to resume an existing session across reconnects. */
  clientSessionId?: string;
  /** Alias for clientSessionId (backward/cross-platform compatibility). */
  sessionId?: string;
  /** Optional client metadata for identification in logs and Studio presence. */
  clientInfo?: {
    platform?: 'kotlin' | 'swift' | 'flutter' | 'node' | 'studio' | string;
    deviceLabel?: string;
  };
}

/** Bridge → Node consumer: attach acknowledged. */
export interface AttachAckFromBridge {
  type: 'attach-ack';
  protocol: 1;
  capabilities?: string[];
  /** Local project identity, distinct from the bridge's human-readable label. */
  projectKey?: string;
  bridgeVersion: string;
  /** Whether a browser tab is currently registered as the sandbox peer. */
  peerConnected: boolean;
  /** Alias for peerConnected (matches PROJECT.md interface contract). */
  sandboxConnected?: boolean;
  /**
   * The `@pyric/cli` package version the serve/bridge process runs
   * (version-skew stamp). ADDITIVE + OPTIONAL: old servers omit it and
   * the client stays silent. When present and different from the
   * client's own version, the client warns once at attach and enriches
   * op-timeout errors — a skewed old worker can accept a newer op frame
   * and die mid-handling, which otherwise surfaces as a bare timeout.
   */
  serveVersion?: string;
  /** Client-scoped session ID assigned or acknowledged by the bridge. */
  clientSessionId: string;
  /** Alias for clientSessionId. */
  sessionId?: string;
  /** Private to this connection; never included in consumer presence. */
  resumeToken?: string;
  /** Process identity, independent of the stable project identity. */
  hostInstanceId?: string;
}

/** Toward the worker: dispatch this one-shot op. (consumer→bridge and
 *  bridge→browser use the same shape; `id` is per-leg.) */
export interface WorkerOpFrame {
  type: 'worker-op';
  /** Correlation id — echoed back in the matching `worker-res`. */
  id: string;
  /** Scopes this op to a specific remote client virtual port. */
  clientSessionId?: string;
  op: WorkerOpPayload;
}

/** Away from the worker: the relayed op result. */
export interface WorkerResFrame {
  type: 'worker-res';
  id: string;
  /** Scopes this response to a specific remote client virtual port. */
  clientSessionId?: string;
  /** When `ok === false`, `error` is populated and `value` omitted. */
  ok: boolean;
  value?: unknown;
  /** `denialContext` (additive, spike gap 6): the structured "why did this
   *  deny" frame a `SandboxError` carries on `permission-denied` — plain
   *  JSON, so it rides the WS legs verbatim and the Node side re-attaches it. */
  error?: {
    code: string;
    message: string;
    denialContext?: unknown;
    envelope?: unknown;
  };
}

/** Toward the worker: register a subscription. Re-issued by the bridge to a
 *  NEW peer on reconnect/replacement (value subs re-deliver a fresh initial
 *  snapshot, so replay is cursor-free and last-value-wins-safe). */
export interface WorkerSubFrame {
  type: 'worker-sub';
  subId: string;
  /** Scopes this subscription to a specific remote client virtual port. */
  clientSessionId?: string;
  sub: WorkerSubPayload;
}

/** Toward the worker: tear a subscription down. */
export interface WorkerUnsubFrame {
  type: 'worker-unsub';
  subId: string;
  /** Scopes this unsubscribe to a specific remote client virtual port. */
  clientSessionId?: string;
}

/** Away from the worker: one streamed snapshot for a subscription. A failed
 *  ESTABLISHMENT also arrives here as `value: { __error: { code, message } }`
 *  (the worker host's snap-error convention) — relays forward it verbatim. */
export interface WorkerSnapFrame {
  type: 'worker-snap';
  subId: string;
  /** Scopes this snapshot to a specific remote client virtual port. */
  clientSessionId?: string;
  value: unknown;
}

/** Bridge → browser peer: notify that a remote client disconnected. */
export interface WorkerClientDisconnectFrame {
  type: 'worker-client-disconnect';
  clientSessionId: string;
}

/** Bridge → hosted peer: transport loss while logical identity is retained. */
export interface WorkerClientInterruptedFrame {
  type: 'worker-client-interrupted';
  clientSessionId: string;
}

/** Record representing an attached remote consumer in presence snapshots. */
export interface RemoteConsumerRecord {
  clientSessionId: string;
  platform: 'kotlin' | 'swift' | 'flutter' | 'node' | 'studio' | string;
  deviceLabel?: string;
  connectedAt: number;
  lastSeen: number;
  activeLens: AuthLens;
}

/** Bridge → browser peer / Studio: broadcast connected remote consumer presence. */
export interface ConsumerPresenceFrame {
  type: 'consumer-presence';
  consumers: RemoteConsumerRecord[];
}

/** Studio / peer → bridge: remote request to mutate a consumer's active AuthLens. */
export interface RemoteSetLensFrame {
  type: 'remote-set-lens';
  id?: string;
  clientSessionId: string;
  lens: AuthLens;
}

/** Bridge → Studio / peer: acknowledgement of a remote lens mutation request. */
export interface RemoteSetLensAckFrame {
  type: 'remote-set-lens-ack';
  id?: string;
  clientSessionId: string;
  ok: boolean;
  error?: {
    code: string;
    message: string;
  };
}

/** Bridge → consumer: notify consumer of runtime events (e.g. remote lens change). */
export interface WorkerEventRemoteLensFrame {
  type: 'worker-event';
  event: 'remote-lens';
  clientSessionId?: string;
  lens: AuthLens;
}

export type WorkerEventFrame = WorkerEventRemoteLensFrame;

/** Either direction: ping for keepalive / liveness detection. */
export interface Ping {
  type: 'ping';
  /** Echo back as `pong.id`. */
  id: string;
}

/** Pong response to a Ping. */
export interface Pong {
  type: 'pong';
  id: string;
}

export type BridgeMessage =
  | HelloFromClient
  | HelloFromBridge
  | AttachFromConsumer
  | AttachAckFromBridge
  | ToolCallRequest
  | ToolCallResponse
  | WorkerOpFrame
  | WorkerResFrame
  | WorkerSubFrame
  | WorkerUnsubFrame
  | WorkerSnapFrame
  | WorkerClientDisconnectFrame
  | WorkerClientInterruptedFrame
  | ConsumerPresenceFrame
  | RemoteSetLensFrame
  | RemoteSetLensAckFrame
  | WorkerEventFrame
  | WorkerMessageFrame
  | WorkerMessageResultFrame
  | Ping
  | Pong;

/** Type guard for runtime parsing. */
export function isBridgeMessage(value: unknown): value is BridgeMessage {
  const isNotObject = value === null || typeof value !== 'object';
  if (isNotObject) return false;
  const t = (value as { type?: unknown }).type;
  return (
    t === 'hello' ||
    t === 'hello-ack' ||
    t === 'attach' ||
    t === 'attach-ack' ||
    t === 'tool-call' ||
    t === 'tool-result' ||
    t === 'worker-op' ||
    t === 'worker-res' ||
    t === 'worker-sub' ||
    t === 'worker-unsub' ||
    t === 'worker-snap' ||
    t === 'worker-client-disconnect' ||
    t === 'worker-client-interrupted' ||
    t === 'consumer-presence' ||
    t === 'remote-set-lens' ||
    t === 'remote-set-lens-ack' ||
    t === 'worker-event' ||
    t === 'worker-message' ||
    t === 'worker-message-result' ||
    t === 'ping' ||
    t === 'pong'
  );
}

/** Error returned by MCP when no browser tab is currently connected. */
export const NO_SANDBOX_ERROR_MESSAGE =
  'sandbox not connected. Open your dev server in a browser and refresh the page so the bridge client can register.';

/** Error for worker ops against a peer that predates the worker relay. */
export const NO_WORKER_RELAY_ERROR_MESSAGE =
  'the connected browser tab does not support the worker relay — reload the tab (and update pyric if reloading does not help).';

// ─── Binary-payload guard (worker-op relay boundary) ────────────────────────
//
// Both WS legs of the worker relay are `JSON.stringify` — a `Blob` or
// `ArrayBuffer` in a relayed value silently becomes `{}` and a TypedArray /
// Buffer becomes an index-keyed object. Nothing errors; the far side just
// receives garbage (the live failure mode: relaying `storage.getBlob` yields
// `{}`). This guard turns that silent corruption into a loud, remediable
// rejection at the relay boundary. It is a cheap explicit TYPE check
// (Blob/ArrayBuffer/TypedArray/DataView), NOT a full JSON round-trip.

/** Human label for a non-JSON-safe binary value, or null when `value` (and
 *  every nested array/plain-object member) is free of binary containers. */
export function findBinaryPayload(value: unknown): string | null {
  if (value === null || typeof value !== 'object') return null;
  if (typeof Blob !== 'undefined' && value instanceof Blob) return 'Blob';
  if (value instanceof ArrayBuffer) return 'ArrayBuffer';
  if (ArrayBuffer.isView(value)) {
    return (value as { constructor?: { name?: string } }).constructor?.name ?? 'TypedArray';
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const hit = findBinaryPayload(item);
      if (hit) return hit;
    }
    return null;
  }
  for (const item of Object.values(value as Record<string, unknown>)) {
    const hit = findBinaryPayload(item);
    if (hit) return hit;
  }
  return null;
}

/**
 * Assert a worker-op result (or subscription snap value) is safe to
 * serialize onto the JSON relay. Throws (code `invalid-argument`) naming
 * the offending type and the base64 storage ops to use instead — so a
 * future caller relaying `storage.getBlob` gets a clear error, not `{}`.
 *
 * `context` is a human label for the message: `op '<method>'` for op
 * results, `subscription '<subId>'` for snap values.
 */
export function assertJsonSafeRelayValue(
  context: string,
  value: unknown,
): void {
  const kind = findBinaryPayload(value);
  if (!kind) return;
  const err = new Error(
    `worker ${context} produced a binary payload (${kind}) that cannot cross the ` +
      'JSON bridge relay — it would be silently corrupted by JSON.stringify. Use the ' +
      "base64 storage ops instead ('storage.getBytes' / 'storage.putBytes'), which carry " +
      "bytes as JSON-safe 'dataB64' strings; 'storage.getBlob' is MessagePort-only.",
  ) as Error & { code: string };
  err.code = 'invalid-argument';
  throw err;
}
