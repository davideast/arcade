/**
 * The three words each method's name is built from, for the surfaces that spell
 * one tool per method.
 *
 * The `verb-prefixed`, `noun-prefixed`, and `verb-suffixed` surfaces exist to
 * measure whether word order changes how well a model picks a tool, so the
 * words are the whole subject of the measurement and they are stated here, once,
 * rather than parsed out of a method name. Most methods reuse the canonical
 * operation's own words; the identity methods do not, because four of them
 * share one operation and each still needs a name of its own.
 */
import { METHODS } from '../methods/registry.js';
import { operationIds } from '../method-types.js';

/**
 * The verb, service, and object one method's names are spelled from. A
 * canonical operation of two words, such as `reset_sandbox`, leaves the object
 * empty, and an empty word is dropped rather than spelled as a separator.
 */
export interface MethodWords {
  verb: string;
  service: string;
  object: string;
}

/** One tool name from the words a surface put in order, dropping empty words. */
export function spellName(words: readonly string[]): string {
  return words.filter((word) => word.length > 0).join('_');
}

/** The methods whose words are not the canonical operation's own. */
const OVERRIDES: Readonly<Record<string, MethodWords>> = {
  'auth.impersonate': { verb: 'impersonate', service: 'auth', object: 'user' },
  'auth.actAsAdmin': { verb: 'become', service: 'auth', object: 'admin' },
  'auth.actAsAnonymous': { verb: 'become', service: 'auth', object: 'anonymous' },
  'auth.useAppSession': { verb: 'adopt', service: 'auth', object: 'session' },
  'firestore.getDocs': { verb: 'read', service: 'firestore', object: 'collection' },
  'rules.lint': { verb: 'lint', service: 'rules', object: 'source' },
  'rules.simulate': { verb: 'simulate', service: 'rules', object: 'request' },
  'rules.set': { verb: 'set', service: 'rules', object: 'source' },
  // `ai_logic` is the one tool name that itself carries an underscore.
  // `fromCanonicalId` splits a canonical id on '_' and takes the second word
  // as the whole service, which would read the service off `script_ai_logic`
  // as `ai` and strand `logic` as the object. Every ai_logic method is
  // overridden here so its words are spelled by hand instead of parsed.
  'ai_logic.script': { verb: 'script', service: 'ai_logic', object: '' },
  'ai_logic.clearScripts': { verb: 'clear', service: 'ai_logic', object: 'scripts' },
  'ai_logic.scripts': { verb: 'list', service: 'ai_logic', object: 'scripts' },
  'ai_logic.status': { verb: 'get', service: 'ai_logic', object: 'status' },
};

/** The words a canonical id carries, which is `verb_service_object` by construction. */
function fromCanonicalId(id: string): MethodWords {
  const [verb, service, ...rest] = id.split('_');
  return { verb: verb!, service: service!, object: rest.join('_') };
}

function loadWords(): ReadonlyMap<string, MethodWords> {
  const words = new Map<string, MethodWords>();
  const claimed = new Set<string>();
  for (const method of METHODS) {
    const override = OVERRIDES[method.key];
    const ids = operationIds(method);
    const chosen = override ?? fromCanonicalId(ids[0]!);
    const name = spellName([chosen.verb, chosen.service, chosen.object]);
    if (claimed.has(name)) throw new Error(`method words '${name}' are claimed twice`);
    claimed.add(name);
    words.set(method.key, chosen);
  }
  return words;
}

const WORDS = loadWords();

/** The words one method is named from. */
export function wordsFor(key: string): MethodWords {
  const words = WORDS.get(key);
  if (words === undefined) throw new Error(`no name words for method '${key}'`);
  return words;
}
