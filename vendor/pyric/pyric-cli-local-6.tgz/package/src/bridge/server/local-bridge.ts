/**
 * In-process ("local") Bridge for the in-process MCP server.
 *
 * The serve / standalone bridges forward data-plane tool calls over a WebSocket
 * to the in-page sandbox. The in-process server has no page: the sandbox runs IN
 * this process, so the bridge's `dispatch` executes tools directly through
 * `buildSandboxDispatcher`. Everything else the `Bridge` contract needs is
 * trivial for a peerless bridge (always "connected", with the tool set from
 * the dispatcher's `SANDBOX_TOOL_NAMES`).
 *
 * Because `buildSandboxDispatcher` is the SAME source the served bridge
 * advertises (pinned by `tool-parity.test.ts`), the in-process tool surface is
 * identical to the served one, including the per-identity `as` arg and the
 * caller identity `auth_impersonate` records.
 *
 * See design rationale (in-process mode).
 */
import type { LocalSandbox } from 'pyric/sandbox';
import { buildSandboxDispatcher, SANDBOX_TOOL_NAMES } from '../client/dispatch.js';
import {
  createBridge,
  type Bridge,
  type BridgeToolEvent,
  type BridgeToolResult,
} from './bridge.js';
import { pyricVersion } from '../../serve/standalone-assets.js';

export interface LocalBridgeOptions {
  /** Reported as the MCP server version. */
  version?: string;
  /** Project label surfaced in tool-result metadata. */
  project?: string;
  /** Called after each dispatch (success or failure). The in-process runner uses
   *  this to schedule a debounced persistence flush so writes survive a restart. */
  onAfterDispatch?: () => void;
  /**
   * Called once for every finished tool call, success or failure. The forwarding
   * bridge records these inside its own `dispatch`; the local bridge replaces
   * that `dispatch`, so it records them here instead. In-process tools reach the
   * same hook through the base bridge's `recordToolEvent`.
   */
  onToolEvent?: (event: BridgeToolEvent) => void;
}

/**
 * A {@link Bridge} backed by an in-process {@link Sandbox}. `dispatch` runs tools
 * locally; the peer-management members are no-ops (there is no remote peer).
 */
export function createLocalBridge(sandbox: LocalSandbox, opts: LocalBridgeOptions = {}): Bridge {
  const dispatcher = buildSandboxDispatcher(sandbox);
  // Reuse the real bridge for the boilerplate the contract needs (startedAt,
  // instanceId, health, recordToolEvent, the peer machinery), then override the
  // three members that differ when the sandbox is in-process rather than a ws
  // peer. The peer machinery stays idle because `dispatch` never touches it.
  const project = opts.project ?? 'sandbox';
  const base = createBridge({
    project,
    version: opts.version ?? pyricVersion(),
    onToolEvent: opts.onToolEvent,
  });
  const recordEvent = (event: BridgeToolEvent): void => {
    if (!opts.onToolEvent) return;
    try {
      opts.onToolEvent(event);
    } catch {
      // Event-log failures must not break tool dispatch.
    }
  };
  return {
    ...base,
    // The sandbox is in-process: always "connected", and the tool set is the
    // dispatcher's, not a (nonexistent) peer's hello.
    isSandboxConnected: () => true,
    toolNames: () => [...SANDBOX_TOOL_NAMES],
    // Execute tools locally instead of forwarding to a ws peer. The bridge
    // contract RETURNS a result (ok:false on failure) rather than rejecting, and
    // `buildSandboxDispatcher` throws on a tool error (e.g. a rules denial), so
    // translate that here.
    async dispatch(name, args) {
      const startedAtMs = Date.now();
      let result: BridgeToolResult;
      try {
        // Same rule as the forwarding bridge: the caller's recorded identity is
        // the default for a call whose own arguments name none. `app-session`
        // is sent as no identity at all, which is the historical behaviour.
        const identity = base.callerIdentity.get();
        const actAs = identity.mode === 'app-session' ? undefined : identity;
        result = await dispatcher(name, args, actAs);
      } catch (e) {
        result = { ok: false, summary: e instanceof Error ? e.message : String(e) };
      } finally {
        opts.onAfterDispatch?.();
      }
      recordEvent({
        timestamp: new Date(startedAtMs).toISOString(),
        mode: 'sandbox',
        project,
        tool: name,
        args,
        result,
        durationMs: Date.now() - startedAtMs,
        isError: !result.ok,
      });
      return result;
    },
  };
}
