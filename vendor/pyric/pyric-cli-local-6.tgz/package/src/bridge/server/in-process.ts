/**
 * InProcess MCP server: runs the pyric sandbox IN this process (no browser, no
 * serve) and exposes the SAME tool surface the bridge advertises, over stdio.
 *
 * This is the zero-setup half of the hybrid MCP server
 * (design rationale): when no `pyric dev --bridge` is running to
 * attach to, the MCP server hosts its own sandbox. The tool surface is identical
 * to the served bridge by construction (`buildSandboxDispatcher` is the shared
 * source pinned by `tool-parity.test.ts`), including the per-identity `as` arg.
 *
 * Persistence (Phase 1b) uses the v3 bundle codec the worker already uses for
 * transfer/branches (`serializeToBuckets` + `bundleRecords`). It writes its OWN
 * `.pyric/state/in-process.json`, NOT serve's `state.json` (which currently uses a
 * different on-disk envelope, and carries a controller-blob version that has
 * drifted from pyric's snapshot SCHEMA_VERSION). Unifying the two formats so a
 * in-process session and a `pyric dev` session can share one file is a tracked
 * design item, not done here.
 */
import { existsSync, readFileSync, writeFileSync, mkdirSync, renameSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import {
  initializeSandbox,
  serializeToBuckets,
  bundleRecords,
  parseBundle,
  deserializeFromBuckets,
  type LocalSandbox,
} from 'pyric/sandbox';
import { getFirestore } from 'pyric/firestore';
import { setRules } from 'pyric/sandbox/firestore';
import { getAuth, sandbox as authSandbox } from 'pyric/auth';
import { getAdminDatabase } from 'pyric/database';
import { getAdminStorageSandbox } from 'pyric/storage/internal';
import type { FirebaseStorage } from 'pyric/storage';
import {
  saveStorageSidecar,
  loadStorageSidecar,
  STORAGE_SIDECAR_RELATIVE,
} from './storage-sidecar.js';
import { type RejectedToolCall } from './mcp.js';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { registerRenderedSurface } from './surface-server.js';
import { renderSurface } from '../surface/index.js';
import { createSurfaceContext } from '../surface/context.js';
import { rememberUnloadedStorageRules } from '../surface/storage-rules.js';
import { createLocalBridge, type LocalBridgeOptions } from './local-bridge.js';
import {
  createEvalLogWriter,
  readEvalRunIdentity,
  EVAL_LOG_ENV_KEY,
  type AuditWriter,
} from './audit.js';
import type { BridgeToolEvent } from './bridge.js';
import type { Transport } from '@modelcontextprotocol/sdk/shared/transport.js';
import { claimProjectState } from '../../serve/hosted/project-ownership.js';
import { TargetRouter } from './target-router.js';
import type { discoverServe } from '../../serve/discovery.js';
import type { callHostedMethod } from '../../cli/hosted-method.js';

/** The stdio transport is a late import: the SDK is heavy and only needed here. */
async function openStdioTransport(): Promise<Transport> {
  const { StdioServerTransport } = await import('@modelcontextprotocol/sdk/server/stdio.js');
  return new StdioServerTransport();
}

/** Where the in-process sandbox snapshot is persisted (relative to the project
 *  dir). Deliberately separate from serve's `state.json` (different format). */
export const IN_PROCESS_STATE_RELATIVE = join('.pyric', 'state', 'in-process.json');

export interface InProcessMcpServerOptions extends LocalBridgeOptions {
  /** Tool-surface variant id. Absent serves the default surface. */
  surface?: string;
  /**
   * Directory the session's `.pyric/` files live under, handed to every method
   * that reaches the filesystem. Absent, the process working directory.
   */
  projectDir?: string;
  /**
   * Mount `production` methods (ADR-0014 Decision 5). Defaults to false: a
   * `production` method is neither listed nor callable unless the server was
   * started with `--allow-production`.
   */
  allowProduction?: boolean;
  /**
   * Called for a tool call the MCP SDK refused before any handler ran, so a
   * schema rejection is still recorded. Absent leaves the server as it was.
   */
  onCallRejected?: (event: BridgeToolEvent) => void;
  /** Suppress following a live Node host (--in-process flag). */
  inProcessOnly?: boolean;
  /** Pre-configured target router, if any. */
  targetRouter?: TargetRouter;
  /** Cache TTL in ms for the pointer check (default 1000ms). */
  cacheTtlMs?: number;
  /** Injected discovery function for testing. */
  discover?: typeof discoverServe;
  /** Injected hosted method caller for testing. */
  callHosted?: typeof callHostedMethod;
}

/**
 * Build the in-process MCP server around an in-process sandbox. Pure: no I/O and
 * no transport, so callers (and tests) can drive it however they like. Mirrors
 * the served bridge's construction (forwarded data-plane + in-process rules
 * tools), with `dispatch` bound to the local sandbox instead of a ws peer.
 */
export function buildInProcessMcpServer(sandbox: LocalSandbox, opts?: InProcessMcpServerOptions) {
  const bridge = createLocalBridge(sandbox, opts);
  const onCallRejected = opts?.onCallRejected;
  const rejectionEvent = (rejection: RejectedToolCall): void => {
    onCallRejected?.({
      timestamp: new Date().toISOString(),
      mode: 'sandbox',
      project: bridge.project,
      tool: rejection.tool,
      args: rejection.args,
      result: { ok: false, summary: rejection.message },
      durationMs: rejection.durationMs,
      schemaRejected: rejection.schemaRejected,
      isError: true,
    });
  };

  // The product surface is the service tools rendered from the method records,
  // and it is what a server with no `--surface` serves. A surface id renders
  // another spelling of the same records for the surface evaluation. Either way
  // the rendering is registered through the surface adapter, so one code path
  // serves the product and the measurements.
  //
  // Throws for an id no renderer claims, which fails the session at startup
  // rather than measuring the wrong surface.
  const rendered = renderSurface(opts?.surface, { allowProduction: opts?.allowProduction });
  const server = new McpServer({ name: 'pyric', version: bridge.version });
  const projectDir = opts?.projectDir ?? process.cwd();
  const targetRouter =
    opts?.targetRouter ??
    new TargetRouter({
      projectDir,
      inProcessOnly: opts?.inProcessOnly,
      allowProduction: opts?.allowProduction,
      cacheTtlMs: opts?.cacheTtlMs,
      discover: opts?.discover,
      callHosted: opts?.callHosted,
    });
  const surfaceContext = createSurfaceContext(sandbox, projectDir, targetRouter);
  return registerRenderedSurface(server, bridge, rendered, surfaceContext, {
    onCallRejected: onCallRejected ? rejectionEvent : undefined,
    onAfterCall: opts?.onAfterDispatch,
  });
}

/**
 * Load `<cwd>/firestore.rules` into the sandbox when present. Returns the path
 * it loaded, or null if there was no rules file. Without rules, rules-enforcing
 * (`as:{uid}`) ops fall back to the sandbox's default; admin ops are unaffected.
 */
export function loadProjectRules(sandbox: LocalSandbox, cwd: string): string | null {
  const rulesPath = join(cwd, 'firestore.rules');
  if (!existsSync(rulesPath)) return null;
  setRules(sandbox, readFileSync(rulesPath, 'utf8'));
  return rulesPath;
}

/**
 * Open the services whose state a snapshot carries.
 *
 * `loadSnapshot` restores only services that are already registered, so a start
 * that applies a snapshot before anything has touched auth, database, or
 * storage drops those buckets without a word. Opening them first is what makes
 * a restored session complete. Returns the storage handle, which the sidecar
 * codec reads and writes; storage keeps its own durability and is not in the
 * bundle at all.
 */
export function openPersistedServices(sandbox: LocalSandbox, cwd: string): FirebaseStorage {
  getAuth(sandbox);
  getAdminDatabase(sandbox);
  // Storage rules are read only by the call that opens the service, so the
  // project's rules have to be in hand here or not at all.
  const rulesPath = join(cwd, 'storage.rules');
  if (!existsSync(rulesPath)) return getAdminStorageSandbox(sandbox);
  const source = readFileSync(rulesPath, 'utf8');
  try {
    return getAdminStorageSandbox(sandbox, { rules: source });
  } catch (error) {
    // A rules file that does not parse cannot govern the service, but a lint
    // call must still be able to say what is wrong with it. The service opens
    // without rules and the source is kept for the lint operation.
    process.stderr.write(
      `[pyric mcp in-process] storage.rules not loaded: ${error instanceof Error ? error.message : String(error)}\n`,
    );
    rememberUnloadedStorageRules(sandbox, source);
    return getAdminStorageSandbox(sandbox);
  }
}

/**
 * Where the app session rides inside a snapshot's `services` map, alongside
 * the persistable services the sandbox core knows about. `sandbox.snapshot()`
 * and `loadSnapshot()` are keyed by registered service name and this name is
 * never registered, so the sandbox core passes it through untouched in both
 * directions without knowing it carries anything auth-shaped.
 */
const APP_SESSION_SERVICE_KEY = '__pyric_cli_app_session';

/** What is captured for the app session: the signed-in uid and the tenant
 *  scope it authenticated under, so a later process restores both rather than
 *  just the uid and a default (untenanted) scope. */
interface PersistedAppSession {
  uid: string;
  tenantId: string | null;
}

/** The app session to fold into a snapshot's `services` map, or `null` when
 *  signed out, meaning nothing for a later process to restore. */
function captureAppSession(sandbox: LocalSandbox): PersistedAppSession | null {
  const auth = getAuth(sandbox);
  const uid = auth.currentUser?.uid ?? null;
  if (uid === null) return null;
  return { uid, tenantId: authSandbox.getTenantId(auth) };
}

/**
 * Sign the captured uid back in through the auth backend's own restore seam
 * (`sandbox.restoreSession`), never a session minted outside it, then restore
 * the tenant scope it carried. Called after `sandbox.loadSnapshot()` so the
 * user pool the uid names is already back in place. A uid the pool no longer
 * holds (the user was deleted since the snapshot was taken) leaves the app
 * signed out rather than throwing: the state file is stale, not corrupt.
 */
function restoreAppSession(sandbox: LocalSandbox, stored: unknown): void {
  const parsed = stored as PersistedAppSession | null | undefined;
  if (parsed === null || parsed === undefined) return;
  const auth = getAuth(sandbox);
  try {
    authSandbox.restoreSession(auth, parsed.uid);
  } catch {
    return;
  }
  authSandbox.setTenantId(auth, parsed.tenantId);
}

/**
 * Persist the sandbox to `<cwd>/.pyric/state/in-process.json` using the v3 bundle
 * codec (the same `serializeToBuckets` + `bundleRecords` the worker uses). Atomic
 * tmp+rename so a crash mid-write never truncates the live file. Carries the
 * app session (the uid `auth.currentUser` names, and its tenant) alongside the
 * user pool, so `pyric auth signInWithEmailAndPassword` in one process and
 * `pyric auth whoami` in the next see the same session.
 */
export function saveSandboxSnapshot(sandbox: LocalSandbox, cwd: string): void {
  const snap = sandbox.snapshot();
  const services = { ...snap.services, [APP_SESSION_SERVICE_KEY]: captureAppSession(sandbox) };
  const bundle = bundleRecords(serializeToBuckets(snap.firestore, services, 0));
  const path = join(cwd, IN_PROCESS_STATE_RELATIVE);
  mkdirSync(dirname(path), { recursive: true });
  const tmp = `${path}.tmp-${process.pid}`;
  writeFileSync(tmp, bundle, 'utf8');
  renameSync(tmp, path);
}

/**
 * Restore the sandbox from the in-process snapshot file if present (a clobber via
 * `loadSnapshot`). Returns the restored doc count, or null when there is no file.
 */
export function loadSandboxSnapshot(sandbox: LocalSandbox, cwd: string): number | null {
  const path = join(cwd, IN_PROCESS_STATE_RELATIVE);
  if (!existsSync(path)) return null;
  const snap = deserializeFromBuckets(parseBundle(readFileSync(path, 'utf8')));
  sandbox.loadSnapshot(snap);
  restoreAppSession(sandbox, snap.services[APP_SESSION_SERVICE_KEY]);
  return Object.keys(snap.firestore).length;
}

export interface InProcessRunOptions {
  /** Tool-surface variant id, from `--surface` or `PYRIC_TOOL_SURFACE`. */
  surface?: string;
  /**
   * Mount `production` methods, from `--allow-production` or
   * `PYRIC_ALLOW_PRODUCTION`. Defaults to false.
   */
  allowProduction?: boolean;
  /**
   * Directory the session reads its rules files and `.pyric/state` from and
   * writes them back to, from `--project-dir` or `PYRIC_PROJECT_DIR`. A relative
   * value resolves against `cwd`. Absent, the project directory is `cwd`, which
   * is what every existing caller gets.
   */
  projectDir?: string;
  /** Environment to read the evaluation settings from. Defaults to the process. */
  env?: NodeJS.ProcessEnv;
  /**
   * Transport to serve on. Defaults to stdio, which is what an editor and the
   * evaluation runner both use; a test supplies an in-memory pair so it can
   * close the session and observe the final flush.
   */
  transport?: Transport;
  /** Suppress following a live Node host (--in-process flag). */
  inProcessOnly?: boolean;
}

/**
 * Build the tool-event writer for an in-process session. Returns null when no
 * evaluation log is named, which is the default and records nothing.
 */
export function createInProcessEventWriter(env: NodeJS.ProcessEnv): AuditWriter | null {
  const evalLogPath = env[EVAL_LOG_ENV_KEY];
  if (evalLogPath === undefined || evalLogPath.trim() === '') return null;
  return createEvalLogWriter(evalLogPath, readEvalRunIdentity(env));
}

/**
 * Wire a session's event writer into the server options. Without a writer the
 * options are left as they were, and the server records nothing.
 */
export function withInProcessEventWriter(
  options: InProcessMcpServerOptions,
  writer: AuditWriter | null,
): InProcessMcpServerOptions {
  if (!writer) return options;
  return {
    ...options,
    onToolEvent: (event) => writer.write(event),
    onCallRejected: (event) => writer.write(event),
  };
}

/**
 * Run the in-process MCP server over stdio. Loads `.pyric/state/in-process.json` and
 * the storage sidecar on start, debounces a save after each dispatch, and
 * flushes both on shutdown. Resolves with an exit code when the stdio transport
 * closes (the editor disconnects).
 *
 * Every file the session touches lives under the project directory, which is
 * `cwd` unless `options.projectDir` names another one. Separating the two lets a
 * caller start the server in a directory that holds none of the state the
 * session reads or writes.
 *
 * With `PYRIC_EVAL_LOG` set, every tool call is appended to that file as NDJSON
 * and the per-project audit log is not written. Without it, nothing is recorded,
 * which is the behaviour in-process mode has always had.
 */
export async function runInProcessMcp(
  cwd: string = process.cwd(),
  options: InProcessRunOptions = {},
): Promise<number> {
  const projectDir = resolve(cwd, options.projectDir ?? '.');
  mkdirSync(projectDir, { recursive: true });
  const owner = await claimProjectState(projectDir, 'in-process');
  try {
    return await runInProcessSession(projectDir, options);
  } finally {
    owner.close();
  }
}

async function runInProcessSession(
  projectDir: string,
  options: InProcessRunOptions,
): Promise<number> {
  const log = (m: string): void => {
    process.stderr.write(`[pyric mcp in-process] ${m}\n`);
  };
  const failureMessage = (error: unknown): string => {
    const isError = error instanceof Error;
    return isError ? error.message : String(error);
  };

  const env = options.env ?? process.env;
  const evalLog = createInProcessEventWriter(env);
  const recordsEvaluation = evalLog !== null;
  if (recordsEvaluation) log(`recording tool events to ${evalLog.path}`);

  const sandbox = initializeSandbox();
  // Before the snapshot, and before the transport serves a single call.
  const storage = openPersistedServices(sandbox, projectDir);
  const restored = loadSandboxSnapshot(sandbox, projectDir);
  const restoredSnapshot = restored !== null;
  if (restoredSnapshot) {
    log(`restored ${restored} docs from ${join(projectDir, IN_PROCESS_STATE_RELATIVE)}`);
  }
  // After the snapshot: restoring it resets the ruleset to the sandbox default,
  // and the project's rules file is the authority for what the server enforces.
  const rulesPath = loadProjectRules(sandbox, projectDir);
  const hasProjectRules = rulesPath !== null;
  if (hasProjectRules) {
    log(`rules loaded from ${rulesPath}`);
  } else {
    log(`no firestore.rules found in ${projectDir}`);
  }
  const restoredObjects = await loadStorageSidecar(storage, projectDir);
  const restoredStorage = restoredObjects > 0;
  if (restoredStorage) {
    log(`restored ${restoredObjects} objects from ${join(projectDir, STORAGE_SIDECAR_RELATIVE)}`);
  }

  // Debounced persistence: a burst of writes collapses to one flush. The final
  // flush is synchronous and runs before the server closes, so the file a reader
  // opens after the session always contains the last writes. `pendingSave`
  // covers the path where the process ends without reaching that flush.
  let saveTimer: ReturnType<typeof setTimeout> | null = null;
  let pendingSave = false;
  const saveNow = (): void => {
    pendingSave = false;
    try {
      saveSandboxSnapshot(sandbox, projectDir);
    } catch (e) {
      log(`persist failed: ${failureMessage(e)}`);
    }
  };
  const flush = (): void => {
    const pendingTimer = saveTimer;
    const hasSaveTimer = pendingTimer !== null;
    if (hasSaveTimer) {
      clearTimeout(pendingTimer);
      saveTimer = null;
    }
    saveNow();
  };
  const scheduleSave = (): void => {
    pendingSave = true;
    const pendingTimer = saveTimer;
    const hasSaveTimer = pendingTimer !== null;
    if (hasSaveTimer) clearTimeout(pendingTimer);
    saveTimer = setTimeout(saveNow, 750);
  };
  const saveIfPendingAtExit = (): void => {
    if (pendingSave) saveNow();
  };
  process.once('exit', saveIfPendingAtExit);

  const baseServerOptions: InProcessMcpServerOptions = {
    onAfterDispatch: scheduleSave,
    surface: options.surface,
    allowProduction: options.allowProduction,
    projectDir,
    inProcessOnly: options.inProcessOnly,
  };
  // A surface id no renderer claims is a start-up failure, not a per-call one:
  // serving the wrong surface would silently mislabel a whole run.
  let server;
  try {
    server = buildInProcessMcpServer(sandbox, withInProcessEventWriter(baseServerOptions, evalLog));
  } catch (e) {
    process.off('exit', saveIfPendingAtExit);
    log(failureMessage(e));
    return 1;
  }
  const transport = options.transport ?? (await openStdioTransport());

  return await new Promise<number>((resolve) => {
    let stopping = false;
    const onStdinEnd = (): void => stop(0);
    /**
     * Write the storage sidecar. Storage reads are asynchronous, so this is the
     * one part of the final flush that cannot be synchronous; it runs before
     * the exit code resolves, which is before the process ends.
     */
    const flushStorage = async (): Promise<void> => {
      try {
        await saveStorageSidecar(storage, projectDir);
      } catch (e) {
        log(`storage persist failed: ${failureMessage(e)}`);
      }
    };
    const finishStop = async (code: number): Promise<number> => {
      await flushStorage();
      try {
        await server.close();
        return code;
      } catch (e) {
        log(`shutdown failed: ${failureMessage(e)}`);
        const wasSuccessful = code === 0;
        return wasSuccessful ? 1 : code;
      }
    };
    const stop = (code: number): void => {
      if (stopping) return;
      stopping = true;
      process.stdin.off('end', onStdinEnd);
      // Synchronous, and before `server.close()`: the debounced timer can hold
      // writes that have not reached disk, and nothing after this point is
      // guaranteed to run.
      flush();
      process.off('exit', saveIfPendingAtExit);
      void finishStop(code).then(resolve);
    };
    transport.onclose = () => stop(0);
    // StdioServerTransport 1.29 no longer reports stdin EOF through onclose.
    // Editors close the pipe to end an MCP session, so own that lifecycle
    // signal explicitly and then close the server/transport above.
    process.stdin.once('end', onStdinEnd);
    process.once('SIGINT', () => stop(0));
    process.once('SIGTERM', () => stop(0));
    void server.connect(transport).then(
      () => log(`in-process sandbox MCP server ready (persisting to ${IN_PROCESS_STATE_RELATIVE})`),
      (e) => {
        log(`failed to start: ${failureMessage(e)}`);
        resolve(1);
      },
    );
  });
}
