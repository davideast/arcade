import { DataSnapshot, RtdbRuleRuntimeError, evaluateRtdbRule } from '../grammar/simulator.js';
import type { EvalContext, SimulatedAuth } from '../grammar/simulator.js';
import type { RtdbNode, RtdbRuleExpression } from '../types.js';
import { SimulationInputSchema, type SimulationInput } from './spec.js';
import { normalizeAuthState } from '../../../sandbox/sandbox-context.js';
import { resolveSentinels } from '../../../database/sandbox/sentinels.js';
import type { RtdbRuleEvaluation, SimulateResult } from './spec.js';

interface AncestorMatch {
  node: RtdbNode;
  pathVariableBindings: Record<string, string>;
  /** Number of `path` segments consumed to reach this node from the root —
   *  i.e. this ancestor's own location, used to root `data`/`newData` at
   *  the rule's location rather than at the operation's target path. */
  depth: number;
}

/** Builds the evaluation context for a rule at a given node — supplied by
 *  `execute` so it can close over `auth` / `root` / the requested op. */
type ContextBuilder = (
  data: DataSnapshot,
  newData: DataSnapshot,
  bindings: Record<string, string>,
) => EvalContext;

interface ValidateFailure {
  node: RtdbNode;
  rule: RtdbRuleExpression;
  bindings: Record<string, string>;
  /** True when this "failure" is a simulator gap (the grammar could not
   *  parse the `.validate` expression) rather than a genuine `false`
   *  evaluation. A real failure found anywhere in the tree always takes
   *  priority over an unsupported one (AND-semantics: a confirmed DENY
   *  is stronger evidence than an abstention). */
  unsupported?: boolean;
  /** The runtime error the rule raised, when it failed by raising one
   *  rather than by evaluating to false. */
  runtimeError?: string;
}

/** The outcome of evaluating one rule: whether it holds, and the runtime
 *  error it raised when it failed that way. */
interface RuleOutcome {
  holds: boolean;
  runtimeError?: string;
}

/**
 * Evaluates one rule. A runtime error that production also raises, such as a
 * string method called on a number, fails the rule: a `.read` or `.write`
 * that raises one does not grant, and a `.validate` that raises one rejects
 * the write. Any other throw is a construct the simulator does not evaluate
 * and propagates to the caller.
 */
function evaluateRule(rule: RtdbRuleExpression, ctx: EvalContext): RuleOutcome {
  try {
    return { holds: Boolean(evaluateRtdbRule(rule, ctx)) };
  } catch (error) {
    if (error instanceof RtdbRuleRuntimeError) return { holds: false, runtimeError: error.message };
    throw error;
  }
}

/**
 * The trace entry for one rule at `node`. `outcome` is absent for a rule the
 * simulator cannot evaluate, which is recorded as `UNSUPPORTED`.
 */
function traceEntry(
  node: RtdbNode,
  kind: RtdbRuleEvaluation['kind'],
  rule: RtdbRuleExpression,
  bindings: Record<string, string>,
  outcome: RuleOutcome | undefined,
): RtdbRuleEvaluation {
  const entry: RtdbRuleEvaluation = {
    path: node.path,
    kind,
    conditionText: rule.raw,
    verdict: 'UNSUPPORTED',
    pathVariableBindings: { ...bindings },
  };
  if (outcome === undefined) {
    const details = rule.parsed.errors.map((e) => e.message).join('; ');
    entry.message = details === ''
      ? 'The simulator cannot evaluate this expression'
      : `The simulator cannot evaluate this expression: ${details}`;
  } else if (outcome.runtimeError !== undefined) {
    entry.verdict = 'ERROR';
    entry.message = outcome.runtimeError;
  } else {
    entry.verdict = outcome.holds ? 'ALLOW' : 'DENY';
  }
  return entry;
}

/** Own-enumerable keys of a snapshot's object value; empty for non-objects. */
function snapshotChildKeys(snap: DataSnapshot): string[] {
  const value = snap.val();
  if (value === null || typeof value !== 'object') return [];
  return Object.keys(value as object);
}

/**
 * The rules `auth` variable for a signed-in request: the uid, the ID token
 * claims with the tenant folded in by the shared normalizer, and `provider`,
 * which production reads as the token's `firebase.sign_in_provider`. There is
 * no top-level `auth.tenant`; production reads it as null.
 */
function simulatedAuthOf(auth: NonNullable<SimulationInput['auth']>): SimulatedAuth {
  const normalized = normalizeAuthState(auth);
  const token = normalized?.token ?? {};
  const simulated: SimulatedAuth = { uid: auth.uid, token };
  const firebase = token.firebase;
  const claims = typeof firebase === 'object' && firebase !== null ? (firebase as Record<string, unknown>) : {};
  const signInProvider = claims.sign_in_provider;
  if (typeof signInProvider === 'string') simulated.provider = signInProvider;
  return simulated;
}

/** True when `n` or any node below it carries a `.validate` rule. */
function hasValidateRule(n: RtdbNode): boolean {
  if (n.validate) return true;
  return n.children.some(hasValidateRule);
}

/**
 * `.validate` enforcement for a write. RTDB evaluates every rule on the path
 * from the root to each write location (every path of a multi-path update),
 * then every descendant rule present in the written value, whether or not
 * that value differs from the stored one. A sibling node the write does not
 * carry is not validated, even when its stored value fails its rule. Each
 * rule sees the merged post-write snapshot rooted at its own location.
 * Unlike `.read`/`.write`, validation never grants: ALL applicable rules must
 * evaluate true. Null proposed values are skipped.
 *
 * An unparseable `.validate` expression is a simulator gap, not a pass:
 * production would still evaluate it and may reject the write, so treating
 * it as "no rule" would be a fidelity lie. It is reported as `unsupported`
 * (an abstention) rather than fabricated as either ALLOW or DENY — mirrors
 * the Firestore simulator's posture where an `UnsupportedError` never
 * counts as a real evaluation. A genuine `false` found anywhere in the
 * tree still wins over an unsupported node elsewhere (a confirmed DENY is
 * stronger evidence than an abstention). Returns the first real failure, else
 * the first unsupported node, else `null` when every applicable `.validate`
 * passes. Every `.validate` the walk reaches is appended to `trace`.
 */
function findFailingValidate(
  node: RtdbNode,
  data: DataSnapshot,
  newData: DataSnapshot,
  bindings: Record<string, string>,
  buildContext: ContextBuilder,
  trace: RtdbRuleEvaluation[],
  pathToWrite: string[],
  updates?: readonly { path: string; value?: unknown }[],
): ValidateFailure | null {
  let firstUnsupported: ValidateFailure | null = null;

  const writePathStrings = new Set<string>();
  if (updates && updates.length > 0) {
    for (const u of updates) {
      writePathStrings.add(u.path.split('/').filter(Boolean).join('/'));
    }
  }
  writePathStrings.add(pathToWrite.filter(Boolean).join('/'));
  const allWritePaths = Array.from(writePathStrings).map((p) => p.split('/').filter(Boolean));

  function walk(
    node: RtdbNode,
    data: DataSnapshot,
    newData: DataSnapshot,
    bindings: Record<string, string>,
    currentSegments: string[],
  ): ValidateFailure | null {
    if (newData.exists()) {
      const rule = node.validate;
      if (rule) {
        if (!rule.parsed.valid) {
          trace.push(traceEntry(node, 'validate', rule, bindings, undefined));
          if (!firstUnsupported) {
            firstUnsupported = { node, rule, bindings, unsupported: true };
          }
        } else {
          const outcome = evaluateRule(rule, buildContext(data, newData, bindings));
          trace.push(traceEntry(node, 'validate', rule, bindings, outcome));
          if (!outcome.holds) return { node, rule, bindings, runtimeError: outcome.runtimeError };
        }
      }
    }

    // At or below a write location the written value is present in full, so
    // every child it carries is visited. Above one, only the children on a
    // write path are: a sibling the write does not carry is never validated.
    const isAtOrBelowWriteTarget = allWritePaths.some(
      (wp) => wp.length <= currentSegments.length && wp.every((seg, idx) => seg === currentSegments[idx]),
    );
    const childKeys = isAtOrBelowWriteTarget
      ? snapshotChildKeys(newData)
      : writeKeysBelow(currentSegments);

    for (const key of childKeys) {
      const matched = childFor(node, key);
      if (matched === undefined) continue;
      const childBindings = matched.variable === undefined
        ? bindings
        : { ...bindings, [matched.variable]: key };
      const failure = walk(
        matched.child,
        data.child(key),
        newData.child(key),
        childBindings,
        [...currentSegments, key],
      );
      if (failure) return failure;
    }

    return null;
  }

  /** The next key of every write path that passes through `currentSegments`. */
  function writeKeysBelow(currentSegments: readonly string[]): Set<string> {
    const keys = new Set<string>();
    for (const wp of allWritePaths) {
      const passesThrough = wp.length > currentSegments.length &&
        currentSegments.every((seg, idx) => seg === wp[idx]);
      if (passesThrough) keys.add(wp[currentSegments.length]);
    }
    return keys;
  }

  const realFailure = walk(node, data, newData, bindings, []);
  return realFailure ?? firstUnsupported;
}

/**
 * Walk from root toward the target path, collecting every ancestor node
 * along the way (including the deepest match). Firebase RTDB evaluates
 * rules from root down — a `true` at any ancestor grants access.
 */
function collectAncestors(
  node: RtdbNode,
  pathSegments: string[],
  bindings: Record<string, string>,
  depth = 0,
): AncestorMatch[] {
  const ancestors: AncestorMatch[] = [{ node, pathVariableBindings: { ...bindings }, depth }];

  if (pathSegments.length === 0) return ancestors;

  const matched = childFor(node, pathSegments[0]);
  if (matched === undefined) return ancestors;
  const newBindings = matched.variable === undefined
    ? { ...bindings }
    : { ...bindings, [matched.variable]: pathSegments[0] };
  ancestors.push(...collectAncestors(matched.child, pathSegments.slice(1), newBindings, depth + 1));
  return ancestors;
}

/** The last segment of a rule node's path: its key, or `$name` for a wildcard. */
function keyOf(node: RtdbNode): string | undefined {
  const segments = node.path.split('/').filter(Boolean);
  return segments[segments.length - 1];
}

/**
 * The child rule node that applies to `key`: the literal child that names it,
 * else the `$wildcard` child, bound to it. Production applies a wildcard only
 * to keys no literal sibling names, whichever is declared first.
 */
function childFor(node: RtdbNode, key: string): { child: RtdbNode; variable?: string } | undefined {
  let wildcard: { child: RtdbNode; variable: string } | undefined;
  for (const child of node.children) {
    const childKey = keyOf(child);
    if (childKey === undefined) continue;
    if (childKey === key) return { child };
    const isWildcard = childKey.startsWith('$');
    if (isWildcard && wildcard === undefined) wildcard = { child, variable: childKey };
  }
  return wildcard;
}

/** The denial result for a failing `.validate` rule. */
function toValidateFailureResult(failure: ValidateFailure, trace: RtdbRuleEvaluation[]): SimulateResult {
  let reason = 'Validation rule evaluated to false';
  if (failure.unsupported) {
    reason = `Validation rule at '${failure.node.path}' contains an expression the simulator cannot evaluate: ${failure.rule.raw}. It was not evaluated; production may reject this write.`;
  } else if (failure.runtimeError !== undefined) {
    reason = `Validation rule at '${failure.node.path}' failed at evaluation: ${failure.runtimeError}`;
  }
  return {
    success: true,
    data: {
      allowed: false,
      unsupported: failure.unsupported === true,
      matchedPath: failure.node.path,
      matchedRule: failure.rule.raw,
      reason,
      pathVariableBindings: failure.bindings,
      trace,
    },
  };
}

/**
 * Return a new tree equal to `root` but with the value at `segments`
 * replaced by `value` (a `null`/`undefined` value deletes the node, same
 * as an RTDB write of `null`). Used to build the post-write tree so that
 * `newData` at an ANCESTOR of the write location reflects the merged
 * result at that ancestor's own path, not just the raw payload at the
 * deepest write path.
 */
function withValueAt(root: unknown, segments: string[], value: unknown): unknown {
  if (segments.length === 0) return value ?? null;

  const [head, ...rest] = segments;
  const currentObj: Record<string, unknown> =
    root !== null && typeof root === 'object' && !Array.isArray(root)
      ? { ...(root as Record<string, unknown>) }
      : {};

  const existingChild = Object.hasOwn(currentObj, head) ? currentObj[head] : null;
  const childValue = withValueAt(existingChild, rest, value);

  if (childValue === null || childValue === undefined) {
    delete currentObj[head];
  } else {
    currentObj[head] = childValue;
  }

  return currentObj;
}

/**
 * Build the single post-write tree that a write/validate evaluation sees as
 * `newData`.
 *
 * For a single-path write this is just `withValueAt(base, targetSegments,
 * targetNewData)`. For an atomic multi-path `update()` — where `updates`
 * lists every path written together — this folds `withValueAt` over EVERY
 * listed path so the projection reflects the ENTIRE update applied at once.
 * Each written path's rules are then evaluated against this shared tree,
 * matching production RTDB: a multi-path update is atomic, so a rule on one
 * written path sees `newData` for its sibling paths in the same update.
 *
 * Evaluating each path leaf-by-leaf against only its own new value (the old
 * behavior) is a wrong-verdict bug: a rule that depends on a sibling path
 * written in the same update sees that sibling as absent, flipping legal
 * writes to a false DENY (and the reverse for `!exists()`-style escape
 * hatches, a false ALLOW).
 */
function projectPostWriteTree(
  base: unknown,
  targetSegments: string[],
  targetNewData: unknown,
  updates: readonly { path: string; value?: unknown }[] | undefined,
): unknown {
  if (!updates || updates.length === 0) {
    return withValueAt(base, targetSegments, targetNewData ?? null);
  }
  let root = base;
  for (const update of updates) {
    const segments = update.path.split('/').filter(Boolean);
    root = withValueAt(root, segments, update.value ?? null);
  }
  return root;
}

function buildSimulatedQueryContext(
  operation: string,
  query: SimulationInput['query'],
): EvalContext['query'] {
  if (operation !== 'read' || !query) {
    return null;
  }
  return {
    orderByChild: query.orderByChild ?? null,
    orderByKey: query.orderByKey ?? null,
    orderByValue: query.orderByValue ?? null,
    equalTo: query.equalTo ?? null,
    limitToFirst: query.limitToFirst ?? null,
    limitToLast: query.limitToLast ?? null,
    startAt: query.startAt ?? null,
    endAt: query.endAt ?? null,
  };
}

/** The value stored at `path` in a root tree, or undefined. */
function valueAtPath(root: unknown, path: string): unknown {
  let cursor: unknown = root;
  for (const segment of path.split('/').filter(Boolean)) {
    if (cursor === null || typeof cursor !== 'object') return undefined;
    cursor = (cursor as Record<string, unknown>)[segment];
  }
  return cursor;
}

export class SimulateHandler {
  execute(compiled: RtdbNode, rawInput: unknown): SimulateResult {
    const parsed = SimulationInputSchema.safeParse(rawInput);
    if (!parsed.success) {
      return {
        success: false,
        error: {
          code: 'INVALID_INPUT',
          message: parsed.error.message,
          recoverable: true,
        },
      };
    }

    const { operation, path, auth, mockData, query } = parsed.data;
    // `now` in an RTDB rule is the instant the request is evaluated. A caller
    // hosting a sandbox names it so a `now`-gated rule moves with the sandbox
    // clock; a standalone caller leaves it out and gets the wall clock.
    const evaluationNow = parsed.data.now ?? Date.now();
    // The server replaces each written `{ ".sv": "timestamp" }` with the
    // instant it evaluates the rules at, and each `{ ".sv": { increment } }`
    // with the stored value plus the delta, before any rule runs. The sandbox
    // resolves its writes the same way at its write boundary.
    const newData = parsed.data.newData === undefined
      ? undefined
      : resolveSentinels(parsed.data.newData, evaluationNow, valueAtPath(mockData, path));
    const updates = parsed.data.updates?.map((update) => ({
      ...update,
      value: resolveSentinels(update.value, evaluationNow, valueAtPath(mockData, update.path)),
    }));

    // Every rule evaluated for this request, in evaluation order.
    const trace: RtdbRuleEvaluation[] = [];

    try {
      const pathSegments = path.split('/').filter(Boolean);
      const rootNode = compiled;

      const ancestors = collectAncestors(rootNode, pathSegments, {});

      // Walk from root down. First ancestor whose rule evaluates to true wins.
      //
      // `data`/`newData` must be rooted at EACH ancestor's own location —
      // not at the operation's target path — matching live RTDB semantics:
      // a rule declared at `/rooms/$roomId` sees `data`/`newData` as the
      // snapshot AT `/rooms/$roomId`, even when the write is deeper (e.g.
      // `/rooms/$roomId/title`). Rooting everything at the deepest write
      // path instead makes ancestor rules see "no data" (since the
      // deepest path usually doesn't exist yet), which silently satisfies
      // `!data.exists()`-style escape hatches and produces a false ALLOW.
      const rootData = new DataSnapshot(mockData, '/');
      // Post-write tree: mockData with the proposed write merged in. Reads
      // don't have a "post-write" state, so leave it as-is. For an atomic
      // multi-path `update()` (`updates` present) the projection reflects
      // EVERY path written together, so this path's rules see `newData` for
      // its sibling paths in the same update.
      const mergedRoot =
        operation === 'read'
          ? mockData
          : projectPostWriteTree(mockData, pathSegments, newData, updates);
      const mergedRootData = new DataSnapshot(mergedRoot, '/');

      let contextAuth: SimulatedAuth | null = null;
      if (auth) contextAuth = simulatedAuthOf(auth);

      const contextQuery = buildSimulatedQueryContext(operation, query);

      const buildContext: ContextBuilder = (data, newDataArg, bindings) => {
        const pvBindings: Record<string, string> = {};
        for (const [k, v] of Object.entries(bindings)) {
          pvBindings[k] = v;
          pvBindings[k.slice(1)] = v;
        }
        return {
          auth: contextAuth,
          data,
          newData: newDataArg,
          root: rootData,
          now: evaluationNow,
          pathVariableBindings: pvBindings,
          query: contextQuery,
        };
      };

      // The validate operation runs only the `.validate` phase: every
      // `.validate` rule from the root through the write location and its
      // written descendants must pass, whatever `.write` grants.
      if (operation === 'validate') {
        const deepestValidate = [...ancestors].reverse().find((a) => a.node.validate !== undefined)
          ?? ancestors.find((a) => hasValidateRule(a.node));
        if (deepestValidate === undefined) {
          return {
            success: false,
            error: { code: 'NO_MATCHING_RULE', message: `No 'validate' rule found for path '${path}'`, recoverable: true },
          };
        }
        const failure = findFailingValidate(rootNode, rootData, mergedRootData, {}, buildContext, trace, pathSegments, updates);
        if (failure) return toValidateFailureResult(failure, trace);
        return {
          success: true,
          data: {
            allowed: true,
            matchedPath: deepestValidate.node.path,
            matchedRule: deepestValidate.node.validate?.raw ?? 'true',
            reason: 'Validation rules evaluated to true',
            pathVariableBindings: deepestValidate.pathVariableBindings,
            trace,
          },
        };
      }

      // Tracks the first ancestor whose `.write`/`.read` rule the grammar
      // couldn't parse. Unlike `.validate`, `.write`/`.read` rules cascade
      // (any ancestor granting `true` wins), so an unparseable rule is not
      // simply "no rule here" — production would still evaluate it and
      // might grant on it. If no ancestor grants and no real deny is
      // found either, this reported as `unsupported` rather than a
      // fabricated deny.
      let firstUnsupportedAncestor: AncestorMatch | undefined;
      // The runtime error each ancestor's rule raised, when it raised one. A
      // rule that raises one does not grant, and the cascade continues to the
      // next rule on the path, as it does after a rule that evaluates false.
      const runtimeErrors = new Map<AncestorMatch, string>();

      for (const ancestor of ancestors) {
        const ruleExpr: RtdbRuleExpression | undefined = ancestor.node[operation];
        if (!ruleExpr) continue;
        if (!ruleExpr.parsed.valid) {
          trace.push(traceEntry(ancestor.node, operation, ruleExpr, ancestor.pathVariableBindings, undefined));
          if (!firstUnsupportedAncestor) firstUnsupportedAncestor = ancestor;
          continue;
        }

        const ancestorSegments = pathSegments.slice(0, ancestor.depth).join('/');
        const dataAtAncestor = rootData.child(ancestorSegments);
        const newDataAtAncestor = mergedRootData.child(ancestorSegments);

        const outcome = evaluateRule(
          ruleExpr,
          buildContext(dataAtAncestor, newDataAtAncestor, ancestor.pathVariableBindings),
        );
        trace.push(traceEntry(ancestor.node, operation, ruleExpr, ancestor.pathVariableBindings, outcome));
        if (outcome.runtimeError !== undefined) runtimeErrors.set(ancestor, outcome.runtimeError);

        if (outcome.holds) {
          // A granting `.write` is necessary but not sufficient: RTDB also
          // enforces every `.validate` rule from the root through the write
          // location and through every present descendant.
          // Unlike `.read`/`.write`, `.validate` does NOT cascade — all must
          // pass (a single failure denies the write). Read ops have no
          // validate phase.
          if (operation === 'write') {
            const failure = findFailingValidate(
              rootNode,
              rootData,
              mergedRootData,
              {},
              buildContext,
              trace,
              pathSegments,
              updates,
            );
            if (failure) return toValidateFailureResult(failure, trace);
          }
          return {
            success: true,
            data: {
              allowed: true,
              matchedPath: ancestor.node.path,
              matchedRule: ruleExpr.raw,
              reason: 'Rule expression evaluated to true',
              pathVariableBindings: ancestor.pathVariableBindings,
              trace,
            },
          };
        }
      }

      // No ancestor rule evaluated to true. If an ancestor's rule couldn't
      // be parsed, we can't rule out that production would have granted on
      // it — report the gap instead of fabricating a deny.
      if (firstUnsupportedAncestor) {
        const rule = firstUnsupportedAncestor.node[operation] as RtdbRuleExpression;
        return {
          success: true,
          data: {
            allowed: false,
            unsupported: true,
            matchedPath: firstUnsupportedAncestor.node.path,
            matchedRule: rule.raw,
            reason: `'${operation}' rule at '${firstUnsupportedAncestor.node.path}' contains an expression the simulator cannot evaluate: ${rule.raw} — not evaluated; production may reject or allow this ${operation}.`,
            pathVariableBindings: firstUnsupportedAncestor.pathVariableBindings,
            trace,
          },
        };
      }

      // No rule on the path grants, so RTDB denies. The denial names the
      // deepest node that carries a rule of this kind, which may be an
      // ancestor of the deepest rules node on the path: that node can hold
      // only children, a `.validate`, or the other operation's rule. With no
      // rule of this kind anywhere on the path, the request is denied by
      // default and no node is named.
      const deciding = [...ancestors].reverse().find((a) => a.node[operation] !== undefined);
      if (deciding === undefined) {
        return {
          success: true,
          data: {
            allowed: false,
            matchedPath: '',
            matchedRule: '',
            reason: `No '${operation}' rule on '${path}' or its ancestors grants access; denied by default`,
            pathVariableBindings: ancestors[ancestors.length - 1].pathVariableBindings,
            trace,
          },
        };
      }
      const decidingRule = deciding.node[operation] as RtdbRuleExpression;
      const decidingError = runtimeErrors.get(deciding);
      const decidingOutcome = decidingError === undefined
        ? 'evaluated to false'
        : `failed at evaluation: ${decidingError}`;
      return {
        success: true,
        data: {
          allowed: false,
          matchedPath: deciding.node.path,
          matchedRule: decidingRule.raw,
          reason: `No '${operation}' rule grants access; the deepest, at '${deciding.node.path}', ${decidingOutcome}`,
          pathVariableBindings: deciding.pathVariableBindings,
          trace,
        },
      };
    } catch (e) {
      // A rule the evaluator does not evaluate, such as one calling a method
      // outside the rules language. Runtime errors that production also
      // raises never reach here: `evaluateRule` counts them as the rule failing.
      return {
        success: false,
        error: {
          code: 'EVALUATION_ERROR',
          message: e instanceof Error ? e.message : String(e),
          recoverable: false,
        },
      };
    }
  }
}
