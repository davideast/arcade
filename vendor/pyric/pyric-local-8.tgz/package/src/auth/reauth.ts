/**
 * Re-authentication: `reauthenticateWithCredential`,
 * `reauthenticateWithPopup`, `reauthenticateWithRedirect`.
 *
 * ─── What re-auth IS ───────────────────────────────────────────────
 * Proving, again and freshly, that the person at the keyboard is the
 * account owner before a sensitive mutation (change the password, change
 * the email, delete the account). Those mutations refuse a session whose
 * last authentication is older than five minutes with
 * `auth/requires-recent-login` (the backend's `assertRecentLogin`, timed on
 * the sandbox clock), and a successful re-auth records a new
 * authentication, which clears the gate and moves the token's `authTime`.
 *
 * ─── Evidence ──────────────────────────────────────────────────────
 * Not oracle-backed, and for a specific reason worth recording: the
 * probe exists (`auth-reauthenticate-with-credential`) and was run
 * against the real project, but the oracle project has the
 * Email/Password provider DISABLED, so it could not even create the two
 * accounts the probe needs — every arm came back
 * `auth/operation-not-allowed`. The capture is committed showing that.
 * The error codes below are matched to the oracle-captured
 * `AuthErrorCodes` map (`USER_MISMATCH = 'auth/user-mismatch'`), and the
 * rows are born unit-backed.
 */

import { makeAuthError } from './auth-errors.js';
import { requireSandboxUser, userInternal } from './action-codes.js';
import { AuthCredential, EmailAuthCredential } from './credentials.js';
import type { AuthProvider } from './providers.js';
import type { AuthFlowRequest, AuthFlowResolver, User, UserCredential } from './types.js';

/**
 * `reauthenticateWithCredential(user, credential)` — mirror of
 * `firebase/auth`.
 *
 * Really re-verifies: an email credential is checked against the stored
 * password exactly as `signInWithEmailAndPassword` checks it, so a wrong
 * password throws `auth/wrong-password` and a credential belonging to a
 * DIFFERENT account throws `auth/user-mismatch` (the check that stops
 * "reauthenticate as someone else" from silently succeeding).
 *
 * On success records a new authentication and mints a fresh ID token, so
 * `getIdTokenResult(user).authTime` advances and the recent-login gate
 * clears.
 */
export async function reauthenticateWithCredential(
  user: User,
  credential: AuthCredential,
): Promise<UserCredential> {
  const t = userInternal(user, 'reauthenticateWithCredential').target;
  const target = t;
  target.backend.assertProviderEnabled(credential.providerId);

  if (credential instanceof EmailAuthCredential) {
    const stored = target.backend.findByEmail(credential.email);
    // user-mismatch BEFORE the password compare: presenting another
    // account's credential is the wrong-user error regardless of whether
    // the password happens to be right, and answering "wrong password"
    // there would leak whether it was.
    if (!stored || stored.uid !== user.uid) {
      throw makeAuthError(
        'auth/user-mismatch',
        'The supplied credentials do not correspond to the previously signed in user.',
      );
    }
    const password = credential.password;
    if (password === null) {
      throw makeAuthError(
        'auth/argument-error',
        'reauthenticateWithCredential: an email-link credential carries no password to verify.',
      );
    }
    // The real check — same path signInWithEmailAndPassword takes, so it
    // throws the same `auth/wrong-password` / `auth/user-disabled`.
    target.backend.validatePassword(credential.email, password);
    return completeReauth(user, target, null);
  }

  // OAuth credential: the sandbox cannot verify an IdP token, so the only
  // honest check is that the credential's provider is actually linked to
  // this account.
  const stored = target.backend.findByUid(user.uid);
  if (!stored?.providerUserInfo.some((p) => p.providerId === credential.providerId)) {
    throw makeAuthError(
      'auth/user-mismatch',
      'The supplied credentials do not correspond to the previously signed in user.',
    );
  }
  return completeReauth(user, target, credential.providerId);
}

/**
 * `reauthenticateWithPopup(user, provider, resolver?)` — mirror of
 * `firebase/auth`. Runs the shared resolver seam with
 * `authType: 'reauth'`, so a host UI can present "confirm it's you"
 * rather than a fresh sign-in.
 *
 * The resolved credential must be for THE SAME user — a resolver that
 * hands back a different uid throws `auth/user-mismatch`. Without that
 * check, "re-authentication" would accept anyone.
 */
export async function reauthenticateWithPopup(
  user: User,
  provider: AuthProvider,
  resolver?: AuthFlowResolver,
): Promise<UserCredential> {
  userInternal(user, 'reauthenticateWithPopup');
  return reauthViaFlow(user, provider, resolver, 'popup', 'reauthenticateWithPopup');
}

/**
 * `reauthenticateWithRedirect(user, provider, resolver?)` — mirror of
 * `firebase/auth`. Resolves inline (the sandbox has no navigation), same
 * as `signInWithRedirect`.
 */
export async function reauthenticateWithRedirect(
  user: User,
  provider: AuthProvider,
  resolver?: AuthFlowResolver,
): Promise<UserCredential> {
  userInternal(user, 'reauthenticateWithRedirect');
  return reauthViaFlow(user, provider, resolver, 'redirect', 'reauthenticateWithRedirect');
}

// ─── Shared internals ─────────────────────────────────────────────────

async function reauthViaFlow(
  user: User,
  provider: AuthProvider,
  perCall: AuthFlowResolver | undefined,
  kind: 'popup' | 'redirect',
  api: string,
): Promise<UserCredential> {
  const target = requireSandboxUser(user, api);
  target.backend.assertProviderEnabled(provider.providerId);
  const req: AuthFlowRequest = { providerId: provider.providerId, authType: 'reauth' };
  const resolver = perCall ?? target.backend.getResolver();
  const resolved = resolver
    ? (kind === 'popup' ? await resolver.openPopup(req) : await resolver.openRedirect(req))
    : target.backend.consumeMockResult(provider.providerId);
  if (!resolved) {
    throw makeAuthError(
      'auth/argument-error',
      `${api}(provider: ${provider.providerId}): no AuthFlowResolver configured. Inject one with sandbox.setAuthFlowResolver(auth, resolver), pass one as the resolver argument, or pre-stage a result with sandbox.mockSignInResult(auth, {user, providerId: '${provider.providerId}', …}).`,
    );
  }
  // The identity the resolver produced must BE the user being
  // re-authenticated. This is the entire security content of the flow.
  if (resolved.user.uid !== user.uid) {
    throw makeAuthError(
      'auth/user-mismatch',
      'The supplied credentials do not correspond to the previously signed in user.',
    );
  }
  return completeReauth(user, target, resolved.providerId ?? provider.providerId);
}

/** Mint a fresh token for the re-verified user and shape the credential. */
function completeReauth(
  user: User,
  target: ReturnType<typeof requireSandboxUser>,
  providerId: string | null,
): UserCredential {
  const stored = target.backend.findByUid(user.uid);
  const claims = stored?.customClaims ?? {};
  // A successful re-auth is a fresh authentication: it restarts the
  // recent-login window and the next token carries the new authTime.
  target.backend.recordAuthentication(user.uid);
  target.backend.getIdTokenResultFor(user.uid, claims, true, user.tenantId);
  const hasStoredUser = stored !== undefined;
  const refreshed = hasStoredUser ? target.backend.buildUserFromStored(stored) : user;
  return {
    user: refreshed,
    providerId,
    operationType: 'reauthenticate',
    _additionalUserInfo: {
      isNewUser: false,
      profile: {},
      providerId,
    },
  };
}
